# Selenium 설치: pip install selenium
# Selenium: 브라우저를 코드로 조작하는 라이브러리

from selenium import webdriver
from selenium.webdriver.chrome.options import Options

options = Options()
options.add_argument('--headless=new') # 브라우저 창 없이 실행
options.add_argument('--disable-gpu')  # GPU 사용X

try:
    URL = 'https://quotes.toscrape.com/js'
    driver = webdriver.Chrome(options=options)
    driver.get(url=URL)

    print('현재 URL: ', driver.current_url)
    print('페이지 제목: ', driver.title)
    print('HTML 길이: ', len(driver.page_source))

finally:
    driver.quit()