from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

options = Options()
options.add_argument('--headless=new')
driver = webdriver.Chrome(options=options)

try:
    URL = 'https://quotes.toscrape.com/js'
    driver = webdriver.Chrome(options=options)
    driver.get(url=URL)
    wait = WebDriverWait(driver, 10)
    wait.until(EC.presence_of_element_located((By.CSS_SELECTOR, 'div.quote')))

    quotes = []
    div_quotes = driver.find_elements(By.CSS_SELECTOR, 'div.quote')
    for block in div_quotes:
        quotes.append({
            'text' : block.find_element(By.CSS_SELECTOR, 'span.text').text,
            "author" : block.find_element(By.CSS_SELECTOR, 'small.author').text
        })
    for quote in quotes:
        print(f'{quote["text"]} : {quote["author"]}')
    
finally:
    driver.quit()