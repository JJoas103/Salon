# Selenium 설치: pip install selenium
# Selenium: 브라우저를 코드로 조작하는 라이브러리

from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

options = Options()
options.add_argument('--headless=new') # 브라우저 창 없이 실행
# options.add_argument('--disable-gpu')  # GPU 사용X

try:
    URL = 'https://quotes.toscrape.com/js/'
    driver = webdriver.Chrome(options=options)
    
    driver.get(URL)
    # WebDriverWait: JS 로딩 대기
    wait = WebDriverWait(driver, 10)
    wait.until(EC.presence_of_element_located((By.CSS_SELECTOR, 'div.quote')))

    # 1) find_elements: 조건이 맞는 태그를 전부 가져와 리스트로 반환 
    quotes = driver.find_elements(By.CSS_SELECTOR, "div.quote")
    print('인용구 개수: ', len(quotes))

    # 2) find_element: 조건이 맞는 하나의 태그 가져오기
    first = quotes[0]
    text_el = first.find_element(By.CSS_SELECTOR, 'span.text')
    print('첫번째 인용문: ', text_el.text)
    author_el = first.find_element(By.CSS_SELECTOR, 'small.author')
    print('첫번째 저자: ', author_el.text)
    tags = first.find_elements(By.CSS_SELECTOR, 'a.tag')
    print('첫번째 태그: ', [tag.text for tag in tags])

finally:
    driver.quit()