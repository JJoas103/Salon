from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import NoSuchElementException
from bs4 import BeautifulSoup

options = Options()
options.add_argument('--headless=new')
driver = webdriver.Chrome(options=options)

try:
    URL = 'https://quotes.toscrape.com/js'
    driver.get(URL)
    wait = WebDriverWait(driver, 10)
    wait.until(EC.presence_of_element_located((By.CSS_SELECTOR, 'div.quote')))

    # page_source: JS 실행 후 렌더링 된 HTML 문자열
    html = driver.page_source
    soup = BeautifulSoup(html, 'html.parser')
    quotes = []
    for div in soup.select('div.quote'):
        quotes.append(div.select_one('small.author').get_text(strip=True))
    print(quotes)
    
finally: 
    driver.quit()