# 대기 wait

from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

options = Options()
options.add_argument('--headless=new')
driver = webdriver.Chrome(options=options)

try:
    URL = 'https://quotes.toscrape.com/js/'
    driver.get(URL)
    # 1) 명시적 대기
    wait = WebDriverWait(driver, 10)
    wait.until(EC.presence_of_element_located((By.CSS_SELECTOR, 'div.quote')))

    # 2) 암시적 대기: find 메서드 호출할 때마다 최대 5초간 대기
    driver.implicitly_wait(5)
    title = driver.find_element(By.TAG_NAME, 'title')

finally:
    driver.quit