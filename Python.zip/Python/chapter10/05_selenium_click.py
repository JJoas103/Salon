from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import NoSuchElementException

options = Options()
options.add_argument('--headless=new')
driver = webdriver.Chrome(options=options)

try:
    URL = 'https://quotes.toscrape.com/js'
    driver = webdriver.Chrome(options=options)
    driver.get(url=URL)
    wait = WebDriverWait(driver, 10)
    quotes = []

    for page in range(1, 100):
        wait.until(EC.presence_of_element_located((By.CSS_SELECTOR, 'div.quote')))

        blocks = driver.find_elements(By.CSS_SELECTOR, 'div.quote')
        for block in blocks:
            quotes.append(block.find_element(By.CSS_SELECTOR, 'small.author').text)
        print(f'{page}: {len(blocks)}개 수집')

        try:
            next_btn = driver.find_element(By.CSS_SELECTOR, 'li.next a')
            next_btn.click()
        
        except NoSuchElementException:
            print('마지막 페이지입니다')
            break

finally:
    driver.quit()
    
print(f'총: {len(quotes)}개 수집완료')