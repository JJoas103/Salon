# with문

from pathlib import Path

sample_path = Path(__file__).parent/'output'/'hello.txt'

# with 없이(비권장)
f = open(sample_path, 'r', encoding='utf-8')
try:
    first_line = f.readline()   #readline(): 첫줄만 읽어오기
    print('첫줄: ', first_line.strip())
finally:
    f.close()   

# with 사용(권장)
with open(sample_path, 'r', encoding='utf-8') as f:
    first_line = f.readline()
    print('첫줄: ', first_line.strip())


