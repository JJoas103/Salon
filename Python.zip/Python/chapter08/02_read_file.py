# 파일 읽기

from pathlib import Path

sample_path = Path(__file__).parent/'output'/'hello.txt'

with open(sample_path, 'r', encoding='utf-8') as f:
    print(f.read()) # read(): 파일의 전체 문자열

# 한줄씩 순회: 메모리 효율적, 큰 파일에 적합
with open(sample_path, 'r', encoding='utf-8') as f:
    for i, line in enumerate(f, start=1):
        print(f'{i}: {line.strip()}')   # strip(): 문자열 양쪽 공백 제거

with open(sample_path, 'r', encoding='utf-8') as f:
    lines = f.readlines() # readlines(): 전체 줄을 리스트로 반환
    print(lines)