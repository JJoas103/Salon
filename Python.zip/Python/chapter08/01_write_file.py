# 파일쓰기

# Pathlib 설치: pip install Pathlib 
from pathlib import Path
# Path: 파일 경로를 쉽게 다루기 위한 클래스

output_dir = Path(__file__).parent/"output" # ~~/chapter08/output
# __file__: 현재 실행중인 파일의 경로
# .parent: 현재 파일의 상위 폴더 

output_dir.mkdir(exist_ok=True)
# mkdir(): 폴더 생성
# exist_ok=True: 기존 폴더가 있어도 에러 없음

file_path = output_dir/'hello.txt'

with open(file_path, 'w', encoding='utf-8') as f:
# with: 자원을 자동으로 닫기
    # open(경로, 'w'): 새로 만들거나 기존 파일 내용 덮어쓰기  
    f.write('첫번째 줄\n') # write(): 한줄씩 문자열 기록
    f.write('두번째 줄\n')
    f.writelines(['세번째 줄\n', '네번째 줄\n']) #writelines(리스트): 리스트 요소 일괄 기록
print('저장완료', file_path)



