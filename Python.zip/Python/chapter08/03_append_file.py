# 파일 추가

from pathlib import Path

sample_path = Path(__file__).parent/'output'/'hello.txt'

# 추가(append)
with open(sample_path, 'a', encoding='utf-8') as f:
    f.write('다섯번째 줄\n')
    f.write('여섯번째 줄\n')

print('추가완료')