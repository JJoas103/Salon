# 문자열(str)

product = '무선 이어폰'
brand = '솔데스크'
print(product, len(product))
# len(): 문자열 길이 반환

print(product + ': ' + brand)

# 문자열 반복(*)
line = '-' * 20
print(line)

# 여러 줄에 걸쳐 문자열 작성
message = """ㅇㅇㅇㅇㅇㅇㅇㅇㅇㅇㅇㅇㅇㅇㅇㅇㅇㅇㅇㅇㅇㅇㅇㅇㅇㅇㅇ
ㅇㅇㅇㅇㅇㅇㅇㅇㅇㅇㅇㅇㅇㅇㅇㅇㅇㅇㅇㅇㅇㅇㅇㅇㅇㅇㅇ
ㅇㅇㅇㅇㅇㅇㅇㅇㅇㅇㅇㅇㅇㅇㅇㅇㅇㅇㅇㅇㅇ"""
print(message)

#인덱싱: 문자열의 인덱스를 사용해 개별 문자에 접근
name = '이순신'
print(name[0])  # 이(첫번째 문자)
print(name[1])  # 순(두번째 문자)
print(name[2])  # 신(세번째 문자)
print(name[-1]) # 신(뒤에서 첫번째 문자)
print(name[-2]) # 순(뒤에서 두번째 문자)

#슬라이싱: 인덱스 범위를 지정해 부분 문자열을 추출(시작 : 끝 : 간격)
hello = 'Hello World'
print(hello[0:5])   # Hello(0부터 4까지)
print(hello[6:])    # World(6부터 끝까지)
print(hello[:5])    # Hello(처음부터 4까지)
print(hello[0:5:2]) # Hlo(0부터 4까지 2칸 건너뛰며 추출)
print(hello[::2])   # HloWrd(2칸 건너뛰며 추출)
print(hello[::-1])  # dlroW olleH(문자열 역순으로 가져오기)

#문자열 메서드
raw = '                            hElLo WoRlD                '
print(raw.strip())  # strip(): 문자열 양쪽 공백 제거

raw = raw.strip()
print(raw.upper())  # upper(): 문자열 대문자로 변환
print(raw.lower())  # lower(): 문자열 소문자로 변환
print(raw.replace('WoRlD', 'python'))   
# replace('치환 전 문자열', '치환 후 문자열'): 문자열 치환

raw = 'a-b-c'
print(raw.split('-'))   # split(): 문자열을 분리 후 리스트로 반환

raw = ['a', 'b', 'c'] 
print('-'.join(raw))   #join(): 리스트 요소를 문자열로 결합