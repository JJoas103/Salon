# 변수
# 타입을 미리 지정하지 않음(동적 타입)
# 변수 이름 규칙: 영문자, 숫자, 언더스코어(_)만 사용(snakce_case) / 숫자 시작X / 대소문자 구분

name_hong = '홍길동'
age = 20
height = 175.5
is_student = True

print(name_hong, type(name_hong))   # <class 'str'>
print(age, type(age)) # <class 'int'>
print(height, type(height)) # <class 'float'>
print(is_student, type(is_student)) # <class 'bool'>
'''
주석
여러 줄
'''

# 변수 재할당
age = 21
print(age, type(age))

# 여러 변수 한번에 선언
x, y, z = 1, 2, 3
print(x, y, z)

# f-string: 문자열 포맷팅
print(f'이름: {name_hong}, 나이: {age}, 키: {height}')