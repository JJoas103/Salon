# 정수(int)와 실수(float)

quantity = 3
price = 20000

total = quantity * price
print('합계: ', total, type(total))

rate = 0.15
discount = total * rate # 정수와 실수를 연산한 값은 실수
print('할인율: ', discount, type(discount)) # <class 'float'>

