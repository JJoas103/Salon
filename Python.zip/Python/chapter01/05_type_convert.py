# 타입 변환(casting)

# int(문자열): 문자열을 정수로 변환
price_str = '20000'
price_int = int(price_str)
print(price_int + 10000)

# str(정수 & 실수): 정수 또는 실수를 문자열로 변환
rate_float = 0.15
rate_str = str(rate_float)
print('할인율: ', rate_str + '%')

# bool(문자열): 문자열을 불로 변환
is_valid = 'True'
is_valid = bool(is_valid)
print(type(is_valid))

# 자동 형변환
total = 100 + 3.14
print(total)
print(type(total))

# 문자열 + 숫자는 파이썬에서 불가능
# count = 10 + '20'
# print(count)