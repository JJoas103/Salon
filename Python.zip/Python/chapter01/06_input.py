# input(): 사용자 입력 받기

name = input('이름을 입력하세요: ')
print(f'안녕하세요 {name}님')

# 항상 문자열만 반환
age = input('나이를 입력하세요: ')
print(type(age))    # <class 'str'>
print(int(age) + 1)
