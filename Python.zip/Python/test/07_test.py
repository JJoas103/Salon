'''
[문제 1] import math
  math.sqrt(16), round(math.pi, 4) 출력
'''
import math
print('sqrt(16)', math.sqrt(16))
print('round(math.pi, 4)', round(math.pi))
  
'''
[문제 2] from math import
  floor(3.9), ceil(3.1) 출력
'''
from math import floor, ceil

print(floor(3.9))
print(ceil(3.1))
'''
[문제 3] 사용자 모듈
  chapter07/my_utils.py 의 add, greet, discount_price 사용
  add(3, 5), greet("솔데스크"), discount_price(10000, 0.1) 출력
'''
import my_utils as mu

print('add: ', mu.add(2, 3))
print('greet: ', mu.greet('솔데스크'))
print('discount: ', mu.discount_price(10000, 0.1))

'''
[문제 4] json
  data = {"name": "홍길동", "age": 20}
  json.dumps → json.loads 왕복 후 name 값 출력
'''
import json

data = {'name' : '홍길동', 'age' : 20}  
json_str = json.dumps(data, ensure_ascii=False)
restored = json.loads(json_str)
print('name:', restored['name'])

'''
[문제 5] pathlib
  Path(__file__).name, .suffix, .stem 출력
'''

from pathlib import Path
p = Path(__file__)
print('파일명: ', p.name)
print('확장자: ', p.suffix)
print('이름:', p.stem)