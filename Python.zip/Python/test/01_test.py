'''
[문제 1] 변수와 f-string
  name="홍길동", age=20, height=175.5 변수를 만든 뒤
  f-string으로 "이름: 홍길동, 나이: 20, 키: 175.5" 를 출력하세요.
'''
name="홍길동"
age=20
height=175.5
print(f'이름: {name}, 나이: {age}, 키: {height}')
'''  
[문제 2] 정수·실수 계산
  quantity=3, unit_price=19900 일 때
  total(합계)과 rate=0.15 할인액 discount를 구해 출력하세요.
  (total은 int, discount는 float)
'''
quantity=3
unit_price=19900
total = quantity * unit_price
rate = 0.15
discount = total * rate
print('합계: ', total)
print('할인액: ', discount)

'''
[문제 3] 문자열 다루기
  text = "  hello python  " 를 strip() 후 upper()로 바꾸고,
  "PYTHON"을 "WORLD"로 replace()한 결과를 출력하세요.
'''
text = "  hello python  "
result = text.strip().upper().replace('PYTHON', 'WORLD')
print(result)

'''
[문제 4] 타입 변환
  price_str = "25000" 을 int로 변환해 5000을 더한 값을 출력하세요.
'''
price_str = '25000'
price = int(price_str)
print(price + 5000)