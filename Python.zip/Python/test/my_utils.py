def add(a, b):
    return a + b

def greet(name):
    return f'{name}님 안녕하세요'

def discount_price(price, rate):
    return price - (price * rate)