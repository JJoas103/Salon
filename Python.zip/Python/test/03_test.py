'''
[문제 1] 리스트
  fruits = ["사과", "바나나", "체리"]
  append("포도") 후, 인덱스 1을 "블루베리"로 바꾸고,
  슬라이싱 fruits[1:3] 결과를 출력하세요.
'''
fruits = ["사과", "바나나", "체리"]
fruits.append('포도')
fruits[1] = '블루베리'
print(fruits[1:3])

'''
[문제 2] 리스트 메서드
  numbers = [3, 1, 4, 1, 5] 를 sort() 후 len()을 출력하세요.
'''
numbers = [3, 1, 4, 1, 5]
numbers.sort()
print(numbers)
print(len(numbers))
'''  
[문제 3] 튜플 언패킹
  point = (10, 20) 을 x, y 두 변수로 언패킹하고 x+y를 출력하세요.
'''
point = (10, 20)
x, y = point
print(x + y)

'''
[문제 4] 딕셔너리
  product = {"name": "무선 이어폰", "price": 89000, "in_stock": True}
  get("discount", 0) 값, price를 79000으로 수정,
  items()로 "name: 무선 이어폰" 형식 한 줄을 출력하세요.
'''
product = {"name": "무선 이어폰", "price": 89000, "in_stock": True}
print('discount: ', product.get('discount', 0))
product['price'] = 79000
print('price: ', product.get('price'))
for key, value in product.items():
    print(f'{key} : {value}')

'''
[문제 5] 집합
  items = ["사과", "바나나", "사과", "체리"] 에서
  set으로 중복을 제거한 뒤 list로 바꿔 출력하세요.
'''
items = ["사과", "바나나", "사과", "체리"]
unique = list(set(items))
print(unique)

'''
[문제 6] 혼합 — 중첩 리스트
  matrix = [[1, 2], [3, 4]] 에서 두 번째 행의 첫 번째 값을 출력하세요.
'''
matrix = [[1, 2], [3, 4]]
print(matrix[1][0])
