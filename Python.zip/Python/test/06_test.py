'''
[문제 1] 클래스 기본
  Dog 클래스에 bark(self) 메서드 → "멍멍!" 반환
  dog = Dog() 생성 후 bark() 호출
'''
class Dog:
    def bark(self):
        return '멍멍!'
dog = Dog()
print(dog.bark())
  
'''
[문제 2] 생성자
  Student(name, age) 클래스, introduce() → "이름: 홍길동, 나이: 25세"
  Student("홍길동", 20) 생성 후 introduce() 출력
'''
class Student:
  def __init__(self, name, age):
   self.name = name
   self.age = age

  def intoduce(self):
    return f'이름: {self.name}, 나이:{self.age}'

s1 = Student('홍길동', 20)
print(s1.intoduce())

'''
[문제 3] BankAccount
  __init__(owner, balance=0), deposit(amount), withdraw(amount)
  잔액 10000에서 5000 입금, 3000 출금 후 info() 출력
'''
class BankAccount:
    def __init__(self, owner, balance=0):
      self.owner = owner
      self.balance = balance

    def deposit(self, amount):
      self.balance += amount

    def withdraw(self, amout):
      if amout > self.balance:
         return '잔액부족'
      self.balance -= amout

    def info(self):
      print(f'{self.owner}님의 잔액 : {self.balance}원')

account = BankAccount('홍길동', 10000)
account.deposit(5000)
account.withdraw(3000)
account.info()

'''
[문제 4] Product
  sell(quantity): 재고 차감 + "OOO N개 판매, 합계 XXX원" 반환
  재고 5개인 Product("무선 이어폰", 89000, 5)에서 sell(2) 호출
'''

class Product:
   def __init__(self, name, price, stock):
      self.name = name
      self.price = price
      self.stock = stock

   def sell(self, quantity):
      self.stock -= quantity
      total = self.price * quantity
      return f'{self.name} {quantity}개 판매, 합계 {total}원'
   
   def __str__(self):
      return f'{self.name}, 재고 {self.stock}개'

earphone = Product("무선 이어폰", 89000, 5)
earphone.sell(2)
print(earphone)
      