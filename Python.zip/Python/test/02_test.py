'''
[문제 1] 산술 연산
  a=17, b=5 일 때 몫(//), 나머지(%), 거듭제곱(**)을 각각 출력하세요.
'''
a=17
b=5
print('몫: ', a//b)
print('나머지: ', a%b)
print('거듭제곱: ', a**b)
'''
[문제 2] 비교·논리 연산
  original=50000, sale=35000 일 때
  "할인가가 3만 이상 4만 이하인가?" 를 and로 판별해 True/False로 출력하세요.
'''
original=50000
sale=35000
in_range = sale >= 30000 and sale <= 40000
print('3만에서 4만 사이?: ', in_range)

'''
[문제 3] in 연산자
  keyword="무신사" 에서 "신"이 포함되어 있는지 in으로 확인하세요.
'''
keyword = '무신사'
print("'신 in keyword:'", '신' in keyword)
  
'''
[문제 4] 할당 연산자
  count=0 에서 +=1, *=3 을 차례로 적용한 최종 count를 출력하세요.
  (0 → 1 → 3)
'''
count = 0
count += 1
count *= 3
print('count: ', count)