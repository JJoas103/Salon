'''
[문제 1] 함수 정의
  greet(name) 함수: "안녕하세요, {name}님!" 반환
  calc(a, b) 함수: 더하기, 빼기, 곱하기 튜플 반환
'''
def greet(name):
    return f'안녕하세요, {name}님'

print(greet('홍길동'))

def calc(a, b):
    return a+b, a-b, a*b

print(calc(10, 3))

'''
[문제 2] 기본값·키워드 인자
  order(item, quantity=1, price=0) → (item, quantity, total) 반환
  order("키보드", price=45000) 호출 결과 출력
'''
def order(item, quantity=1, price=0):
    total = quantity * price
    return item, quantity, total
print(order('키보드', price=45000))

'''
[문제 3] *args
  total(*prices) 함수: 전달된 가격들의 합계 반환
  total(1000, 2000, 3000) → 6000
'''
def total(*prices):
    return sum(prices)
print(total(1000, 2000))

'''
[문제 4] map / filter / lambda
  numbers = [1, 2, 3, 4, 5]
  map으로 제곱 리스트, filter로 짝수 리스트를 만드세요.
'''
# def test(x):
#     return x**2

numbers = [1, 2, 3, 4, 5]
squared = list(map(lambda x:x**2, numbers))
print('제곱": ', squared)

# def test(x):
#   if x%2==0:
#       return x

evens = list(filter(lambda x: x%2, numbers))
print('짝수: ', evens)

'''
[문제 5] global
  counter=0, increment() 함수에서 global로 1씩 증가
  increment()를 두 번 호출 후 counter 출력 → 2
'''
counter = 0

def increment():
    global counter
    counter+= 1
  
increment()
increment()
print(counter)

'''
[문제 6] 타입 힌트
  double(x: int) -> int 함수를 작성하고 double(5) 결과 출력
'''
def double(x: int) -> int:
    return x * 2

print("double(5)", double(5))
