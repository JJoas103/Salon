'''
[문제 1] if / elif / else
  score=85 일 때 등급을 구하세요.
  90 이상 A, 80 이상 B, 60 이상 C, 미만 F (01_if.py 참고)
'''
score = 85
if score >= 90:
    grade = 'A'
elif score >= 80:
    grade = 'B'
elif score >= 60:
    grade = 'C'
else:
    grade = 'F' 
print(f'점수: {score} -> 등급: {grade}')
'''
[문제 2] 삼항 연산자
  price=45000, budget=50000 일 때
  label 변수에 "구매 가능" 또는 "구매 불가"를 한 줄로 넣으세요.
'''
price=45000
budget=50000
label = '구매가능' if price <= budget else '구매불가'
print(label)

'''
[문제 3] for + range
  range(1, 6)으로 1부터 5까지 한 줄에 출력하세요. (end=" ")
'''
for i in range(1, 6):
    print(i)

'''
[문제 4] enumerate
  fruits = ["사과", "바나나", "체리"]
  "0: 사과" 형식으로 각 줄을 출력하세요.
'''
fruits = ["사과", "바나나", "체리"]
for idx, fruit in enumerate(fruits):
  print(f'{idx}: {fruit}')

'''
[문제 5] while
  stock=3, sold=0 에서 재고가 0이 될 때까지
  sold를 1씩 늘리고 stock을 1씩 줄이세요.
  마지막 sold 값을 출력하세요.
'''
stock = 3
sold = 0
while stock > 0:
  stock -= 1
  sold += 1
print(sold)

'''
[문제 6] break / continue
  range(10)에서 5가 되면 break로 멈추기 전까지 출력: 0 1 2 3 4
  range(5)에서 짝수는 continue로 건너뛰고 홀수만 출력: 1 3
'''
for i in range(10):
   if i == 5:
      break
   print(i)
  
for i in range(5):
   if i % 2 == 0:
      continue
   print(i)
