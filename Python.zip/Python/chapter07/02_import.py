# import

import datetime as dt

now = dt.datetime.now()
print('오늘, ', now)

# from 모듈 import 이름: 모듈에서 특정 함수, 변수만 가져옴
from math import floor, ceil, pi

print('반내림 함수: ', floor(3.9))
print('반올림 함수: ', ceil(3.1))
print('원주율: ', pi)
