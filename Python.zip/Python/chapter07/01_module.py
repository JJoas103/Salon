# 모듈

import math # 모듈 전체 가져오기
# math: 파이썬이 제공하는 표준라이브러리

print('모듈 이름: ', math.__name__)
print('제곱근: ', math.sqrt(25))
print('원주율: ', math.pi)

import my_utils

print('모듈 이름: ', my_utils.__name__)
print(my_utils.add(3, 2))