from pathlib import Path
from bs4 import BeautifulSoup

html = (Path(__file__).parent/'sample'/'shop.html').read_text(encoding='utf-8')
soup = BeautifulSoup(html, 'html.parser')

h1 = soup.find('h1', class_='shop-title')
# 1) string: 직계 자식이 텍스트가 하나면 반환
print('1) h1.string: ', h1.string)

article = soup.find('article', class_='product')
# 2) string: 자식 태그가 많으면 None
print('2) article.string: ', article.string)

# 3) get_text(): 직계 텍스트 뿐만 아니라 자식 태그의 텍스트까지 가져옴(줄바꿈 포함)
print('3) article.get_text(): ', article.get_text(strip=True))
print('4) article.get_text(): ', article.get_text(separator=' , ', strip=True))

print('기모 후드티의 가격: ', article.find('p', class_='price').get_text(strip=True))