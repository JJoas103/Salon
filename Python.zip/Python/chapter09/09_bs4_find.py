from pathlib import Path
from bs4 import BeautifulSoup

html = (Path(__file__).parent/'sample'/'shop.html').read_text(encoding='utf-8')
soup = BeautifulSoup(html, 'html.parser')

# 1) 태그 이름으로
# find(조건): 조건이 맞는 하나의 태그 가져오기
first_a = soup.find('a')
print('find 첫 a태그: ', first_a.get_text(),' -> ' ,first_a['href'])

# find_all(조건): 조건이 일치하는 모든 태그를 리스트 형태로 가져오기
# limit=n: 특정 태그 최대 n까지 리스트로 반환
all_product = soup.find_all('article', class_='product', limit=2)
print('find_all 상품 개수: ', len(all_product))

# 2) id로 찾기
main = soup.find(id='main')
print('main 안 section의 클래스 값: ', main.find('section')['class'])

# 3) 여러 class: sale article만 가져오기
sale_items = soup.find_all('article', class_='sale')
print('find_all 세일 상품 개수: ', len(sale_items))
for item in sale_items:
    print(item.find('h2').get_text(strip=True))

# 4) 상품 가격만 추출해 리스트 만들기
p_all = soup.find_all('p', class_='price')
print(p_all)
print('상품의 가격 들: ',[p.get_text() for p in p_all])
