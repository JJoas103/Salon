from pathlib import Path

html_path = Path(__file__).parent/'sample'/'cafe_menu.html'
html = html_path.read_text(encoding='utf-8')
# read_text(): 파일 내용을 문자열로 읽어오기

print(html[:300])