from pathlib import Path
from bs4 import BeautifulSoup, Tag

sample_path = Path(__file__).parent/'sample'/'shop.html'
html = sample_path.read_text(encoding='utf-8')

# BeautifulSoup 객체 생성
soup = BeautifulSoup(html, 'html.parser')

# find_all(): 찾고자할 태그를 전부 리스트로 반환
print(soup.find_all('h2'))

# prettify(): 들여쓰기된 HTML(구조 확인 용)
print(soup.prettify()[:400])

# find(): 조건에 맞는 첫 태그 1개 반환
print(soup.find('h2'))

# Tag 확인
h1 = soup.find('h1')
print('is Tag', isinstance(h1, Tag))
h1_string = h1.string
print('is Tag', isinstance(h1_string, Tag))
