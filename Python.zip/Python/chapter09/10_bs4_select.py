from pathlib import Path
from bs4 import BeautifulSoup

html = (Path(__file__).parent/'sample'/'shop.html').read_text(encoding='utf-8')
soup = BeautifulSoup(html, 'html.parser')

# 1) select() == find_all
names = soup.select('h2.name')
print('상품명: ', [h2.get_text(strip=True) for h2 in names])

# 2) select_ond == find
main = soup.select_one('#main')
print('존재: ', main is not None)

# 3) 후손 선택
prices = soup.select('article.product .price')
print('가격: ', [price.get_text(strip=True) for price in prices])

# 4) 직계 자식 선택
nav_links = soup.select('nav.menu > a')
print('링크: ', [a.get_text(strip=True) for a in nav_links])

# 5) 복합 클래스
sale = soup.select('article.product.sale')
print('세일상품: ', sale[0].select_one('.name').get_text())