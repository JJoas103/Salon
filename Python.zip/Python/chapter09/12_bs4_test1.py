from pathlib import Path
from bs4 import BeautifulSoup

html = (Path(__file__).parent/'sample'/'shop.html').read_text(encoding='utf-8')
soup = BeautifulSoup(html, 'html.parser')
'''
=== 1. find / find_all ===
첫 상품: 기모 후드티
상품 수: 3
'''
print('첫 상품: ', soup.find('h2', class_='name').get_text(strip=True))
print('상품 수: ', len(soup.find_all('article', class_='product')))
'''
=== 2. select  ===
  - 기모 후드티
  - 솔데스크 머그컵
  - 노트북 스티커
'''
print('-'*30)

names = soup.select('h2.name')
for name in names:
    print(f'{name.get_text(strip=True)}')

'''
=== 3. get_text ===
  가격: 39,000원
  가격: 15,000원
  가격: 3,000원
'''
print('-'*30)
prices = soup.select('p.price')
for price in prices:
    print(f'{price.get_text(strip=True)}')

'''
=== 4. attrs (href, data-id) ===
  [101] 기모 후드티 -> /products/101
  [102] 솔데스크 머그컵 -> /products/102
  [103] 노트북 스티커 -> /products/103
'''
print('-'*30)
articles = soup.select('article.product')
for article in articles:
    id = article['data-id']
    link = article.select_one('a.detail-link')['href']
    title = article.select_one('h2.name').get_text(strip=True)
    print(f'[{id}] {title} -> {link}')

'''
=== 5. parent ===
price 부모 태그: article
price 부모 data-id: 101
'''
print('-'*30)
price = soup.select_one('p.price')
print('price 부모 태그: ', price.parent.name)
print('price 부모 태그: ', price.parent.get('data-id'))
