import time
import requests

HEADERS = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
           "Referer" : "https://finance.daum.net/"}

API_URL = 'https://finance.daum.net/api/search/ranks'

time.sleep(1.0)
response = requests.get(API_URL, headers=HEADERS, params={'limit':10}, timeout=15)

rows = []

# json(): JSON 응답을 딕셔너리로 변환
for item in response.json().get('data', []):
    rows.append({
        "rank" : item.get('rank'),
        "name" : item.get('name'),
        "price" : item.get('tradePrice')
    })

print(f'다음 인기 종목: {len(rows)}건')

for row in rows:
    print(f'{row["rank"]}.{row["name"]}: {row["price"]}')