# requests - params, headers

import requests
HEADERS = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
}

url = 'https://postman-echo.com/get'    # API 테스 사이트
params = {'keyword' : '파이썬', 'page' : 1} # 쿼리파라미터를 담을 딕셔너리

response = requests.get(url, params=params, headers=HEADERS, timeout=10)

print('요청 url: ', response.url)
print('상태코드: ', response.status_code)

# .ok: 상태코드가 200이면 True(요청 성공 여부 확인)
if response.ok:
    data = response.json()  # json(): 서버 응답이 json일 때만 유효
    print('서버가 받은 params:', data['args'])

