# 네이버 금융

import requests
import time
from bs4 import BeautifulSoup

HEADERS = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",}
KOSPI_INDEX_URL = 'https://finance.naver.com/sise/sise_index.naver?code=KOSPI'

time.sleep(1.0)
response = requests.get(KOSPI_INDEX_URL, headers=HEADERS, timeout=15)
response.encoding = 'euc-kr'
soup = BeautifulSoup(response.text, 'html.parser')

print('===코스피 지수===')
now = soup.select_one('#now_value').get_text(strip=True)
print('현재: ', now)
change = soup.select_one('#change_value_and_rate').get_text(strip=True)
print('등락: ', change)

# 시가 총액(상위 종목 - 1페이지)
KOSPI_STOCK_URL = 'https://finance.naver.com/sise/nxt_sise_market_sum.naver'
time.sleep(1.0)
response = requests.get(KOSPI_STOCK_URL, headers=HEADERS, timeout=15)
response.encoding = 'euc-kr'
soup = BeautifulSoup(response.text, 'html.parser')

stocks= []
table = soup.select_one('table.type_2')
trs = table.select('tr')
# print(trs[0:5])
for tr in trs:
    tds = tr.select('td')

    if len(tds) < 10:
        continue

    title = tds[1].select_one('a').get_text(strip=True)
    price = tds[2].get_text(strip=True)
    change = tds[3].select_one('span').get_text(strip=True)
    stocks.append({
        'title' : title,
        'price' : price,
        'change' : change
    })
   
for stock in stocks:
    print(f'{stock["title"]} | {stock["price"]}')