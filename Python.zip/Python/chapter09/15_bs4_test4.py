import requests
from bs4 import BeautifulSoup

HEADERS = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",}
URL = 'https://quotes.toscrape.com/'

response = requests.get(URL, headers=HEADERS, timeout=10)
soup = BeautifulSoup(response.text, 'html.parser')

div_quotes = soup.select('div.quote')
quotes = []

for block in div_quotes:
    quotes.append({
        "text" : block.select_one('span.text').get_text(strip=True),
        "author" : block.select_one('small.author').get_text(strip=True),
        "tags" : [tag.get_text(strip=True) for tag in block.select_one('div.tags').select('a.tag')]
    })

print(f'인용구 {len(quotes)}개')
for quote in quotes:
    print(f'명언: {quote["text"]} / 저자: {quote["author"]} / 태그: {", ".join(quote["tags"])}')