# 도서 목록

from pathlib import Path
from bs4 import BeautifulSoup

html = (Path(__file__).parent/'sample'/'book_list.html').read_text(encoding='utf-8')
soup = BeautifulSoup(html, 'html.parser')

books = []
trs = soup.select('table#books tr')

for tr in trs:
    td_title = tr.select_one('td.title')
    if not td_title:
        continue
    title = td_title.get_text(strip=True)
    author = tr.select_one('td.author').get_text(strip=True)
    price = tr.select_one('td.price').get_text(strip=True)

    books.append({
                    'title': title, 
                    'author' : author,
                    'price' : price
                  })

print('==추천도서==')
for i, book in enumerate(books, 1):
    print(f"{i}.{book['title']} / {book['author']} / {book['price']}")
