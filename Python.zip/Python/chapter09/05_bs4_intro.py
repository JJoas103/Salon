# BeautifulSoup
# HTML/XML 등 정적인 문서를 파싱해서, 원하는 데이터를 추출하는 라이브러리
# 설치: pip install beautifulsoup4

from pathlib import Path
from bs4 import BeautifulSoup, Tag

sample_path = Path(__file__).parent/'sample'/'cafe_menu.html'
html = sample_path.read_text(encoding='utf-8')

soup = BeautifulSoup(html, 'html.parser')
# BeautifulSoup(): HTML 문자열을 파싱해 Soup 트리 객체 생성

print('타입: ', type(soup))
print('문서 제목: ', soup.title.string) # .string: 태그 안 텍스트

print('-' * 20)
print('body 태그: ', soup.body.name) # .name: 태그 이름
print('h1 태그의 내용, ', soup.h1.string)