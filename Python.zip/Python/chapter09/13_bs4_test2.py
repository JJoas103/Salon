from pathlib import Path
from bs4 import BeautifulSoup

html = (Path(__file__).parent/'sample'/'cafe_menu.html').read_text(encoding='utf-8')
soup = BeautifulSoup(html,'html.parser')

print('===솔데스크 카페 메뉴===')
menus = soup.select('li.menu-item')

for li in menus :
    name = li.select_one('span.name').get_text(strip=True)
    price = li.select_one('span.price').get_text(strip=True)
    print(f'{name} : {price}')