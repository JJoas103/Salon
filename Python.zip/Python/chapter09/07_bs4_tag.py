from pathlib import Path
from bs4 import BeautifulSoup

html = (Path(__file__).parent/'sample'/'shop.html').read_text(encoding='utf-8')
soup = BeautifulSoup(html, 'html.parser')

print('==HTML 원본==')
print(soup.prettify())
print('-'*30)

# find(): 조건에 맞는 첫 태그를 반환
article = soup.find('article', class_='product')
print('1) 태그 이름: ', article.name)

# attrs: 속성 전체 가져오기(딕셔너리)
print('2-1) 속성: ', article.attrs)
# tag['키']: 속성값 직접 접근
print('2-2) data-id: ', article['data-id'])
# .get(): 속성값 안전하게 조회(없으면 None 반환)
print('2-3) href: ', article.get('href'))


# parent: 부모 태그
price = soup.find('p', class_='price')
print('price의 부모: ', price.parent.name)
print('price의 부모의 속성: ', price.parent.get('class'))

# child: 자식 태그(직계 자식 노드)
for child in article.children:
    if child.name:
        print(f' - {child.name}')

# sibling: 형제 태그(같은 레벨 옆 태그)
# select_one(): CSS 선택자로 태그 반환
first_product = soup.select_one('article.product')
# find_next_sibling(): 다음 형제 중 1개의 태그를 반환
second_product = first_product.find_next_sibling('article')
print('두번째 상품명: ',second_product.select_one('h2.name').get_text(strip=True))
