# requests 모듈: 웹 페이지를 가져오는 라이브러리
# 설치: pip install requests

import requests

# GET 요청
url = 'https://quotes.toscrape.com/'
response = requests.get(url, timeout=10)
# timeout: 시간제한

print('상태코드: ', response.status_code) # 200이면 성공, 404 없음, 500이면 서버오류
print('글자 수: ', response.text) #HTML 문자열
