from pathlib import Path
from bs4 import BeautifulSoup

html = (Path(__file__).parent/'sample'/'shop.html').read_text(encoding='utf-8')
soup = BeautifulSoup(html, 'html.parser')

# 링크 수집
menu = soup.select_one('nav.menu')
a_all = menu.select('a')
for a in a_all: 
    text = a.getText(strip=True)
    # get('속성'): 속성 값 반환
    href = a.get('href')
    print(f'{text} : {href}')

# 이미지
imgs = soup.select('img')
for img in imgs:
    src = img.get('src')
    alt = img.get('alt')
    print(f'{src}, {alt}')

# has_attr(): 속성 여부 확인
article = soup.select_one('article.sale')
print('class 속성 여부: ', article.has_attr('class'))
print('style 속성 여부: ', article.has_attr('style'))