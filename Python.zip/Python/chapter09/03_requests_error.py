import requests

URL = 'https://quotes.toscrape.com/'
HEADERS = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
}
# 성공
response = requests.get(URL, headers=HEADERS, timeout=10)
if response.ok:
    print('HTML 받기 성공(길이): ', len(response.text))
else:
    print('실패', response.text[:100])

# 실패 > 예외처리
try:
    bad_response = requests.get(URL+'/no-such-page-xyz', headers=HEADERS, timeout=10)
    print('404 테스트 code', bad_response.status_code)  
    bad_response.raise_for_status()
    # raise_for_status(): 4xx/5xx이면 requests.HTTPError 예외 발생

except requests.HTTPError as e:
    print('HTTPError', e)