# 연습 3) quotes.toscrape.com — 인용구 출력
# quotes.toscrape.com (인터넷 연결 필요)
# chapter09/12_static_web.py 복습
#
# === requests / BeautifulSoup 치트시트 ===
# requests.get(url, headers=, timeout=) — GET 요청
# response.raise_for_status()           — 실패 시 예외
# response.text                         — HTML 문자열
# BeautifulSoup(text, "html.parser")    — HTML → Soup
# soup.select("div.quote")              — 인용구 블록 전부
# block.select_one("span.text")         — 인용문 1개
# block.select("a.tag")                 — 태그 링크 전부

import requests
from bs4 import BeautifulSoup

HEADERS = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36",
}
URL = "https://quotes.toscrape.com/"

# requests.get() — headers·timeout과 함께 GET 요청
response = requests.get(URL, headers=HEADERS, timeout=10)
# .raise_for_status() — 4xx/5xx이면 HTTPError 발생
response.raise_for_status()
# BeautifulSoup() — response.text(HTML)를 파싱
soup = BeautifulSoup(response.text, "html.parser")

quotes = []
# select() — div.quote 인용구 블록 전부
for block in soup.select("div.quote"):
    quotes.append({
        # select_one() — span.text 1개 / .get_text() — 인용문
        
        "text": block.select_one("span.text").get_text(strip=True),
        # select_one() — small.author 1개 / .get_text() — 저자
        "author": block.select_one("small.author").get_text(strip=True),
        # select() — a.tag 전부 / .get_text() — 태그명 리스트
        "tags": [t.get_text(strip=True) for t in block.select("a.tag")],
    })

print(f"=== 인용구 {len(quotes)}개 ===\n")
for q in quotes[:5]:
    print(f"  \"{q['text'][:40]}...\"")
    print(f"   - {q['author']}")
    print(f"   - 태그: {', '.join(q['tags'])}")
    print()

# select_one() — li.next a 1개 / ["href"] — 다음 페이지 경로
next_link = soup.select_one("li.next a")
if next_link:
    print("다음 페이지:", next_link["href"])
