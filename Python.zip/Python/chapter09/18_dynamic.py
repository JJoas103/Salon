import requests
from bs4 import BeautifulSoup

HEADERS = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"}
URL = 'https://quotes.toscrape.com/js'

response = requests.get(URL, headers=HEADERS, timeout=10)
soup = BeautifulSoup(response.text, 'html.parser')
print(soup.prettify)
# ctrl + U : 데이터가 보이면 정적페이지, 없으면 동적페이지

