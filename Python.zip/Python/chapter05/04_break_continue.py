# break, continue, pass, for-else

# break: 반복문 종료
for n in range(10):
    if n == 5:
        break
    print(n, end=' ')
print()

# continue: 현재 반복문 중단하고 다음 반복문 시작
for n in range(5):
    if n % 2 == 0:
        continue
    print(n, end=' ') # 1 3
print()

# for-else: break 없이 루프가 끝나면 else 실행
for n in range(3):
    print(n,  end=' ')
else:
    print()
    print('반복종료')