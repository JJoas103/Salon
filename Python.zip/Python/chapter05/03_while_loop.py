# 반복문 - while문

count = 0

while count < 3:
    print(f'conut: {count}')
    count += 1
