# 반복문 - for문

fruits = ['사과', '바나나', '수박']

# for 변수 in 리스트/문자열등: 리스트, 문자열 등을 순회
for fruit in fruits:
    print(fruit)

print('-'* 30)

# range(n): 0부터 n-1까지 순회
for i in range(5):
    print(i, end=' ')

print('\n' + '-'* 30)

# range(start, stop): start부터 stop-1까지 순회 
for i in range(1, 6):
    print(i, end= ' ')

print('\n' + '-'* 30)

# range(start, stop, step): start부터 stop-1까지 순회  step 만큼 증가
for i in range(1, 6, 2):
    print(i, end= ' ')

print('\n' + '-'* 30)

# enurate(): 인덱스와 값을 받아 순회
for idx, fruit in enumerate(fruits):
    print(idx, fruit)