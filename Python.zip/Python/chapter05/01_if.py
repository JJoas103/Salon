# 조건문 - if문

price = 45000
budget = 50000

# 기본 if문
if price <= budget:
    print('구매 가능')
elif price <= budget * 1.2:
    print('예산 초과 - 할인 기다리기')
else:
    print('구매 불가능')

# 삼항연산자
label = '구매 가능' if price <= budget else '구매 불가'
print(label)

# 중첩 if 문
score = 85
if score >= 60:
    if score >= 90:
        grade = 'A'
    elif score >= 80:
        grade = 'B'
    else:
        grade = 'C'
else:
    grade = 'F'
print(f'점수: {score} -> 등급: {grade}')