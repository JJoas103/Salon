from pathlib import Path
from bs4 import BeautifulSoup
from selenium import webdriver
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
import re
import time
import requests
import pandas as pd

# 설정값
URL = 'https://www.musinsa.com/brand/musinsastandard/products?gf=A'
TARGET_COUNT = 5
HEADERS = {                              # 사진 다운로드용 User-Agent (chapter09 매너)
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                  "AppleWebKit/537.36 (KHTML, like Gecko) "
                  "Chrome/125.0 Safari/537.36"
}
BASE_DIR = Path(__file__).parent
OUTPUT_DIR = BASE_DIR/'output'  # csv 저장 폴더
IMAGE_DIR = BASE_DIR/'images'   # 이미지 저장 폴더

OUTPUT_DIR.mkdir(exist_ok=True)
IMAGE_DIR.mkdir(exist_ok=True)

def parse_cards(html: str) -> dict[str, dict]:
    # 현재 화면(HTML)에서 상품 정보를 뽑아 {상품ID: 상품정보 딕셔너리} 딕셔너리로 반환
    soup = BeautifulSoup(html, 'html.parser')
    cards: dict[str, dict] = {}
    a_list = soup.select('a[data-item-id]')
    for a in a_list:
        item_id = a.get('data-item-id')
        img = a.select_one('img')

        # 사진없는 링크는 건너뛰기
        if not item_id or img is None:
            continue
        
        # 상품ID가 이미 있으면 건너뜀
        if item_id in cards:
            continue

        # 상품의 정보를 딕셔너리로 저장
        cards[item_id] = {
            '상품ID' : item_id,
            '상품명' : (img.get('alt') or '').strip(),
            '가격': a.get('data-price'),
            '정상가': a.get('data-original-price'),
            '할인율' : f'{a.get("data-discount-rate") or 0}%',
            '상품URL' : a.get('href') or '',
            '사진URL' : img.get('src') or ''
        }
        '''
        {
            1001:{상품ID: 1001, 상품명: 아디다스, 가격: 2000},
            1002:{상품ID: 1001, 상품명: 나이키, 가격: 2000},
        }   
        '''
    return cards

def collect_products(url: str, target: int) -> list[dict]:
    # 하나의 상품의 정보를 담은 딕셔너리를 모은 리스트 반환
    options = Options()
    options.add_argument("--headless=new")         
    options.add_argument("--disable-gpu")
    options.add_argument("--window-size=1920,3000")
    options.add_argument(f"user-agent={HEADERS['User-Agent']}")

    driver = webdriver.Chrome(options=options)
    collected: dict[str, dict] = {}
    '''
    {
        1001:{상품명: 아디다스, 가격: 2000},
        1002:{상품명: 나이키, 가격: 2000},
    }
    '''
    try:
        driver.get(url)
        WebDriverWait(driver, 15).until(
            EC.presence_of_element_located((By.CSS_SELECTOR, 'a[data-item-id]'))
        )
        stall = 0
        y = 0

        while(len(collected) < target):
            # 현재 렌더링된 HTML을 파싱해서 딕셔너리로 가져오기
            new_cards = parse_cards(driver.page_source)

            before = len(collected)

            # 새 상품을 누적
            for item_id, info in new_cards.items():
                if item_id not in collected:
                    collected[item_id] = info

            # 수집한 상품개수와 이전 루프에서 수집한 상품개수가 다르면 새 상품을 파싱했다는 것이므로 카운트 초기화
            if len(collected) != before:
                print(f'스크롤 내리는 중...누정{len(collected)}개 상품 수집')
                stall = 0
            else:
                # 새 상품이 없을 때 카운트 증가
                stall += 1
                if stall >= 5:
                    print('더 이상 새 상품이 없습니다(마지막 페이지)')
                    break
            
            # 화면을 내림
            y += 1500
            driver.execute_script(f'window.scrollTo(0, {y})')
            time.sleep(0.9)

            # 수집한 정보를 딕셔너리 리스트로 정리
            products: list[dict] = []
            for info in collected.values():
                번호 = len(products) + 1
                사진파일 = f'{번호:03d}_{info["상품ID"]}.jpg'
                products.append({
                    '번호': 번호,
                    '상품ID': info['상품ID'],
                    '상품명' : info['상품명'],
                    '가격' : info['가격'],
                    '정상가' : info['정상가'],
                    '할인율' : info['할인율'],
                    '사진파일' : 사진파일,
                    '상품URL' : info['상품URL'],
                    '사진URL' : info['사진URL']
                })
            if len(products) >= target:
                break
        return products
    
    finally: 
        driver.quit()

# csv 저장
def save_csv(products: list[dict]) -> Path:
    df = pd.DataFrame(products)
    csv_path = OUTPUT_DIR/'musinsa_proudcts.csv'
    df.to_csv(csv_path, index=False, encoding='utf-8-sig')
    print('csv 저장완료')
    return csv_path

# 이미지 저장
def download_images(products:list[dict])->None:
    print(f'사진 다운로드 시작 {len(products)}')
    for proudct in products:
        if not proudct['사진URL']:
            continue
        try:
            res = requests.get(proudct['사진URL'], headers=HEADERS, timeout=10)
            res.raise_for_status() # 실패 시 예외
            (IMAGE_DIR/proudct['사진파일']).write_bytes(res.content) # 사진 저장
            print(f'{proudct["사진파일"]} 저장')
        except Exception as e:
            print('실패')
        time.sleep(0.3)

# 메인
def main() -> None:
    print('1. 페이징 로딩 및 상품 수집')
    products = collect_products(URL, TARGET_COUNT)
    print(f'상품: {len(products)}개 수집완료')

    print('2. 사진 다운로드')
    #이전에 가져온 사진 정리
    for old in IMAGE_DIR.glob('*.jpg'):
        old.unlink()
        
    download_images(products)

    print('3. CSV 저장')
    save_csv(products)

    print('작업 완료')

# 다른 파일에서 이 파일을 모듈로 호출하면 main() 함수가 즉시 실행되는 것을 방지
if __name__ == '__main__':
    main()