"""무신사 상품 CSV를 검색하고 Ollama로 추천하는 챗봇."""

import re
from pathlib import Path

import pandas as pd
from common_gpt import get_llm

CSV_PATH = Path(__file__).parent / "musinsa_products.csv"
MODEL_NAME = "qwen3:8b"

HELP = """
[질문 예시]
  3만원 이하 티셔츠 추천해 줘
  할인율 높은 바지 3개 보여 줘
  방금 추천한 것 중 두 번째 상품 링크 알려 줘

[명령어]
  도움말 | 목록 | 초기화 | 종료
"""

# 상품명 검색에 필요하지 않은 표현
STOP_WORDS = {
    "추천", "추천해", "추천해줘", "보여", "보여줘", "상품", "제품", "무신사",
    "이하", "이상", "미만", "정도", "안쪽", "가격", "할인", "할인율", "높은",
    "낮은", "가장", "저렴한", "비싼", "원", "만원", "찾아줘", "알려줘",
}

# 이 표현이 있으면 전체 상품이 아닌 직전 검색 결과에서 다시 검색한다.
FOLLOW_UP_WORDS = ("방금", "그중", "그 중", "첫 번째", "두 번째", "링크")


def load_products() -> pd.DataFrame:
    """CSV를 읽고 가격과 할인율을 숫자로 정리한다."""
    products = pd.read_csv(CSV_PATH)

    # 문자열 가격을 숫자로 바꾸고, 바꿀 수 없는 값은 NaN으로 처리한다.
    products["가격"] = pd.to_numeric(products["가격"], errors="coerce")
    products["정상가"] = pd.to_numeric(products["정상가"], errors="coerce")

    # '43%'에서 %를 제거해 정렬 가능한 숫자 43으로 만든다.
    discount_text = products["할인율"].astype(str).str.replace("%", "", regex=False)
    products["할인율숫자"] = pd.to_numeric(
        discount_text, errors="coerce"
    ).fillna(0)

    # 추천에 꼭 필요한 상품명이나 가격이 없는 행은 제외한다.
    return products.dropna(subset=["상품명", "가격"]).copy()


# 상품 검색
def search_products(products: pd.DataFrame, question: str) -> pd.DataFrame:
    """질문을 분석하고 조건에 맞는 상품을 최대 12개 반환한다."""
    search_results = products.copy()

    # '3만원' 또는 '3.5만원'에서 최대 가격을 추출한다.
    max_price = None
    price_match = re.search(r"(\d+(?:\.\d+)?)\s*만\s*원", question)
    if price_match:
        max_price = int(float(price_match.group(1)) * 10_000)
    else:
        # '30,000원' 형태도 처리한다.
        price_match = re.search(r"([\d,]+)\s*원", question)
        if price_match:
            max_price = int(price_match.group(1).replace(",", ""))

    # '30%'에서 최소 할인율 30을 추출한다.
    discount_match = re.search(r"(\d+)\s*%", question)
    min_discount = int(discount_match.group(1)) if discount_match else None

    # 질문에서 한글과 영어 단어만 꺼내고 불필요한 표현을 제거한다.
    words = re.findall(r"[가-힣A-Za-z]+", question.lower())
    keywords = []
    for word in words:
        if len(word) >= 2 and word not in STOP_WORDS:
            keywords.append(word)

    # 질문에서 추출한 가격과 할인율 조건을 차례대로 적용한다.
    if max_price is not None:
        search_results = search_results[search_results["가격"] <= max_price]
    if min_discount is not None:
        search_results = search_results[
            search_results["할인율숫자"] >= min_discount
        ]

    # 키워드 중 하나라도 상품명에 포함된 상품을 찾는다.
    if keywords:
        pattern = "|".join(re.escape(word) for word in keywords)
        # '|': 또는, re.escape(word): 단어를 정규식 패턴으로 변환
        name_matches = search_results[
            search_results["상품명"].str.contains(pattern, case=False, na=False)
        ]
        # 상품명 검색 결과가 없으면 가격·할인율 검색 결과를 유지한다.
        if not name_matches.empty:
            search_results = name_matches

    # 할인 질문은 할인율이 높은 순, 나머지는 가격이 낮은 순으로 정렬한다.
    if "할인" in question:
        search_results = search_results.sort_values(
            ["할인율숫자", "가격"], ascending=[False, True]
        )
    else:
        search_results = search_results.sort_values(
            ["가격", "할인율숫자"], ascending=[True, False]
        )

    return search_results.head(12)

def format_products(products: pd.DataFrame) -> str:
    """검색된 상품 DataFrame을 AI가 읽을 문자열로 바꾼다."""
    lines = []
    for _, product in products.iterrows():
        lines.append(
            f"- 상품ID: {product['상품ID']} | 상품명: {product['상품명']} | "
            f"가격: {int(product['가격']):,}원 | 정상가: {int(product['정상가']):,}원 | "
            f"할인율: {int(product['할인율숫자'])}% | URL: {product['상품URL']}"
        )
    return "\n".join(lines)

# 추천 체인 생성
def create_chain():
    """프롬프트, Ollama 모델, 문자열 파서를 하나의 체인으로 연결한다."""
    from langchain_core.output_parsers import StrOutputParser
    from langchain_core.prompts import ChatPromptTemplate
    from langchain_ollama import ChatOllama

    # 프롬프트 템플릿 생성
    prompt = ChatPromptTemplate.from_messages([
        (
            "system",
            "너는 무신사 상품 추천 상담원이다. 반드시 검색된 상품 정보만 사용한다. "
            "목록에 없는 브랜드, 소재, 색상, 재고는 추측하지 않는다. "
            "상품명, 가격, 할인율, 추천 이유, URL을 포함해 친절하게 답한다.",
        ),
        (
            "human",
            "[최근 대화]\n{history}\n\n"
            "[검색된 상품]\n{products}\n\n"
            "[현재 질문]\n{question}",
        ),
    ])
    #model = ChatOllama(model=MODEL_NAME, temperature=0.1)
    model = get_llm()
    parser = StrOutputParser()

    # 입력 딕셔너리 → 프롬프트 → Ollama → 문자열 답변
    return prompt | model | parser


def main() -> None:
    """사용자 입력, 상품 검색, AI 추천을 순서대로 실행한다."""
    # 프로그램을 시작할 때 전체 상품과 추천 체인을 한 번만 준비한다.
    all_products = load_products() # 상품 데이터 로드
    recommendation_chain = create_chain() # 추천 체인 생성(프롬프트 > 모델 > 파서)

    # 아직 검색 전이므로 컬럼만 있고 행은 없는 빈 검색 결과로 시작한다.
    search_results = all_products.head(0).copy()    # 검색 결과 초기화(빈 데이터프레임)
    conversation_history: list[str] = []            # 대화 기록 초기화(빈 리스트)

    # 안내 메시지 출력
    print(f"무신사 상품 {len(all_products)}개를 불러왔습니다.")
    print(HELP)

    # 무한 루프, 사용자 입력 받기
    while True:
        question = input("\n나: ").strip()

        # 질문이 없으면 다시 입력받는다.
        if not question:
            continue

        # 네 가지 명령어를 먼저 처리한다.
        if question.lower() in {"종료", "exit", "quit"}:
            print("챗봇: 상담을 종료합니다.")
            break
        if question == "도움말":
            print(HELP)
            continue
        if question == "목록":
            if search_results.empty:
                print("현재 검색된 상품이 없습니다.")
            else:
                columns = ["상품ID", "상품명", "가격", "할인율", "상품URL"]
                print(search_results[columns].to_string(index=False))
            continue
        if question == "초기화":
            search_results = all_products.head(0).copy() # 검색 결과 초기화(빈 데이터프레임)
            conversation_history.clear() # clear(): 리스트의 모든 요소를 제거
            print("챗봇: 대화 기록과 검색 결과를 초기화했습니다.")
            continue

        # 후속 질문이면 직전 결과에서, 새 질문이면 전체 상품에서 검색한다.
        # 후속 질문 여부 확인(any(): 튜플에 포함된 단어가 질문에 있는지 확인)
        is_follow_up = any(word in question for word in FOLLOW_UP_WORDS)

        # 후속 질문이면 직전 결과에서, 새 질문이면 전체 상품에서 검색한다.
        products_to_search =  search_results if not search_results.empty and is_follow_up else all_products
        
        # 상품검색
        search_results = search_products(products_to_search, question)

        # 검색 결과가 비어있으면 조건에 맞는 상품을 찾지 못했습니다 출력
        if search_results.empty:
            print("챗봇: 조건에 맞는 상품을 찾지 못했습니다. 조건을 넓혀 주세요.")
            continue

        # 체인의 입력 변수 history, products, question을 딕셔너리로 전달한다.
        recent_history = "\n".join(conversation_history[-6:]) or "이전 대화 없음" # 최근 6개 대화 기록 문자열 생성(빈 문자열이면 이전 대화 없음 출력)
        chain_input = {
            "history": recent_history,
            "products": format_products(search_results),
            "question": question,
        }

        try:
            # AI 답변 요청(체인의 입력 변수 history, products, question을 딕셔너리로 전달)
            answer = recommendation_chain.invoke(chain_input)
            # 예외 처리
        except Exception as error:
            print("챗봇: Ollama 연결에 실패했습니다.")
            print(f"Ollama 실행 상태와 {MODEL_NAME} 설치 여부를 확인하세요.")
            print("상세 오류:", error)
            continue

        print("챗봇:", answer)
        conversation_history.extend([
            f"사용자: {question}",
            f"챗봇: {answer}",
        ])


if __name__ == "__main__":
    main()
