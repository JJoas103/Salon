import re
from pathlib import Path
import pandas as pd
from common_gpt import get_llm
from langchain_core.prompts import ChatPromptTemplate
from langchain_core.output_parsers import StrOutputParser

CSV_PATH = Path(__file__).parent/'musinsa_products.csv'
HELP = """
[질문 예시]
3만원 이하 티셔츠를 추천해 줘
할인율 높은 바지 3개 보여 줘
방금 추천한 것 중 두번재 상품 링크 알려줘

[명령어]
    도움말 | 목록 | 초기화 | 종료
"""

# csv를 읽어 전체 상품을 정제해서 가져오기
def load_products() -> pd.DataFrame:
    df = pd.read_csv(CSV_PATH)
    # 기존 문자열로 이루어진 가격, 정상가 값을 숫자로 변환, 바꿀 수 없는 값이면 그 칸을 Nan(결측치)로 바꿈
    df['가격'] = pd.to_numeric(df['가격'], errors='coerce')
    df['정상가'] = pd.to_numeric(df['정상가'], errors='coerce')
    # 기존 문자열로 이루어진 할인율은 '%'를 지우고 숫자로 변환
    df['할인율'] = pd.to_numeric(
        df['할인율'].astype(str).str.replace('%','',regex=False), 
        errors='coerce')
    # 상품명, 가격 결측치를 제거한 데이터프레임을 반환
    return df.dropna(subset=['상품명', '가격']).copy()

# 사용자의 질문에서 일부의 상품만 추출해 데이터프레임으로 반환(최대 12개)
# 예시) 가격 3만원, 할인율 30%, 티셔츠
def search_products(base: pd.DataFrame, question: str) -> pd.DataFrame:
    result = base.copy()

    # 사용자의 질문에서 최대 가격 조건 찾기(ex) 3만원보다 낮은 가격의 상품만 데이터프레임에서 추출)
    price_match = re.search(r'(\d+(?:\.\d+)?)\s*만\s*원', question)
    if price_match: 
        result = result[result['가격'] <= float(price_match.group(1)) *10_000]
    
    # 사용자의 질문에서 최소 할인율 조건 찾기(ex) 30% 이상 할인하는 상품만 데이터프레임에서 추출)
    discount_match = re.search(r'(\d+)\s*%', question)
    if discount_match: 
        result = result[result['할인율'] >= int(discount_match.group(1))]
    
    # 2글자 이상 한글/영어 단어를 상품명 키워드로 사용 ex) A티셔츠랑 바지 검색해줘
    words = [w for w in re.findall(r'[가-힣A-Za-z]+', question) if len(w) >= 2]
    if words:
        pattern = '|'.join(re.escape(w) for w in words)
        matched = result[result['상품명'].str.contains(pattern, case=False, na=False)]
        # 키워드로 걸러진 결과가 없으면 가격/할인 조건만 유지
        if not matched.empty:
            result = matched

    # 할인이 포함된 질문이면 할인율이 높은 순, 아니면 가격이 낮은 순으로 정렬
    # 조건이 맞는 상품 최대 12개의 행의 데이터프레임 생성
    sort_col = '할인율' if '할인' in question else '가격'
    return result.sort_values(sort_col, ascending=(sort_col == '가격')).head(12)

# 프롬프트에 보낼 상품을 문자열로 정제
def format_products(df: pd.DataFrame) -> str:
    return '\n'.join(
        f'- {row["상품명"]} | {int(row["가격"])}원 | '
        f'- 할인율 {int(row["할인율"])}% | {row["상품URL"]}'
        for _, row in df.iterrows()
    )
# iterrows: 데이터프레임에서 인덱스와 데이터를 추출

# 챗봇 메인
def main() -> None:
    # 상품 데이터 로드
    all_products = load_products()
    # 체인 생성(프롬프트 -> LLM -> 파서)
    prompt = ChatPromptTemplate.from_messages([
        (
            'system',
            '너는 대진대쇼핑몰 추천 상담원이다. 검색된 상품 정보만 사용하고, '
            '목록에 없는 내용은 추측하지 않는다. 상품명, 가격, 할인율, '
            '추천 이유, URL을 포함해 친절하게 답한다.',
        ),
        (
            'human',
            '[최근 대화]\n{history}\n\n[검색된 상품]\n{products}\n\n[질문]\n{question}'
        ),
    ])
    chain = prompt | get_llm() | StrOutputParser()

    # 이전 기록
    history: list[str] = []
    
    # 검색된 상품
    search_results = all_products.head(0)   

    # 안내 메시지 출력
    print(f'무신사 상품 100개를 불러왔습니다')
    print(HELP)
    
    # 무한 루프, 사용자 입력 받기
    while True:
        question = input('\n나: ').strip()

        # 질문이 없으면 다시 입력
        if not question:
            continue

        # 기본 명령어 수행
        if question.lower() in {'종료', 'exit', 'quit'}:
            print('챗봇: 상담을 종료합니다')
            break
        if question == '도움말':
            print(HELP)
            continue

        # 사용자의 질문에서 일부 상품만 추려서 데이터프레임으로 만들기
        base = all_products
        search_results = search_products(base, question)
        
        # 챗봇 연결
        try:
            answer = chain.invoke({
                # 최신 질문 답변만 보내기
                'history': '\n'.join(history[-6:]) or '이전 대화 없음',
                # 상품 정보(사용자 질문 조건에 맞는 일부만)
                'products' : format_products(search_results),
                # 사용자 질문
                'question' : question
            })
        except Exception as e:
            print('챗봇: 답변 생성에 실패했습니다')
            print('상세오류: ', e)
            continue
        
        # 답변 출력
        print('챗봇: ', answer)
        # 사용자의 질문과 답변을 history 리스트에 누적
        history += [f'사용자: {question}', f'챗봇: {answer}']
main()