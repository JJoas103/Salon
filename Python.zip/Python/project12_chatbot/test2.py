import re
from pathlib import Path

import pandas as pd
from langchain_core.output_parsers import StrOutputParser
from langchain_core.prompts import ChatPromptTemplate

from common_gpt import get_llm  # 이미 만들어 둔 LLM 로더 사용

CSV_PATH = Path(__file__).parent / "musinsa_products.csv"

HELP = """
[질문 예시]
  3만원 이하 티셔츠를 추천해 줘
  할인율 높은 바지 3개 보여 줘
  방금 추천한 것 중 두번째 상품 링크 알려줘

[명령어]
  도움말 | 목록 | 초기화 | 종료
"""

# 이 단어가 있으면 전체 상품이 아니라 직전 검색 결과에서 다시 찾는다.
FOLLOW_UP_WORDS = ("방금", "그중", "그 중", "번째", "링크")


def load_products() -> pd.DataFrame:
    """CSV를 읽고 가격/할인율을 숫자로 정리한다."""
    df = pd.read_csv(CSV_PATH)
    df["가격"] = pd.to_numeric(df["가격"], errors="coerce")
    df["정상가"] = pd.to_numeric(df["정상가"], errors="coerce")
    df["할인율숫자"] = pd.to_numeric(
        df["할인율"].astype(str).str.replace("%", "", regex=False), errors="coerce"
    ).fillna(0)
    return df.dropna(subset=["상품명", "가격"]).copy()


def search_products(df: pd.DataFrame, question: str) -> pd.DataFrame:
    """질문에서 가격/할인율/키워드 조건을 뽑아 최대 12개를 반환한다."""
    result = df.copy()

    # "3만원" 같은 최대 가격 조건
    price_match = re.search(r"(\d+(?:\.\d+)?)\s*만\s*원", question)
    if price_match:
        result = result[result["가격"] <= float(price_match.group(1)) * 10_000]

    # "30%" 같은 최소 할인율 조건
    discount_match = re.search(r"(\d+)\s*%", question)
    if discount_match:
        result = result[result["할인율숫자"] >= int(discount_match.group(1))]

    # 2글자 이상 한글/영어 단어를 상품명 키워드로 사용
    words = [w for w in re.findall(r"[가-힣A-Za-z]+", question) if len(w) >= 2]
    if words:
        pattern = "|".join(re.escape(w) for w in words)
        matched = result[result["상품명"].str.contains(pattern, case=False, na=False)]
        if not matched.empty:  # 키워드로 걸러진 결과가 없으면 가격/할인 조건만 유지
            result = matched

    # "할인"이 포함된 질문이면 할인율 높은 순, 아니면 가격 낮은 순
    sort_col = "할인율숫자" if "할인" in question else "가격"
    return result.sort_values(sort_col, ascending=(sort_col == "가격")).head(12)


def format_products(df: pd.DataFrame) -> str:
    """AI 프롬프트에 넣을 상품 목록 문자열을 만든다."""
    return "\n".join(
        f"- {row['상품명']} | {int(row['가격']):,}원 | "
        f"할인율 {int(row['할인율숫자'])}% | {row['상품URL']}"
        for _, row in df.iterrows()
    )


def main() -> None:
    # 전체 상품 가져오기
    all_products = load_products()

    # 프롬프트 생성
    prompt = ChatPromptTemplate.from_messages([
        (
            "system",
            "너는 무신사 상품 추천 상담원이다. 검색된 상품 정보만 사용하고, "
            "목록에 없는 내용은 추측하지 않는다. 상품명, 가격, 할인율, "
            "추천 이유, URL을 포함해 친절하게 답한다.",
        ),
        (
            "human",
            "[최근 대화]\n{history}\n\n[검색된 상품]\n{products}\n\n[질문]\n{question}",
        ),
    ])
    # 체인생성
    chain = prompt | get_llm() | StrOutputParser()

    search_results = all_products.head(0)  # 검색 전이므로 빈 결과로 시작
    history: list[str] = []

    print(f"무신사 상품 {len(all_products)}개를 불러왔습니다.")
    print(HELP)

    while True:
        question = input("\n나: ").strip()
        if not question:
            continue

        if question.lower() in {"종료", "exit", "quit"}:
            print("챗봇: 상담을 종료합니다.")
            break
        if question == "도움말":
            print(HELP)
            continue
        if question == "목록":
            if search_results.empty:
                print("현재 검색된 상품이 없습니다.")
            else:
                cols = ["상품ID", "상품명", "가격", "할인율", "상품URL"]
                print(search_results[cols].to_string(index=False))
            continue
        if question == "초기화":
            search_results = all_products.head(0)
            history.clear()
            print("챗봇: 대화 기록과 검색 결과를 초기화했습니다.")
            continue

        # 후속 질문이면 직전 결과에서, 새 질문이면 전체 상품에서 검색
        is_follow_up = any(w in question for w in FOLLOW_UP_WORDS)
        base = search_results if is_follow_up and not search_results.empty else all_products
        search_results = search_products(base, question)

        if search_results.empty:
            print("챗봇: 조건에 맞는 상품을 찾지 못했습니다. 조건을 넓혀 주세요.")
            continue

        try:
            answer = chain.invoke({
                "history": "\n".join(history[-6:]) or "이전 대화 없음",
                "products": format_products(search_results),
                "question": question,
            })
        except Exception as e:
            print("챗봇: 답변 생성에 실패했습니다.")
            print("상세 오류:", e)
            continue

        print("챗봇:", answer)
        history += [f"사용자: {question}", f"챗봇: {answer}"]


if __name__ == "__main__":
    main()