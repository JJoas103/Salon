# 함수의 매개변수와 기본값

# 기본값이 설정되어 있는 매개변수는 생략 가능
def order(item, quantity=1, price=2000000):
    total = quantity * price
    return item, quantity, total

print('200만원 노트북을 3개 구매: ', order('노트북', 3, 3000000))
print('노트북 구매:', order('노트북'))

# 키워드 인자: 순서와 관계업시 매개변수를 전달
print('햇반 구매: ', order(quantity=2, item='햇반', price=1700))

