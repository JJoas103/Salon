# 타입 힌트: 매개변수의 타입 명시

def greet(name : str) -> str:
    return '안녕하세요,'+ name + '님'
print(greet('홍길동'))

print('-' *30)

# 문자열, 정수, 정수 타입의 매개변수를 받아 튜플 반환
def order(item: str, quantity: int, price: int) -> tuple[str, int, int]:
    total = quantity * price
    return item, quantity, total

print(order('마우스', 2, 1000))

