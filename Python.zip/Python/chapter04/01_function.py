# 함수의 정의와 호출

# def 이름(매개변수): 함수 정의
def greet(name):
    return f'안녕하세요, {name}님'

print(greet('홍길동'))  # 함수 호출

# 반환값이 없는 함수
def log(message):
    print(f'[LOG]{message}')

result = log('시작')
print('반환값: ', result)   # 반환값 None

# 여러 값을 반환: 튜플로 반환
def calc(a, b): 
    return a + b, a - b, a * b
print(calc(10, 3))
