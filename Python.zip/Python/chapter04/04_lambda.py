# 람다 함수

# 일반함수
def square(x):
    return x ** 2

print('square(4): ', square(4))

# 람다함수
double = lambda x: x * 2
print('double(5): ', double(5))

print('-'*30)

numbers = [1, 2, 3, 4, 5]

# 일반함수 - 제곱
square = list(map(square, numbers)) 
# map(함수, 리스트): 리스트의 각 요소에 함수적용
print('제곱: ', square)

# 람다 - 제곱
squared_lambda = list(map(lambda x : x **2, numbers))
print('squared_lambda: ' , squared_lambda)

print('-'*30)

# 일반함수 - 2의 배수 값 필터
def is_even(x):
    return x % 2 == 0
evens = list(filter(is_even, numbers))
# filter(함수, 리스트): 리스트의 각 요소에 함수 적용
print('짝수: ', evens)

# 람다함수 - 2의 배수 값 필터
evens_lambda = list(filter(lambda x:x%2==0, numbers))
print('짝수: ', evens_lambda)

print('-'*30)

products = [('키보드', 45000), ('마우스', 15000), ('모니터', 25000)]

# 일반함수 - 가격 순 정렬
def by_price(p):
    return p[1]
by_price = sorted(products, key=by_price)
print('가격순: ', by_price)

# 람다 - 가격 순 정렬
by_price_lambda = sorted(products, key=lambda p : p[1])
print('가격순: ', by_price_lambda)