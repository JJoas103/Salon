# args, **kwargs: 가변인자

# (*매개변수): 매개변수 개수를 가변적으로 받음(튜플)
def total(*prices):
    return sum(prices)

print(total(1000, 2000, 3000, 4000))

# (**매개변수): 매개변수 개수를 가변적으로 받음(딕셔너리)
def show_info(**info):
    for key, vale in info.items():
        print(f'{key} : {vale}')

show_info(name='홍길동', age=30, major='컴공')

def describe(title, *tags):
    print(f"{title} :  {' / '.join(tags)}")
describe('파이썬', '기초', '크롤링', 'AI')