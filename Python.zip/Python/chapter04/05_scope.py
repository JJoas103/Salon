# 변수 스코프

global_var = '전역변수'

def outer():
    outer_var = '외부함수 변수'
    def inner():
        local_var = '내부 변수'
        print(f'전역: {global_var}, 외부: {outer_var}')
    inner()
    # print(f'내부: {local_var}' ): 내부함수에서 선언한 자원은 메인/외부에서 접근 불가

outer()
# print(f'전역: {global_var}, 외부: {outer_var}, 내부: {local_var}')
# 함수에서 선언한 자원은 메인에서 접근 불가

print('-'*30)

# nonlocal: 중첩함수에서 바깥 함수 변수 수정
count = 0
def counter_func():
    count = 0
    def add():
        nonlocal count
        count += 1
        return count
    return add

add_one = counter_func()
print(add_one(), add_one(), add_one())