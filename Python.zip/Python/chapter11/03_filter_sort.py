from pathlib import Path
import pandas as pd

SAMPLES = Path(__file__).parent/'samples'
csv_path = SAMPLES/'products.csv'
df = pd.read_csv(csv_path, encoding='utf-8-sig')

# 1) 조건 필터: df[조건]
shoes = df[df['category'] == '신발']
print(shoes)

print('-'*30)

# 2) 복합 조건
nike_shoes = df[(df['category'] == '신발') & (df['brand'] == '나이키')]
print(nike_shoes)

print('-'*30)

# 3) isin: 여러 조건 중 하나와 일치
top_brands = df[df['brand'].isin(['나이키', '아디다스'])]
print(top_brands)

print('-'*30)
# 4) sort_values: 정렬
sorted_df = df.sort_values('name')
print(sorted_df)