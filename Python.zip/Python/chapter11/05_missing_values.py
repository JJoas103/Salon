# 결측치(빈 값) 처리
# numpy 설치: pip install numpy

import numpy as np
import pandas as pd
from pathlib import Path

SAMPLES = Path(__file__).parent/'samples'
csv_path = SAMPLES/'products.csv'
df = pd.read_csv(csv_path, encoding='utf-8-sig')

df = pd.read_csv(Path(__file__).parent/'samples'/'products.csv')
df = df.replace('', np.nan) # replace(): 빈문자열을 결측치로 교체
print('결측치 개수: \n',df.isnull().sum()) #isnull(): 결측치 여부 / sum(): 결측치 개수

print('-'*30)

# 1) fillna: 기본값 채우기
filled = df.copy()
filled['brand'] = filled['brand'].fillna('Unknown')
filled['price_raw'] = filled['price_raw'].fillna('0원')
print(filled)

print('-'*30)
# 2) dropna
dropped = df.dropna(subset=['brand', 'name', 'discount_raw'])
print(dropped)