from pathlib import Path
import pandas as pd

SAMPLES = Path(__file__).parent/'samples'
OUTPUT = Path(__file__).parent/'output'
OUTPUT.mkdir(exist_ok=True)

# 1) csv 읽기
csv_path = SAMPLES/'products.csv'
df = pd.read_csv(csv_path, encoding='utf-8-sig')
# read_csv: CSV 파일을 데이터 프레임으로 변환
print(df)
print(df.dtypes)

# 2) csv 저장
out_path = OUTPUT/'loaded.csv'
df.to_csv(out_path, index=False, encoding='utf-8-sig')
# to_csv: 데이터프레임을 CSV로 저장 
