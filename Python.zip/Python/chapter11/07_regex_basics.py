# re: 정규표현식 모듈
import re

raw_price = [
    '29,900원', 
    '\139,900', 
    '99000', 
    '할인가 45,700원', 
    '무료배송 79,900',
    None,
    '품절']

def parse_price(text) -> int | None:

    # 입력이 빈 문자열이거나 문자열이 아닌 경우 None을 반환
    if not text or not isinstance(text, str):
        return None

    digits = re.sub(r'[^\d]', '', text)
    # [^...]: 이 안에 잇는 거 빼고 전부
    # \d: 숫자
    # re.sub(패턴, 바꿀문자, 원본): 패턴에 맞는 부분을 치환

    return int(digits) if digits else None

for price in raw_price:
    print(f'{parse_price(price)}')

print('-'*30)

discount_texts = ['10%할인', '할인율 25%', '정가', '세일 15% OFF']
pattern = re.compile(r'(\d+)\s*%')
# compile(): 패턴을 컴파일하여 객체화, 반복 사용 시 효율적

for text in discount_texts:
    match = pattern.search(text)    
    # search(): 문자열에서 패턴 찾기
    rate = int(match.group(1)) / 100 if match else 0.0
    print(f'{text} -> {rate}')
