from pathlib import Path
import pandas as pd

SAMPLES = Path(__file__).parent/'samples'
csv_path = SAMPLES/'products.csv'
df = pd.read_csv(csv_path, encoding='utf-8-sig')

# 1) 컬럼 선택
subset = df[['brand', 'name', 'price_raw']]
print(subset)

print('-'*30)

# 2) 컬럼 추가: df['새로운 컬럼'] = 값
df_copy = df.copy()
df_copy['source'] = '쿠팡'
print(df_copy)

print('-'*30)

# 3) 컬럼 이름 변경: rename
df_copy = df_copy.rename(columns={'price_raw' : 'price_text'})
print(df_copy.columns.to_list())

print('-'*30)

# 4) assign: 체이닝 친화적 컬럼 추가
# df_copy.assign(
#     name_length = df_copy['name'].str.len(),
#     brand_upper = df_copy['brand'].str.upper()
# )
df_copy['name_length'] = df_copy['name'].str.len()
df_copy['brand_upper']  = df_copy['brand'].str.upper()

print(df_copy.columns.to_list())
print(df_copy[['name_length', 'brand_upper']])

# print(df_copy[['name', 'name_length', 'brand_upper']])
