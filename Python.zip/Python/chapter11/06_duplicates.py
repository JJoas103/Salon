import pandas as pd

df = pd.DataFrame({
    "brand": ["나이키", "아디다스", None, "나이키", "뉴발란스"],
    "name": ["에어포스", "슈퍼스타", "530", "에어포스", "993"],
    "price": [139000, 99000, 129000, 139000, 259000],
})

print(df)
# duplicated(): 완전 동일 행 중복 여부 확인
print('중복 행 수: ', df.duplicated().sum())

# 1) 특정 컬럼 기준 중복 확인
dup_mask = df.duplicated(subset=['brand', 'name'], keep=False)
print(dup_mask)

print('-'*30)

# 2) 특정 컬럼 기준 중복 제거(첫번째 행만 남기기)
unique = df.drop_duplicates(subset=['brand', 'name'], keep="first")
print(unique)

print('-'*30)

# 3) 인덱스 리셋
unique = unique.reset_index(drop=True)
print(unique)