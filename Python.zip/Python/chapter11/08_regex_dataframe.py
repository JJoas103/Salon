from pathlib import Path
import pandas as pd
import re

SAMPLES = Path(__file__).parent/'samples'
csv_path = SAMPLES/'products.csv'

df = pd.read_csv(csv_path, encoding='utf-8-sig')

# 가격 치환
def parse_price(text) -> int | None:
    if not text or not isinstance(text, str):
        return None
    digits = re.sub(r'[^\d]', '', text)
    return int(digits) if digits else None

# 할인율 치환
def parse_discount(text) -> float:
    if not text or not isinstance(text, str):
        return 0.0
    m = re.search(r'(\d+)', text)
    return int(m.group(1)) / 100 if m else 0.0

# 제조사 치환
def clean_brand(text) -> str:
    if not text or not isinstance(text, str):
        return '알수없음'
    return text

df['price'] = df['price_raw'].apply(parse_price)
df['discount'] = df['discount_raw'].apply(parse_discount)
df['brand_clean'] = df['brand'].apply(clean_brand)
# apply(): 각 값에 함수를 일괄 적용해 새 Series 반환
print(df)