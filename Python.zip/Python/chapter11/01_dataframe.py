# pandas: 표 형태 데이터를 다루는 라이브러리
# 설치: pip install pandas

import pandas as pd
raw = {
    "brand" : ['나이키', '아디다스', '뉴발란스', '나이키'],
    'name' : ['에어포스', '슈퍼스타', '530', '드라이핏 티'],
    'price' : [139000, 99000, 12900, 45000],
    'category' : ['신발', '신발', '신발', '상의']
}

df = pd.DataFrame(raw) # DataFrame(): 딕셔너리를 데이터프레임으로 변환
print(df)

# 자주 쓰는 속성
print('컬럼: ', df.columns.tolist())
print('행, 열 개수: ', df.shape)
print('앞 2행', df.head(2))
print('기본 통계: ', df.describe())