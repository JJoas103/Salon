from common_gpt import get_llm
from langchain_core.messages import HumanMessage, ToolMessage
from langchain_core.tools import tool

PRODUCTS = {
    '라이트북 14' : 790000,
    '파워북 15' : 1090000,
    '미니북 12' : 590000,
}

@tool
def find_price(product_name : str) -> str:
    """정확한 상품명으로 가격을 조회한다."""
    price = PRODUCTS.get(product_name)
    if price is None:
        return '상품을 찾지 못했습니다.'
    return f'{price}'

@tool
def calculate_discount(price: int, rate: int) -> int:
    """가격에 할인율을 적용한다."""
    return price - (price * rate // 100)

tools = [find_price, calculate_discount]
tool_map = {
    'find_price' : find_price,
    'calculate_discount' : calculate_discount
}
llm = get_llm().bind_tools(tools)
message = [HumanMessage(content = '라이트북 14 가격을 찾고 10% 할인 가격을 알려 줘')]

for step in range(5):
    answer = llm.invoke(message)
    message.append(answer)

    # LLM이 호출한 도구가 없으면 최종문장을 호출하고 반복문 종료
    if not answer.tool_calls:
        print(answer.content)
        break

    # LLM이 호출한 도구가 있으면 하나씩 처리
    for call in answer.tool_calls:
        tool = tool_map[call['name']]
        result = tool.invoke(call['args'])
        print(f'{step + 1}단계: {call["name"]} => {result}')
        message.append(ToolMessage(content=str(result), tool_call_id=call['id']))
else:
    print('최대 실행 회수에서 중단했습니다.')



