import asyncio
import sys
from pathlib import Path
from common_gpt import get_llm
from mcp import ClientSession, StdioServerParameters
from mcp.client.stdio import stdio_client

async def main():
    server_file = Path(__file__).with_name('mcp_server.py')

    # MCP 서버 프로세스를 어떻게 실행할지 명령을 준비
    params = StdioServerParameters(
        command=sys.executable,
        args = [str(server_file)],
    )
    # MCP 서버와 통신하는 클라이언트 객체 생성
    async with stdio_client(params) as (read, write):
        # MCP 서버와 통신하는 세션을 관리하는 객체 생성
        async with ClientSession(read, write) as session:
            await session.initialize()

            # MCP 서버가 가지고 있는 도구 목록을 조회
            tools = await session.list_tools()
            print('사용 가능한 MCP 도구: ')
            for tool in tools.tools:
                print('-', tool.name)
            
            # call_tool: 서버에 등록된 도구 중 하나를 호출
            result = await session.call_tool(
                'compare_price',
                {'product_ids' : ['P001', 'P002', 'P003']}
            )
            print('실행결과: ', result.content[0].text)

if __name__ == '__main__':
    asyncio.run(main())

