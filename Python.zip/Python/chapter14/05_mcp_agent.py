import asyncio
import sys
from pathlib import Path
from common_gpt import get_llm

from langchain.agents import create_agent
from langchain_core.messages import HumanMessage
from langchain_mcp_adapters.client import MultiServerMCPClient
from langchain_mcp_adapters.tools import load_mcp_tools

# pip install langchain
# pip install langchain_mcp_adapters

MCO_SERVER = Path(__file__).with_name('mcp_server.py')

async def main():

    # MultiServerMCPClient: MCP 서버와 통신하는 클라이언트 객체
    client = MultiServerMCPClient({
        'products' : {
            'transport' : 'stdio',
            'command' : sys.executable,
            'args' : [str(MCO_SERVER)]
        }
    })

    # session: MCP 서버와 통신하는 세션을 관리하는 객체 
    async with client.session('products') as session:
        tools = await load_mcp_tools(session)

        llm = get_llm()

        # 에이전트(LLM과 도구를 연결) 생성
        agent = create_agent(llm, tools, 
                             system_prompt="상품 정보는 반드시 MCP Tool로 확인해서 답하세요.")
        
        # 에이전트 실행
        question = HumanMessage(content = '상품의 목록을 확인하고 가장 저렴한 상품을 추천해 줘.')
        result = await agent.ainvoke({'messages' : [question]})

    # 최종답변 출력
    print('최종 답변: ', result['messages'][-1].content)

if __name__ == '__main__':
    asyncio.run(main())