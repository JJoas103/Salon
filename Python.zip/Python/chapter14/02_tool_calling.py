from common_gpt import get_llm
from langchain_core.messages import HumanMessage, ToolMessage
from langchain_core.tools import tool

@tool
def calculate_discount(price: int, rate: int) -> int:
    """가격과 할인율을 받아 할인 가격을 계산한다."""
    return price - (price * rate // 100)

tools = [calculate_discount]
llm = get_llm().bind_tools(tools)   # bind_tools(): 도구를 LLM에 연결

messages = [HumanMessage(content='125000원 상품을 20% 할인하면 얼마야?')]

ai_message = llm.invoke(messages)   # 첫번째 응답은 도구 이름과 입력 값이 들어옴
messages.append(ai_message)

# LLM이 호출한 도구를 하나씩 처리
for call in ai_message.tool_calls:
    print('호출한 도구: ', call['name'])
    result = calculate_discount.invoke(call['args'])
    messages.append(ToolMessage(content = str(result), tool_call_id = call['id']))

# LLM 최종 답변
final_message = llm.invoke(messages)
print(final_message.content)