# pip install mcp
# MCP(Model Context Protocol): AI 애플리케이션과 외부도구를 연결하는 표준
# 서버는 사용할 수 있는 도구를 공개하고, 클라이언트는 목록을 조회하거나 실행

from mcp.server.fastmcp import FastMCP # MCP 서버를 구현하는 프레임워크

mcp = FastMCP('product-tools')

PRODUCTS = {
    'P001' : {'name' : '라이트북 14', 'price' : 790000},
    'P002' : {'name' : '파워북 15', 'price' : 1090000},
    'P003' : {'name' : '미니북 16', 'price' : 590000},
}

@mcp.tool()   # 파이썬 함수를 MCP 서버의 도구로 등록
def list_products() -> list[dict]:
    """상품을 비교하거나 조회하기 전에 전체 상품 ID, 이름, 가격을 반환한다."""
    result = []
    for prduct_id in PRODUCTS:
        product = PRODUCTS[prduct_id]
        result.append({
            'product_id' : prduct_id,
            'name' : product['name'],
            'price' : product['price']
        })
    return result

@mcp.tool()
def get_product(product_id: str) -> dict:
    """상품 ID로 이름과 가격을 조회한다."""
    return PRODUCTS.get(product_id, {'error' : '상품을 찾지 못했습니다.'})

@mcp.tool()
def compare_price(product_ids : list[str]) -> dict:
    """여러 상품 중 가장 저렴한 상품을 찾는다."""
    cheapest = None

    for product_id in product_ids: 
        product = PRODUCTS.get(product_id)

        if product is None:
            continue
        
        if cheapest is None or product['price'] < cheapest['price']:
            cheapest = {
                'product_id' : product_id,
                'name' : product['name'],
                'price' : product['price']
            }

        if cheapest is None:
            return {'error' : '비교할 상품이 없습니다.'}

    return cheapest

if __name__ == '__main__':
    mcp.run(transport='stdio')
    # 클라이언트와 표준 입력/출력으로 통신