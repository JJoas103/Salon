# Chapter 14 핵심 개념

## Chain과 Agent

Chain은 개발자가 미리 정한 순서대로 프롬프트, LLM, 출력 변환기 등을 실행한다.
반복 가능한 고정 절차에 적합하다. Agent는 사용자의 목표를 해석하고 등록된 Tool 중
무엇을 어떤 순서로 호출할지 LLM이 판단한다. 외부 상태를 바꾸는 Tool에는 입력 검증과
권한 제한이 필요하다.

## Tool과 MCP

Tool은 검색, 계산, 파일 처리처럼 LLM이 호출할 수 있도록 이름과 입력 스키마를 붙인
기능이다. MCP(Model Context Protocol)는 Tool을 별도 프로세스나 서비스에서 표준
방식으로 발견하고 호출하게 하는 연결 규격이다. MCP 자체가 답을 생성하는 LLM이나
문서를 검색하는 RAG는 아니다.

MCP 서버가 제공하는 핵심 primitive에는 Tool, Resource, Prompt가 있다. Tool은
계산·API 호출·파일 저장처럼 실행할 기능이고, Resource는 파일이나 데이터베이스
레코드처럼 읽을 문맥 데이터다. Prompt는 클라이언트가 가져다 쓸 수 있는 재사용
대화 템플릿이다. OpenAI Responses API의 `image_generation` 같은 내장 Tool은
OpenAI가 제공하는 모델 기능이며 MCP Tool과는 구분해야 한다. 이 장에서는 그 내장
기능을 다시 MCP 서버로 감싸 다른 Agent가 표준 방식으로 호출할 수 있게 한다.

## RAG와 Elasticsearch

RAG는 질문과 관련된 외부 문서를 먼저 검색하고, 검색 결과를 프롬프트의 근거로 넣어
LLM이 답하게 하는 패턴이다. 이 예제는 문서를 작은 청크로 나누고 다국어 임베딩을
계산해 Elasticsearch의 dense_vector 필드에 저장한다. 검색할 때는 정확한 단어를
찾는 키워드 검색과 의미가 가까운 내용을 찾는 kNN 벡터 검색을 결합한다.

전체 흐름은 사용자 질문 → LangChain Agent → MCP Tool → Elasticsearch 하이브리드
검색 → 근거 청크 → OpenAI GPT 최종 답변 순서다. GPT가 먼저 문서를 모두 읽는 것이
아니라, Elasticsearch가 관련 청크를 좁힌 뒤 그 일부만 GPT에 전달한다.

## 파일과 외부 API 안전 원칙

파일 도구는 `chapter14/rag_files` 바로 아래의 TXT, Markdown, CSV, JSON, PDF만 읽고
파일 크기를 10MB로 제한한다. `../` 같은 상위 경로 접근은 거부한다. 외부 API 도구도
에이전트가 임의 URL을 호출하게 하지 않고, 예제에서는 Open-Meteo의 현재 날씨
엔드포인트만 사용한다. 비밀 정보가 포함된 문서는 Elasticsearch나 외부 LLM으로
전송하지 않아야 한다.
