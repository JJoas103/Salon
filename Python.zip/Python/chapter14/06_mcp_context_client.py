import asyncio
import sys
from pathlib import Path
from langchain_mcp_adapters.client import MultiServerMCPClient

MCP_SERVER = Path(__file__).with_name('mcp_context_server.py')

async def main():
    client = MultiServerMCPClient(
        {
            'context' : {
                'transport' : 'stdio',
                'command' : sys.executable,
                'args' : [str(MCP_SERVER)]
            }
        }
    )
    # Resource
    resorces = await client.get_resources(
        server_name = 'context',
        uris = 'guide://chapter14/core'
    )
    print('[Resource]')
    print(resorces[0].as_string()[:300])

    # Prompt
    prompt_messages = await client.get_prompt(
        'context',
        'explain_mcp',
        arguments={'audience' : '파이썬 중급자'}
    )
    print('[Prompt]')
    print(prompt_messages[0].content)

if __name__ == '__main__':
    asyncio.run(main())