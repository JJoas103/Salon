import csv
from pathlib import Path
from elasticsearch import Elasticsearch, helpers
from mcp.server.fastmcp import FastMCP
from typing import Any

ES_URL = 'http://localhost:9200'
INDEX_NAME = 'chapter14-products'
CSV_FILE = Path(__file__).parent/'data'/'products.csv'

PRODUCT_MAPPINGS = {
    'properties': {
        'product_id' : {'type' : 'keyword'},
        'name' : {'type' : 'text'},
        'price' : {'type' : 'integer'},
        'weight' : {'type' : 'float'},
        'memory' : {'type' : 'integer'},
        'description' : {'type' : 'text'},
        'content' : {'type' : 'text'}
    }
}

mcp = FastMCP('elasticsearch-product-search')

# ES 서버 연결
def get_client() -> Elasticsearch:
    client = Elasticsearch(ES_URL, request_timeout=30)
    if not client.ping():
        raise ConnectionError('ES에 연결할 수 없습니다: ', {ES_URL})
    return client

# csv를 읽어 ES 문서 형태로 변환
def load_products() -> list[dict[str, Any]]:
    products = []
    with CSV_FILE.open(encoding='utf-8', newline='') as file:
        for row in csv.DictReader(file):
            product = {
                'product_id' : row['product_id'],
                'name' : row['name'],
                'price' : row['price'],
                'weight' : row['weight'],
                'memory' : row['memory'],
                'description' : row['description'],
            }
            product['content'] = (
                f"[{product['product_id']}] {product['name']}\n"
                f"가격: [{product['price']}]원\n"
                f"무게: [{product['weight']}]kg\n"
                f"메모리: [{product['memory']}]GB\n"
                f"특징: [{product['description']}]"
            )
            products.append(product)

    return products
    

@mcp.tool()
def create_product_index() -> dict[str, Any]:
    """상품 인덱스를 만들고 CSV의 샘플 상품을 색인한다."""
    client = get_client()

    # 이미 인덱스가 존재
    if client.indices.exists(index=INDEX_NAME):
        document_count = client(index=INDEX_NAME)['count']
        return {
            'create' : False,
            'index' : INDEX_NAME,
            'document_count' : document_count,
            'message' : '이미 존재하는 인덱스이므로 변경하지 않았습니다.'
        }
    # 인덱스가 없음 - 인덱스 생성
    client.indices.create(index=INDEX_NAME, mappings=PRODUCT_MAPPINGS)
    # CSV에서 상품을 가져와 인덱스에 저장
    products = load_products()
    actions = (
        {'_index': INDEX_NAME, '_id': product['product_id'], '_source': product}
        for product in products
    )
    indexed_count, _ = helpers.bulk(client, actions)
    client.indices.refresh(index=INDEX_NAME)
    return {
        'create' : True,
        'index' : INDEX_NAME,
        'document_count' : indexed_count,
        'message' : '상품 인덱스 생성과 데이터 색인을 완료했습니다.'
    }

@mcp.tool()
def search_products(keyword: str, count: int = 5) -> list[dict[str, Any]]:
    """Elasticsearch에서 상품 키워드를 검색한다. 결과는 최대 10개이다."""
    keyword = keyword.strip()
    if not keyword:
        raise ValueError('검색어를 한 글자 이상 입력하세요.')
    client = get_client()
    # 인덱스가 없으면 예외
    if not client.indices.exists(index=INDEX_NAME):
        raise RuntimeError(
            '상품 인덱스가 없습니다. create_product_index Tool을 먼저 호출하세요.'
        )
    response = client.search(
        index=INDEX_NAME,
        size = count,
        query={
            'multi_match' : {
                'query' : keyword,
                'fields': ['name^3', 'description^2', 'content']
            }
        },
    )
    return [hit['_source'] for hit in response['hits']['hits']]

if __name__ == '__main__':
    mcp.run(transport='stdio')