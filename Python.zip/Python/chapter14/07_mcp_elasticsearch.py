import asyncio
import sys
from pathlib import Path

from langchain.agents import create_agent
from langchain_core.messages import HumanMessage
from langchain_mcp_adapters.client import MultiServerMCPClient
from langchain_mcp_adapters.tools import load_mcp_tools
from common_gpt import get_llm

MCP_SERVER = Path(__file__).with_name('mcp_elasticsearch_server.py')

async def main():
    client = MultiServerMCPClient(
        {
            'product-search' : {
                'transport' : 'stdio',
                'command' : sys.executable,
                'args' : [str(MCP_SERVER)]
            }
        }
    )
    async with client.session('product-search') as session:
        tools = await load_mcp_tools(session)
        llm = get_llm()
        # 에이전트 생성
        agent = create_agent(
            llm, tools, 
            system_prompt=(
                "먼저 create_product_index Tool로 상품 인덱스를 준비하세요."
                "그 다음 상품 정보는 반드시 search_product Tool을 확인해서 답하세요."
                "검색 결과에 없는 정보는 추측하지 마세요."
                ),
        )
        question = HumanMessage(content='라이트북 찾아 줘')
        result = await agent.ainvoke(
            {'messages' : [question]},
            config={'recursion_limit' : 10}
        )
    print('최종답변: ', result['messages'][-1].content)

if __name__ == '__main__':
    asyncio.run(main())