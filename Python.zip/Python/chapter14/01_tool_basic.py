from langchain_core.tools import tool

@tool   # 일반 파이썬 함수를 LangChain의 도구로 변환
def calculate_discount(price: int, rate: int) -> int:
    # docstring: 도구설명(LLM이 도구를 사용할 때 참고, 단순 주석X)
    """가격과 할인율을 받아 할인 가격을 계산한다"""
    return price - (price * rate // 100)

print('도구 이름: ', calculate_discount.name)
print('도구 설명: ', calculate_discount.description)
print('실행 결과: ', calculate_discount.invoke({'price' : 10000, 'rate' : 10}))