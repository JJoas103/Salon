from mcp.server.fastmcp import FastMCP
from pathlib import Path

GUIDE_FILE = Path(__file__).parent/'resource'/'chapter14_guide.md'

mcp = FastMCP(
    'mcp-primitives',
    instructions='Chapter14 가이드와 학습용 Prompt, 계산 tool을 제공합니다.'
)

@mcp.resource("guide://chapter14/core") # 리소스 등록(서버가 가진 데이터를 LLM이 읽을 수 있게 만들어 줌)
def chapter14_guide() -> str:
    """클라이언트가 읽을 수 있는 Chapter 14 가이드 문서다."""
    return GUIDE_FILE.read_text(encoding='utf-8')

@mcp.prompt()   # 프롬프트 템플릿 등록
def explain_mcp(audience: str = '파이썬 입문자') -> str:
    """대상 독자에 맞춰 MCP를 설명하기 위한 재사용 Prompt다."""
    return (
        f'{audience}에게 MCP의 Host, Client, Server, Tool, Resource, Prompt의 차이를'
        '작은 파이썬 예시와 함께 설명해 주세요. MCP와 Agent가 같은 개념이 '
        '아니라는 점을 포함해 주세요.'
    )

@mcp.tool()
def count_keyword(keyword : str) -> dict:
    """Chapter 14 가이드에서 특정 단어가 몇 번 나오는지 계산한다."""
    keyword = keyword.strip()
    if not keyword:
        raise ValueError('검색할 단어를 입력해주세요')
    text = GUIDE_FILE.read_text(encoding='utf-8')
    return {'keyword' : keyword, 'count' : text.casefold().count(keyword.casefold())}

if __name__ == '__main__':
    mcp.run(transport='stdio')