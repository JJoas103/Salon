# 클래스

class Dog:

    def bark(self):
        return '멍멍'
    
# 인스턴스 객체 생성
dog1 = Dog()
dog2 = Dog()

print(dog1.bark())
print(dog2.bark())
print(type(dog1)) # <class '__main__.Dog'>
print(dog1 is dog2) # 서로 다른 객체