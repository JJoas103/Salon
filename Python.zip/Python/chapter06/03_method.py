# 메서드

class BankAccount:
    def __init__(self, owner, balance=0):
        self.owner = owner
        self.balance = balance
    
    def deposit(self, amount):
        self.balance += amount
        return self.balance

    def withdraw(self, amount):
        if(amount > self.balance):
            return '잔액부족'
        self.balance -= amount
        return self.balance
    
    def info(self):
        return f'{self.owner}님 잔액: {self.balance}원'
    
    # 자바의 toString() 메서드와 유사
    def __str__(self):
        return f'{self.owner}님 잔액: {self.balance}원'


account = BankAccount('홍길동', 10000)
print(account.info())

account.deposit(5000)
print('입금 후: ', account.info())

print(account.withdraw(100000))
# print('출금 후: ', account.info())