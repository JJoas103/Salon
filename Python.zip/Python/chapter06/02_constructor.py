# 생성자(__init__)

class Student:

    # __init__ : 생성자 메서드
    def __init__(self, name, age):
        self.name = name
        self.age = age
    
    def introduce(self):
        return f'이름:{self.name}, 나이: {self.age}세'

s1 = Student('홍길동', 20)
s2 = Student('이순신', 24)

print(s1.introduce())
print(s2.introduce())
print(s1.name)
