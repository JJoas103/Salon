import chromadb
from langchain_core.output_parsers import StrOutputParser
from langchain_core.prompts import ChatPromptTemplate
from common_gpt import get_llm
from pathlib import Path
from langchain_text_splitters import RecursiveCharacterTextSplitter

BASE_DIR = Path(__file__).parent
DATA_FILE = BASE_DIR/'data'/'products.txt'
DB_DIR = BASE_DIR/'chroma_db2'

# 문장을 청크로 나누기
text = DATA_FILE.read_text(encoding='utf-8')
splitter = RecursiveCharacterTextSplitter(
    chunk_size = 100,
    chunk_overlap = 10
)
chunks = splitter.split_text(text)

# 청크 벡터DB에 저장
client= chromadb.PersistentClient(path=str(DB_DIR))
collection = client.get_or_create_collection('products')
collection.upsert(
    ids = [f'product-{i}' for i in range(len(chunks))],
    documents = chunks
)

llm = get_llm()

prompt = ChatPromptTemplate.from_template("""
    너는 상품 상담원이다. 아래 검색 문서만 근거로 답해라.
    근거가 없으면 모른다고 답하고, 가격과 상품 ID를 정확히 표시해라.
    [검색 문서]
    {context}
    [질문]
    {question}
""")

chain = prompt | llm | StrOutputParser()

# 사용자 질문
question = '150 만원 이하이면서 메모리가 16GB인 상품은?'

# 질문과 유사한 상품 조회
result = collection.query(query_texts=[question], n_results=3)
docs = result['documents'][0]
context = '\n\n'.join(docs)

print(chain.invoke({"context": context, "question": question}))