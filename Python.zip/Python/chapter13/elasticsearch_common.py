# ElasticSearch 공통 모듈
import os
from elasticsearch import Elasticsearch

# 환경변수
ELASTICSEARCH_URL = os.getenv('ELASTICSEARCH_URL', 'http://localhost:9200')
PRODUCT_INDEX = os.getenv('ELASTICSEARCH_PRODUCT_INDEX', 'chapter13-products')
PRODUCT_VECTOR_INDEX = os.getenv('ELASTICSEARCH_VECTOR_INDEX', 'chapter13-products-vector')
PRODUCT_HYBRID_INDEX = os.getenv('PRODUCT_HYBRID_INDEX', 'chapter13-products-hybrid')

# ElasticSearch 클라이언트 생성
def get_elasticsearch() -> Elasticsearch:
    return Elasticsearch(ELASTICSEARCH_URL, request_timeout=30)

# 상품 검색
def keyword_search(question:str, count:int=3) ->list[dict]:
    client = get_elasticsearch()
    response = client.search(
        index=PRODUCT_INDEX,
        size = count,
        query={
            'multi_match': {
                'query' : question,
                'fields' : ['name^3', 'description^2', 'content']
            }
            # name^3: 상품명 필드를 3배 중요하게 검색
        },
    )
    return [hit['_source'] for hit in response['hits']['hits']]
'''
    {
        ...
        'hits':[
            ...
            hits : [
                {'_index': 인덱스, 'id': 기본키, '_source':{'name': 아이폰},
                {'_index': 인덱스, 'id': 기본키, '_source':{'name': 갤럭시}
            ]
        ]

    }
'''
# LLM 프롬프트용 문자열 만들기
def products_to_context(products : list[dict]) -> str:
    return '\n\n'.join(product['content'] for product in products)