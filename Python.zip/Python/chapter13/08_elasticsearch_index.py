import csv
# 엘라스틱서치 설치: pip install elasticsearch==8.15.0
from elasticsearch import helpers
from pathlib import Path
from elasticsearch_common import get_elasticsearch, PRODUCT_INDEX, keyword_search

BASE_DIR = Path(__file__).parent
CSV_FILE = BASE_DIR/'data'/'products.csv'

# 클라이언트 생성
client = get_elasticsearch()

# 서버 확인
if not client.ping():
    raise ConnectionError('ElasticSearch에 연결할 수 없습니다')

# 상품 인덱스 저장
if not client.indices.exists(index=PRODUCT_INDEX):
    client.indices.create(
        index=PRODUCT_INDEX,
        mappings={
            'properties':{
                'product_id': {'type' : 'keyword'},
                'name' : {'type' : 'text'},
                'price' : {'type' : 'integer'},
                'weight' : {'type' : 'float'},
                'memory' : {'type' : 'integer'},
                'description' : {'type' : 'text'},
                'content' : {'type' : 'text'},
            }
        }
    )

# CSV 문서를 인덱스에 저장
with CSV_FILE.open(encoding='utf-8', newline='') as file:
    products = []

    # CSV 파일을 딕셔너리로 읽어오는 객체(첫 줄은 자동으로 헤더로 인식)
    for row in csv.DictReader(file):
        product = {
            'product_id': row['product_id'],
            'name' : row['name'],
            'price': int(row['price']),
            'weight': float(row['weight']),
            'memory': int(row['memory']),
            'description': row['memory'],
        }
        product['content'] = (
            f'[{product["product_id"]}] {product["name"]}\n'
            f'가격: {product["price"]}원\n'
            f'무게: {product["weight"]}kg\n'
            f'메모리: {product["memory"]}GB\n'
            f'특징: {product["description"]}\n'
        )
        products.append(product)

# 딕셔너리를 엘라스틱서치 인덱스에 저장하기 위해 변환
actions = (
    {'_index': PRODUCT_INDEX, '_id:': product['product_id'], '_source': product}
    for product in products
)
# 엘라스틱서치 인덱스에 저장
helpers.bulk(client, actions)

# 인덱스 새로고침
client.indices.refresh(index=PRODUCT_INDEX)

print(f'{len(products)}개 상품 색인 완료: {PRODUCT_INDEX}')

# 상품 검색
products = keyword_search('라이트북', count=2)

for product in products:
    print(product['content'], '\n')
