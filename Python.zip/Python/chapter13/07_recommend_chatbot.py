import chromadb
from langchain_core.output_parsers import StrOutputParser
from langchain_core.prompts import ChatPromptTemplate
from pathlib import Path
from common_gpt import get_llm

DB_DIR = Path(__file__).parent/'chroma_db'

client = chromadb.PersistentClient(path=str(DB_DIR))
collection = client.get_or_create_collection('products')
llm = get_llm()

# 첫번째 체인 - 생략된 후속 질문
rewrite_prompt = ChatPromptTemplate.from_template("""
대화 기록을 참고해 마지막 질문을 검색 가능한 한 문장으로 다시 써라.
설명 없이 문장만 출력해라
대화기록: {history}
마지막 질문: {question}
""")
rewrite_chain = rewrite_prompt | llm | StrOutputParser()

# 두번째 체인
answer_prompt = ChatPromptTemplate.from_template("""
검색 문서만 근거로 질문에 답해라
검색 문서: {context}
질문: {question}                                                   
""")
answer_chain = answer_prompt | llm | StrOutputParser()

history = '사용자: 휴대성이 좋은 상품을 추천해 줘. AI: 미니북 12를 추천합니다'
question = '그것의 메모리는 얼마야?'

# 검색용 문장 생성
search_question = rewrite_chain.invoke({'history': history, 'question': question})

# 재작성된 문장으로 실제 벡터 검색
result = collection.query(query_texts=[search_question], n_results=2)
docs = result['documents'][0]

# 최종답변
print('바꾼 검색어: ', search_question)
answer = answer_chain.invoke({'context': '\n\n'.join(docs), 'question' : question})
print(answer)
