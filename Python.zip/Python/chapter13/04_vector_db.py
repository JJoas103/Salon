# ChromaDB에 저장하고 검색하기

from pathlib import Path

import chromadb
from langchain_text_splitters import RecursiveCharacterTextSplitter

base_dir = Path(__file__).parent
data_file = base_dir/'data'/'products.txt'
db_dir = base_dir/'chroma_db'

# 문장을 청크로 나누기
text = data_file.read_text(encoding='utf-8')
splitter= RecursiveCharacterTextSplitter(
    chunk_size = 100,
    chunk_overlap = 10
)
chunks = splitter.split_text(text)

# 청크를 벡터DB에 저장
client = chromadb.PersistentClient(path=str(db_dir)) # 벡터DB 저장
collection = client.get_or_create_collection(name='products') # 컬렉션(관계형 db에 테이블)

# 임베딩
collection.upsert(
    ids=[f'product-{i}' for i in range(len(chunks))],
    documents = chunks,
)
print(f'{len(chunks)}개의 청크를 저장했습니다: {db_dir}')

# query_texts: 데이터 조회
# n_results: 질문과 가장 유사한 문서 요청
result = collection.query(
    query_texts=['매일 들고 다닐 가벼운 노트북'],
    n_results=2,
)
for text in result['documents'][0]:
    print(text, '\n')