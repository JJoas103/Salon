import chromadb
from langchain_core.output_parsers import StrOutputParser
from langchain_core.prompts import ChatPromptTemplate
from pathlib import Path
from common_gpt import get_llm

DB_DIR = Path(__file__).parent/'chroma_db'

client = chromadb.PersistentClient(path=str(DB_DIR))
llm = get_llm(temperature=0.1)

prompt = ChatPromptTemplate.from_template("""
너는 상품 상담원이다. 아래 검색 문서만 근거로 답해라.
근거가 없으면 모른다고 답하고, 가격과 상품ID를 정확히 표시해라.
[검색 문서]
{context}
[질문]
{question}
""")

chain = prompt | llm | StrOutputParser()
collection = client.get_or_create_collection('products')

question = '90만 원 이하이면서 메모리가 16GB인 상품은?'
result = collection.query(query_texts=[question], n_results=3)
docs = result['documents'][0]

context = '\n\n'.join(docs)
answer = chain.invoke({'context': context, 'question':question})

print(answer)
