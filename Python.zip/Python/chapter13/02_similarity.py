from math import sqrt
from chromadb.utils.embedding_functions import DefaultEmbeddingFunction

# 코사인 유사도 검사
def cosine_similarity(vector_a, vector_b):
    dot_product = sum(a * b for a, b in zip(vector_a, vector_b))
    magnitude_a = sqrt(sum(a * a for a in vector_a))
    magnitude_b = sqrt(sum(b * b for b in vector_b))
    return dot_product / (magnitude_a * magnitude_b)

sentences = [
    '라이트북 14는 가볍고 휴대성이 좋은 노트북이다',
    '매일 들고 다니기 편한 가벼운 컴퓨터를 찾고 있다',
    '파워북 15는 영상 편집에 적합한 고성능 노트북이다'
]

# 임베딩 함수를 사용해 문장을 벡터화
embed = DefaultEmbeddingFunction()
vectors = embed(sentences)

# 코사인 유사도 검사
similar_score = cosine_similarity(vectors[0], vectors[1])
different_score = cosine_similarity(vectors[0], vectors[2])

# 기준문장
print(sentences[0])

# 문장별 코사인 유사도
print(f'{sentences[1]}\n->{similar_score:.4f}')
print(f'{sentences[2]}\n->{different_score:.4f}')

# 결과
if similar_score > different_score:
    print('휴대성을 표현한 문장이 기준 문장과 더 가깝습니다')
else:
    print('임베딩 모델에 따라 예상과 다른 결과가 나올 수 있습니다')