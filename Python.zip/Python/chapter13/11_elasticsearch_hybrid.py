import csv
from elasticsearch import helpers
from langchain_core.output_parsers import StrOutputParser
from langchain_core.prompts import ChatPromptTemplate
from common_gpt import get_llm
from pathlib import Path
from sentence_transformers import SentenceTransformer
from elasticsearch_common import get_elasticsearch, PRODUCT_HYBRID_INDEX

EMBEDDING_MODEL = 'sentence-transformers/paraphrase-multilingual-MiniLM-L12-v2'

# 검색 점수 가중치
KEYWORD_BOOST = 0.7
VECTOR_BOOST = 0.3

# CSV 상품 불러오기
CSV_FILE = Path(__file__).parent/'data'/'products.csv'
with CSV_FILE.open(encoding='utf-8', newline='') as file:
    products = []
    for row in csv.DictReader(file):
        product = {
            'product_id' : row['product_id'],
            'name' : row['name'],
            'price' : int(row['price']),
            'weight' : float(row['weight']),
            'memory' : int(row['memory']),
            'description' : row['description'],
        }
        product['content'] = (
            f'[{product["product_id"]}] {product["name"]} \n'
            f'가격: {product["price"]}원 \n'
            f'무게: {product["weight"]}kg \n'
            f'메모리: {product["memory"]}GB \n'
            f'특징: {product["description"]} \n'
        )
        products.append(product)

contents = [product['content'] for product in products]
embedding_model = SentenceTransformer(EMBEDDING_MODEL)
vectors = embedding_model.encode(contents, normalize_embeddings=True).tolist()
dims = len(vectors[0])

# 인덱스에 상품 저장
client = get_elasticsearch()
if not client.indices.exists(index=PRODUCT_HYBRID_INDEX):
    client.indices.create(
        index=PRODUCT_HYBRID_INDEX,
        mappings = {
            'properties' : {
                'product_id' : {'type' : 'keyword'},
                'name' : {'type' : 'text', 'analyzer' : 'nori'},
                'price' : {'type' : 'integer'},
                'weight' : {'type' : 'float'},
                'memory' : {'type' : 'integer'},
                'description' : {'type' : 'text', 'analyzer' : 'nori'},
                'content' : {'type' : 'text', 'analyzer' : 'nori'},
                'embedding' : {
                    'type' : 'dense_vector',
                    'dims' : dims,
                    'index' : True,
                    'similarity' : 'cosine',
                    },
                }
            },
        )
actions = (
    {
        '_index' : PRODUCT_HYBRID_INDEX,
        '_id' : product['product_id'],
        '_source' : {
            **product,
            'embedding' : [float(value) for value in vector],
        }, 
    }
    for product, vector in zip(products, vectors)
)
helpers.bulk(client, actions)
client.indices.refresh(index=PRODUCT_HYBRID_INDEX)

# 질문
question = '매일 들고 다니기 편한 학습용 노트북'

# 질문을 벡터화
query_vector = embedding_model.encode(
    question,
    normalize_embeddings=True
).tolist()

response = client.search(
    index = PRODUCT_HYBRID_INDEX,
    size = 3,
    query = {
        'multi_match' : {
            'query' : question,
            'fields' :  ['name^3', 'description^2', 'content'],
            'boost' : KEYWORD_BOOST
        }
    },
    knn = {
        'field' : 'embedding',
        'query_vector' : query_vector,
        'k' : 3,
        'num_candidates' : 10,
        'boost' : VECTOR_BOOST,
    },
)
# 조회된 상품 확인
for hit in response['hits']['hits']:
    print(f'점수: {hit["_score"]:.4f}')
    print(f'{hit["_source"]["content"]}')

# 프롬프트에 전달할 상품들을 하나의 문자열로 변환
context = '\n\n'.join(
    hit['_source']['content'] for hit in response['hits']['hits']
)

prompt = ChatPromptTemplate.from_template("""
아래 검색 결과만 근거로 질문에 답하라.
상품ID, 상품명, 가격과 추천이유를 표시해라.
[검색결과]
{context}
[질문]
{question}                                                                                 
""")
chain = prompt | get_llm() | StrOutputParser()
print(chain.invoke({'context': context, 'question' : question}))