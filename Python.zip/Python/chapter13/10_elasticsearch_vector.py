import csv
from elasticsearch import helpers
from langchain_core.output_parsers import StrOutputParser
from langchain_core.prompts import ChatPromptTemplate
from common_gpt import get_llm
from pathlib import Path
# pip install sentence_transformers
from sentence_transformers import SentenceTransformer
from elasticsearch_common import get_elasticsearch, PRODUCT_VECTOR_INDEX

EMBEDDIING_MODEL = 'sentence-transformers/paraphrase-multilingual-MiniLM-L12-v2'
CSV_FILE = Path(__file__).parent/'data'/'products.csv'
client = get_elasticsearch()

# CSV를 읽어 상품을 딕셔너리로 가져오기
with CSV_FILE.open(encoding='utf-8', newline='') as file : 
    products = []
    for row in csv.DictReader(file):
        product = {
            'product_id' : row['product_id'],
            'name' : row['name'],
            'price' : row['price'],
            'weight' : row['weight'],
            'memory' : row['memory'],
            'description' : row['description'],
        }
        product['content'] = (
            f'[{product["product_id"]}. {product["name"]}]\n'
            f'가격: {product["price"]}원\n'
            f'무게: {product["weight"]}kg\n'
            f'메모리: {product["memory"]}GB\n'
            f'특징: {product["description"]}'
        )
        products.append(product)

# 상품의 content를 벡터화
contents = [product['content'] for product in products]
embedding_model = SentenceTransformer(EMBEDDIING_MODEL)
vectors = embedding_model.encode(contents, normalize_embeddings=True).tolist()
dims = len(vectors[0])

# 상품을 인덱스에 저장
if not client.indices.exists(index=PRODUCT_VECTOR_INDEX):
    client.indices.create(
        index=PRODUCT_VECTOR_INDEX,
        mappings={
            'properties':{
                'product_id' : {'type' : 'keyword'},
                'name' : {'type' : 'text'},
                'price' : {'type' : 'integer'},
                'weight' : {'type' : 'float'},
                'memory' : {'type' : 'integer'},
                'description' : {'type' : 'text'},
                'content' : {'type' : 'text'},
                'embedding' : {
                    'type' : 'dense_vector',
                    'dims' : dims,
                    'index' : True,
                    'similarity' : 'cosine'
                },
            }
        },
    )
action = (
    {
        '_index' : PRODUCT_VECTOR_INDEX,
        '_id' : product['product_id'],
        '_source' : {
            **product,
            'embedding' : [float(value) for value in vector]
        },
    }
    for product, vector in zip(products, vectors)
)
helpers.bulk(client, action)
client.indices.refresh(index=PRODUCT_VECTOR_INDEX)

question = '매일 들고 다니기 편한 공부용 컴퓨터'

# 사용자의 질문을 벡터로 변환
query_vector = embedding_model.encode(
    question,
    normalize_embeddings=True,
).tolist()

# 사용자의 질문과 가장 유사한 상품을 인덱스에서 찾기
response = client.search(
    index=PRODUCT_VECTOR_INDEX,
    knn={
        'field': 'embedding',
        'query_vector': query_vector,
        'k' : 3,
        'num_candidates' : 10
    }
)
for hit in response['hits']['hits']:
    print(f'점수: {hit["_score"]:.4f}')
    print(hit['_source']["content"], '\n')

context = '\n\n'.join(hit['_source']['content'] for hit in response['hits']['hits'])

prompt = ChatPromptTemplate.from_template("""
아래 의미 검색 결과만 근거로 질문에 답해라.
검색 결과: {context}
질문: {question}
""")
chain = prompt | get_llm() | StrOutputParser()
print('[최종 답변]')
print(chain.invoke({"context": context, "question" : question}))