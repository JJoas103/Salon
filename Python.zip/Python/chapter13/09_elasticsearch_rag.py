from langchain_core.output_parsers import StrOutputParser
from langchain_core.prompts import ChatPromptTemplate
from langchain_core.runnables import RunnablePassthrough
from elasticsearch_common import keyword_search, products_to_context
from common_gpt import get_llm

# 사용자의 질문을 받으면 ES를 검색해 LLM context 만들기
def retrive(data: dict) -> str:
    return products_to_context(keyword_search(data['question'], count=3))

es_rag = RunnablePassthrough.assign(context=retrive)

llm = get_llm(0.5)

prompt = ChatPromptTemplate.from_template("""
아래 검색 결과만 근거로 답해라.
상품 ID, 상품명, 가격과 추천 이유를 표시해라.
[검색결과]                                                                                  
{context}                                         
[질문]
{question}                                          
""")

chain = es_rag | prompt | llm | StrOutputParser()
print(chain.invoke({'question': '영상 편집 노트북을 추천해 줘'}))
# 사용자의 질문 => 엘라스틱서치에서 검색된 상품 => 프롬프트 => LLM => 답변