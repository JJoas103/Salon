# pip install langchain_text_splitters

from langchain_text_splitters import RecursiveCharacterTextSplitter
from pathlib import Path

data_file = Path(__file__).parent/'data'/'products.txt'
text = data_file.read_text(encoding='utf-8')

# 최대 100자씩 나누고, 문백이 끊기지 않게 앞뒤 10자 겹침
splitter = RecursiveCharacterTextSplitter(
    chunk_size = 100,
    chunk_overlap = 10
)

# 긴 텍스트를 작은 청크(조각)로 나누기
chunk = splitter.split_text(text)

print('원본 파일 글자 수: ', len(text))
print('청크 수: ', len(chunk))
print('결과 타입: ', type(chunk).__name__)

for index, chunk in enumerate(chunk):
    print(f'\n[{index}] {chunk}')