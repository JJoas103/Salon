# chromadb 설치: pip install 
from chromadb.utils.embedding_functions import DefaultEmbeddingFunction

sentences = [
    '라이트북 14는 가볍고 휴대성이 좋은 노트북이다',
    '파워북 15는 영상 편집에 적합한 고성능 노트북이다'
]

embed = DefaultEmbeddingFunction()
vectors = embed(sentences)

print('[임베딩 대상 상품]')
print(sentences[0])
print('\n벡터 개수: ', len(vectors))
print('벡터 차원: ', len(vectors[0]))
print('첫번째 벡터의 앞 5개 숫자: ', vectors[0][:5])

