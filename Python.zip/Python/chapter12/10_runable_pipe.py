from langchain_core.runnables import RunnableLambda

def get_question(data: dict) -> str:
    return data["question"]

def add_label(question: str) -> str:
    return f'사용자 질문: {question}'

runnable_question = RunnableLambda(get_question)
runnable_label = RunnableLambda(add_label)

chain = runnable_question | runnable_label

result = chain.invoke({
    'question' : '3만원 이하 티셔츠를 추천해 줘',
    'user_id' : 10
})
# result = chain.invoke('안녕')
print(result)