# from common import get_llm
from common_gpt import get_llm
from langchain_core.prompts import ChatPromptTemplate
from langchain_core.output_parsers import StrOutputParser

prompt = ChatPromptTemplate.from_messages([
    ("system", '너는 상품 설명 전문가다. 과장하지 말고 3줄로 답한다.'),
    ('human', '{product}의 장점은 {audience}에게 설명해 줘')
])

llm = get_llm()

chain = prompt | llm | StrOutputParser()
# LCEL(LangChain Expression Language): 각 단계(체인)를 파이썬 파이프 연산자(|)로 조립
# LCEL 컴포넌트는 Runnable 인터페이스를 구현했기 때문에 체인으로 연결 가능
# 프롬프트 > 모델 > 파서 > 최종문자열

answer = chain.invoke({'product':'기계식 키보드', 'audience': '코딩입문자'})
print(answer)

