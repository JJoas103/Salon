# from common import get_llm
from common_gpt import get_llm
from langchain_core.prompts import ChatPromptTemplate
from langchain_core.output_parsers import StrOutputParser

prompt = ChatPromptTemplate.from_messages([
    ("system", '너는 상품 설명 전문가다. 과장하지 말고 3줄로 답한다.'),
    ('human', '{product}의 장점은 {audience}에게 설명해 줘')
])
prompt_value = prompt.invoke({'product':'기계식 키보드', 'audience': '코딩입문자'})

llm = get_llm()
ai_message = llm.invoke(prompt_value)

answer = ai_message.content

print(answer)