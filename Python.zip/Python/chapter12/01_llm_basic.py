from common import get_llm

llm = get_llm()

response = llm.invoke('안녕')
print(response)
print(response.content)
print(type(response)) # AIMessage 타입