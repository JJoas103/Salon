from common_gpt import get_llm
from langchain_core.runnables import RunnablePassthrough
from langchain_core.prompts import ChatPromptTemplate
from langchain_core.output_parsers import StrOutputParser

#  프롬프트 -> LLM -> 문자열 반환

def search_product(data: dict) -> str:
    return (
        '상품명: 검정티셔츠\n'
        '가격: 29,900원\n'
        '할인율: 10%'
    )
prompt = ChatPromptTemplate.from_template('''
다음 상품 정보만 사용해 질문에 답해 줘.
[상품 정보] {context}
[질문] {question}
''')
llm = get_llm(0)

chain = (
    RunnablePassthrough.assign(context=search_product) 
    | prompt 
    | llm 
    | StrOutputParser()
)
answer = chain.invoke({
    'question' : '3만원 이하 상품??'
})
print(answer)