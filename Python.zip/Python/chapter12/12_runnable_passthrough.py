from langchain_core.runnables import RunnablePassthrough
# RunnablePassthrough: 입력을 수정하지 않고 그대로 반환

passthrough = RunnablePassthrough()

data = {
    'product' : '기계식 키보드',
    'audience' : '코딩 입문자',
    'user_id' : 10
}
result = passthrough.invoke(data)
print('입력: ', data)
print('출력: ', result)