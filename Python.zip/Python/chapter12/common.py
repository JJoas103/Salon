# pip install langchain_ollama
import os
from langchain_ollama import ChatOllama

MODEL_NAME = os.getenv('OLLAMA_MODEL', 'qwen3:8b')

def get_llm(temperature: float = 0.2) -> ChatOllama:
    # temperature가 낮으면 답변이 비교적 사실적
    # temperature가 높으면 답변의 표현이 다양해지지만 결과의 변동이 커짐
    return ChatOllama(model=MODEL_NAME, temperature=temperature)