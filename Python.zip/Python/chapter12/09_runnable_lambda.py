from langchain_core.runnables import Runnable, RunnableLambda

def add_greeting(name : str) -> str:
    return f'안녕하세요, {name}님'

def add_exclamation(message : str)->str:
    return message + '!!!'

# greeting = add_greeting('홍길동')
# exclamtion = add_exclamation(greeting)
# print(exclamtion)

runable_greeting = RunnableLambda(add_greeting)
runable_exclamation = RunnableLambda(add_exclamation)
print('runable_greeting은 Runable? ', isinstance(runable_greeting, Runnable))
print('runable_exclamation은 Runable? ', isinstance(runable_exclamation, Runnable))

# greeting = runable_greeting.invoke('홍길동')
# exclamtion = runable_exclamation.invoke(greeting)
# print(exclamtion)
chain = runable_greeting | runable_exclamation
print(chain.invoke('홍길동'))