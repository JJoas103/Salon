from common_gpt import get_llm
from langchain_core.messages import AIMessage, HumanMessage, SystemMessage

# 상품 목록 테이블
products = [
    {"name": "라이트북 14", "price": 790000, "weight": 1.25, "memory": 16},
    {"name": "파워북 15", "price": 1090000, "weight": 1.75, "memory": 32},
    {"name": "스터디북 13", "price": 650000, "weight": 1.10, "memory": 8},
]

# 상품 정리
def make_table(items: list[dict]) -> str:
    lines = []
    for item in items:
        lines.append(
            f'-{item["name"]} / {item["price"]}원 / {item["weight"]}kg / {item["memory"]}GB'
        )
        # '스터디북 13 / 650000원 / 1.10kg / 8GB' \n
    return '\n'.join(lines)

llm = get_llm(0.2)

messages = [
    SystemMessage(content=f'''
너는 상품 비교 상담원이다. 아래 상품 정보만 근거로 답한다.
정보가 없으면 "목록에서 확인할 수 없습니다"라고 말한다.
{make_table(products)}
''')                          
]

print('상품 비교 챗봇입니다 종료하려면 종료를 입력하세요')

while True:
    question = input('\n나: ').strip()
    if question.lower() in {'종료', 'exit', 'quit'}:
        print('챗봇: 상담을 종료합니다')
        break
    if not question:
        continue

    messages.append(HumanMessage(content=question))
    answer = llm.invoke(messages)
    print('챗봇: ', answer.content)