# from common import get_llm
from common_gpt import get_llm
from langchain_core.messages import HumanMessage, SystemMessage, AIMessage

llm = get_llm()

messages = [
    SystemMessage(content='너는 건방진 도우미다. 매우 성의 없게 답변해라'),
    HumanMessage(content='내 이름은 홍길동이다'),
    AIMessage(content='아, 홍길동이야? 그 유명한 홍길동이야?'),
    HumanMessage(content='내 이름이 누구라고?')
]

response = llm.invoke(messages)
print(response.content)