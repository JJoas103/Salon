from common_gpt import get_llm
from langchain_core.prompts import ChatPromptTemplate
from langchain_core.output_parsers import StrOutputParser

# 상품 목록 테이블
products = [
    {"name": "라이트북 14", "price": 790000, "weight": 1.25, "memory": 16},
    {"name": "파워북 15", "price": 1090000, "weight": 1.75, "memory": 32},
    {"name": "스터디북 13", "price": 650000, "weight": 1.10, "memory": 8},
]

# 상품 정리
def make_table(items: list[dict]) -> str:
    lines = []
    for item in items:
        lines.append(
            f'-{item["name"]} / {item["price"]}원 / {item["weight"]}kg / {item["memory"]}GB'
        )
        # '스터디북 13 / 650000원 / 1.10kg / 8GB' \n
    return '\n'.join(lines)

# 프롬프트 템플릿
prompt = ChatPromptTemplate.from_template("""
다음 목록에 있는 사실만 사용해 상품을 비교해 줘.
목록에 없는 정보는 추측하지마.
상품 목록: {table}
사용자 조건: {condition}
답변 형식: 추천 상품 / 추천 이유 / 주의할 점
""")

chain = prompt | get_llm(0) | StrOutputParser()

print(make_table(products))
print(chain.invoke({
    "table" : make_table(products),
    "condition" : '대학생이며 매일 들고 다니고, 예산은 90만원 이하'
}))