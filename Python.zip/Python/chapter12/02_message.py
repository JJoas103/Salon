# pip install langchain_core
from common import get_llm
from langchain_core.messages import HumanMessage, SystemMessage

# SystemMessage: 모델의 역할과 답변 규칙을 결정
# HumanMessage: 사용자의 실제 질문

llm = get_llm()

message = [
    SystemMessage(content='너는 건방진 도우미다. 매우 성의 없게 답변해라'),
    HumanMessage(content='노트북을 살 때 고려해야 할 기준 3가지는?')
]
response = llm.invoke(message)
print(response.content)