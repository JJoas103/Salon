from langchain_core.runnables import RunnablePassthrough
# RunnablePassthrough: 입력을 수정하지 않고 그대로 반환

passthrough = RunnablePassthrough()

data = {
    'product' : '기계식 키보드',
    'audience' : '코딩 입문자',
    'user_id' : 10
}
def search_product(data: dict) -> str:
    return '검정 티셔츠 / 29,900원 / 할인율 10%'

add_context = RunnablePassthrough.assign(
    context=search_product
)
# assign(): 기존 값은 유지하고, 새로운 키를 추가해 값을 설정
print('assign 실행 전: ', data)
print('assign 실행 후: ', add_context.invoke(data))