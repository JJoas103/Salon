from common_gpt import get_llm
from langchain_core.prompts import ChatPromptTemplate
from langchain_core.output_parsers import StrOutputParser
from langchain_core.runnables import Runnable

prompt = ChatPromptTemplate.from_template(
    "{product}의 장점을 초보자에게 한 문장으로 설명해 줘"
)
llm = get_llm(0.2)
output_parser = StrOutputParser()

print('prompt는 Runable? ', isinstance(prompt, Runnable))
print('llm은 Runable? ', isinstance(llm, Runnable))
print('output_parser는 Runable? ',isinstance(output_parser, Runnable))

# prompt_value = prompt.invoke({'product' : '신라면'})
# llm_response = llm.invoke(prompt_value)
# answer = output_parser.invoke(llm_response)

chain = prompt | llm | output_parser
print('chain은 Runable? ', isinstance(chain, Runnable))
# answer = chain.invoke({'product' : '신라면'})
# print(answer)
