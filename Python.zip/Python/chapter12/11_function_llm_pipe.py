from common_gpt import get_llm
from langchain_core.output_parsers import StrOutputParser
from langchain_core.prompts import ChatPromptTemplate
from langchain_core.runnables import RunnableLambda

def prepare_prompt_data(data: dict) -> dict:
    return {
        'product': data['product'],
        'audience' : data['audience']
    }
prepare_runnable = RunnableLambda(prepare_prompt_data)

prompt = ChatPromptTemplate.from_template("""
    {product}의 장점을 {audience}에게 두 문장으로 설명해줘
""")
llm = get_llm(0.2)

chain = prepare_runnable | prompt | llm | StrOutputParser()

answer = chain.invoke({
    'product' : '기계식 키보드',
    'audience' : '코딩 입문자',
    'user_id' : 10
})
print(answer)