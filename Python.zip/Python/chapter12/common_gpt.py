# pip install dotenv
from dotenv import load_dotenv
# pip install langchain_openai
from langchain_openai import ChatOpenAI
import os

load_dotenv()

MODEL_NAME = os.getenv("OPENAI_MODEL", "gpt-4o-mini")

def get_llm(temperature: float = 0.2) -> ChatOpenAI:
    return ChatOpenAI(model=MODEL_NAME, temperature=temperature)