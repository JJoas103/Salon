# 상품 색인과 검색을 제공하는 MCP 서버

from typing import Any
from mcp.server.fastmcp import FastMCP
from elasticsearch_store import prepare_index, hybrid_search

# MCP 서버 객체 생성
mcp = FastMCP(
    "musinsa-product-rag",
    instructions='구조화된 가격, 할인 조건으로 상품을 검색합니다.'
)

# LLM이 어떤 Tool을 어떻게 호출해야 하는지 알려주는 안내문
SEARCH_GUIDE = """
# 상품 검색 Tool 사용 안내
- query에는 상품 종류와 특징만 넣습니다. 예: `여름 티셔츠`, `출근용 바지`
- `3만원 이하`는 max_price=30000으로 전달합니다.
- `할인율 30% 이상은` min_discount=30으로 전달합니다.
- 가격이나 할인 조건이 없으면 해당 인자는 null로 둡니다.
- 후속 질문은 최근 Tool 결과를 먼저 참조하고, 새로운 조건이 생겼을 때 검색합니다.
- 상품명, 가격, 할인율, URL은 Tool 결과에 있는 값만 답변에 사용합니다.
""".strip()

# MCP 리소스 등록
@mcp.resource('catalog://musinsa/search-guide')
def search_guide() -> str:
    """상품 검색 Tool의 인자 변환 규칙과 답변 근거 규칙이다."""
    return SEARCH_GUIDE

# MCP 프롬프트 등록
@mcp.prompt()
def shopping_chat_prompt(tone: str = '친절하고 간결한') -> str:
    """사용자가 선택할 수 있는 상품 상담 프롬프트 템플릿이다."""
    return (
        f'{tone} 무신사 상품 상담을 진행해 주세요. 상품 검색이 필요한 첫 질문에는 '
        'prepare_product_index를 먼저 호출하고, search_product를 호출하세요. '
        '사용자의 자연어 가격과 할인 조건은 search_product의 숫자 인자로 구조화하세요. '
        '"그중", "두 번째", "방금 상품" 같은 후속 질문은 최근 대화와 Tool 결과를 사용하고 ' 
        '불필요한 재검색을 피하세요.'
    )

# MCP 도구 등록(1): 인덱스 생성
@mcp.tool()
def prepare_product_index() -> dict[str, Any]:
    """전용 Elasticsearch 인덱스와 무신사 상품을 준비한다."""
    return prepare_index()

# MCP 도구 등록(2): 상품 검색
@mcp.tool()
def search_product(
    query: str,
    max_price: int | None = None,
    min_discount: int | None = None,
    count: int = 5
) -> dict[str, Any]:
    """상품을 검색한다. 가격은 원 단위 상한, 할인율은 퍼센트 하한으로 받는다.
    query에는 가격, 할인 표현을 제외한 상품 종류나 특징을 넣는다.
    예를 들어 '3만원 이하 티셔츠'는 query='티셔츠', maxt_price=30000이다.
    """
    if max_price is not None: 
        if max_price <=0 or max_price > 100000000:
            raise ValueError('max_price는 1원 이상 1억 원 이하이어야 합니다.')
    
    if min_discount is not None: 
        if min_discount < 0 or min_discount > 100:
            raise ValueError('min_discount 0 이상 100 이하이어야 합니다.')
    
    if count < 1:
        count = 1
    elif count > 10:
        count = 10
    
    # es에서 검색
    products = hybrid_search(query=query, 
                             max_price=max_price, 
                             min_discount=min_discount,
                             count=count)
    
    # LLM에게 전달
    return {
        'query' : query,        # 어떤 검색어로 찾았는지
        'filters' : {           # 어떤 조건으로 찾았는지
            'max_price' : max_price,
            'min_discount' : min_discount,
        },
        'result_count' : len(products), # 몇 건 찾았는지
        'products' : products           # 실제 검색된 상품 들
    }

if __name__ == '__main__':
    mcp.run(transport='stdio')