import asyncio
import sys
from pathlib import Path

from langchain.agents import create_agent
from langchain_core.messages import AIMessage, HumanMessage, ToolMessage
from langchain_mcp_adapters.client import MultiServerMCPClient
from langchain_mcp_adapters.prompts import load_mcp_prompt
from langchain_mcp_adapters.resources import load_mcp_resources
from langchain_mcp_adapters.tools import load_mcp_tools

from llm import get_llm

MCP_SERVER = Path(__file__).with_name('mcp_product_server.py')
MCP_RESOURCE = 'catalog://musinsa/search-guide'

# 메인: MCP 서버와 한 세션을 유지하면서 사용자 질문 처리
async def main() -> None:
    client = MultiServerMCPClient(
        {
            'products':{
                'transport' : 'stdio',
                'command' : sys.executable,
                'args' : [str(MCP_SERVER)]
            }
        }
    )
    # 세션 처리
    async with client.session('products') as session:
        # 도구 불러오기
        tools = await load_mcp_tools(session)
        # 리소스 불러오기
        resources = await load_mcp_resources(session, uris=MCP_RESOURCE)
        # 프롬프트 불러오기
        prompt = await load_mcp_prompt(
            session, 'shopping_chat_prompt', arguments={'tone' : '친절하고 간결한'}
        )

        # 에이전트 생성
        agent = create_agent(
            get_llm(),
            tools,
            system_prompt=(
                '상품 정보는 MCP Tool 결과만 근거로 답하세요.'
                '검색 결과에 없는 상품명, 가격, 할인율, URL은 만들지 마세요.'
                'Tool 호출 여부와 인자는 현재 질문과 대화기록을 바탕으로 판단하세요.'
            )
        )

        # 메시지 생성
        messages = list(prompt)
        messages.append(HumanMessage
                        (content=f'[MCP Resource : {MCP_RESOURCE}]\n{resources[0].as_string()}'))


        # 챗봇
        print('무신사 MCP RAG 챗봇')
        print('예: 3만원 이하 티셔츠 추천해 줘')
        print('후속 질문 예: 그 중 두번째 상품 링크 알려 줘')
        print('종료하려면 "종료"를 입력하세요.')

        while True:
            question = input('\n나: ').strip()
            if not question:
                continue
            if question.lower() in {'종료', 'exit', 'quit'}:
                print('챗봇: 상담을 종료합니다.')
                break
        
            # 기존 메시지에서 사용자의 질문을 추가
            request_message = messages.copy()
            request_message.append(HumanMessage(content=question))

            try:
                #에이전트 호출: 요청메시지를 전달하고, 응답메시지를 받음
                result = await agent.ainvoke(
                    {'messages' : request_message},
                    config={'recursion_limit' : 12}
                )
                
            except Exception as error:
                print('챗봇: Tool 또는 LLM 호출에 실패했습니다.')
                print('상세2 오류: ', error)
                continue

            # 로그 확인용
            new_messages = result['messages'][len(messages):]
            for message in new_messages:
                if isinstance(message, AIMessage) and message.tool_calls:
                    for call in message.tool_calls:
                        print(f'[Tool 요청] {call["name"]} {call["args"]}')
                elif isinstance(message, ToolMessage):
                        print(f'[Tool 결과] {message.name} {message.content}')

            
            # 기존 메시지 업데이트
            messages = result['messages']
            print('챗봇: ', messages[-1].content)

if __name__ == '__main__':
    asyncio.run(main())
