# 리스트(순서 O, 변경 O)
# 데이터가 계속 추가/삭제/변경될 때 사용

fruits = ['사과', '바나나', '체리']

# 인덱스로 요소 접근
print(fruits[0], fruits[-1])    # 첫번째, 마지막 요소 접근 

# append(): 리스트 맨 끝에 요소 추가
fruits.append('포도')
print('append() 후: ', fruits)

# 인덱스 위치 값 변경
fruits[1] = '수박'
print('인덱스 위치 값 변경 후: ', fruits)

# 슬라이싱
print('슬라이싱 1~2: ', fruits[1:3])    #인덱스 1~2
print('슬라이싱 처음부터 2개: ', fruits[:2])    #처음부터 2개

# 리스트 메서드
numbers = [3, 1, 4, 2, 5]

# sort(): 리스트 요소를 오름차순으로 정렬
numbers.sort()
print(numbers)

# len(): 리스트 요소 개수 출력
print('요소의 개수: ', len(numbers))

# 중첩 리스트: 2차원 리스트(행 열)
matrix = [[1, 2], [3, 4]]
print('중첩리스트: ', matrix)
print('두번째 행의 첫번째 값: ', matrix[1][0])