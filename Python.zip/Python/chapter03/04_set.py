# 집합(set)
# 순서X, 중복X

tags = {'전자', '오디오', '블루투스', '전자'}
print(tags) # 중복 제거

# add(): 요소 추가
tags.add('충전')

# discard(): 요소 제거
tags.discard('오디오')

# 리스트에서 중복 제거
items = ['사과', '바나나', '사과', '체리']
unique = list(set(items))

print('중복제거된 리스트: ', unique)