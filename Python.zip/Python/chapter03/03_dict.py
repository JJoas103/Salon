# 딕셔너리

product = {
    "name": "무선 이어폰",
    "price": 89000,
    "in_stock": True,
}

# 키로 값 접근
print(product["name"])

# 기존 키 값 수정
product["price"] = 79000
print(product["price"])

# 새 키 추가
product['color'] = '블랙'
print(product["color"])

print('-'*30)

# 키 값 순회
# for key in 딕셔너리: 딕셔너리 키만 순회
for key in product:
    print(key, product[key])

print('-'*30)
# items(): (키, 값) 튜플로 순회
for key, value in product.items():
    print(f'{key} : {value}')

print('-'*30)

# 딕셔너리 메서드
# list(딕셔너리.keys()): 딕셔너리의 모든 키 들을 리스트로 변환해 출력
print(list(product.keys()))

# list(딕셔너리.values()): 딕셔너리의 모든 값 들을 리스트로 변환해 출력
print(list(product.values()))