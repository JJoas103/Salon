# 튜플(순서O, 변경X)
# 데이터가 변경되지 않을 때 사용(rgb 값 등)

point = (10, 20)

# 인덱스로 요소 접근
print(point[0], point[1])

# 요소 1개(쉼표 필수)
single = (30, )
print('single: ', single)
print(type(single)) # <class 'tuple'>

# 언패킹: 튜플 또는 리스트에 담긴 값들을 하나씩 꺼내 여러 변수에 담는 것
x, y = point
print('언패킹 후: ', x, y)