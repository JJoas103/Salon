# 산술 연산자
a, b = 10, 3

print('더하기: ', a + b)
print('빼기: ', a - b)
print('곱하기: ', a * b)
print('나누기: ', a / b) 
print('몫: ', a // b)   # 몫(정수)
print('나머지: ', a % b) # 나머지
print('거듭제곱: ', a**b) # 거듭제곱