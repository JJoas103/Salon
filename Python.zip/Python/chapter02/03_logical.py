# 논리 연산자

has_coupon = True
in_stock = False

# and: 양쪽 모두 True일 때만 True
print('쿠폰 있고 재고 있음: ', has_coupon and in_stock)
# or: 한쪽이라도 Treu면 True
print('쿠폰 또는 재고 있음: ', has_coupon or in_stock)
# not: True <-> False 반전
print('재고 있음: ', not in_stock)

# is (==와 유사하지만 더 엄격한 비교)
price = 45000
budget = 50000
can_buy = price <= budget and in_stock is True
print('예산 내 구매 가능: ', can_buy)
