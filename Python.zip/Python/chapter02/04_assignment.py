# 할당 연산자

count = 0
count += 1  # count = count + 1
print('count: ', count)

score = 17
score //= 5 # score = score // 5
print('score: ', score)