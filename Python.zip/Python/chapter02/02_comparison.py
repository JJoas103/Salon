# 비교 연산자
original = 50000
sale = 35000

print('원가 > 할인가: ', original > sale)
print('원가 == 할인가: ', original == sale)
print('할인가 3만~4만 사이: ', sale >= 30000 and sale <=40000)

# in 연산자: 문자열 포함 여부 확인
keyword = '무신사'
print("'무'가 포함?: ", '무' in keyword)
print("'나'가 포함?: ", '나' in keyword)