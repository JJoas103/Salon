<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<!DOCTYPE html>
<html lang="ko">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Chapter 15-1 | Spring → FastAPI</title>
    <style>
        :root {
            color-scheme: light;
            --ink: #172033;
            --muted: #64748b;
            --line: #dbe4ee;
            --surface: #ffffff;
            --accent: #2563eb;
            --accent-dark: #1d4ed8;
            --code: #111827;
            --page: #f4f7fb;
        }

        * { box-sizing: border-box; }

        body {
            margin: 0;
            color: var(--ink);
            background: var(--page);
            font-family: Pretendard, "Noto Sans KR", Arial, sans-serif;
        }

        header {
            padding: 44px 24px 38px;
            color: white;
            background: linear-gradient(125deg, #102a56, #2563eb 72%, #38bdf8);
        }

        header > div, main {
            width: min(1080px, calc(100% - 32px));
            margin: 0 auto;
        }

        h1 { margin: 0 0 10px; font-size: clamp(28px, 5vw, 44px); }
        header p { margin: 0; color: #dbeafe; line-height: 1.7; }

        .flow {
            margin-top: 20px;
            padding: 12px 16px;
            border: 1px solid rgba(255,255,255,.3);
            border-radius: 10px;
            background: rgba(15, 23, 42, .24);
            font-family: Consolas, monospace;
            overflow-x: auto;
        }

        main { padding: 30px 0 52px; }

        .intro {
            margin-bottom: 22px;
            padding: 18px 20px;
            border-left: 4px solid var(--accent);
            border-radius: 8px;
            background: #eff6ff;
            line-height: 1.7;
        }

        .grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 20px;
        }

        article {
            display: flex;
            min-height: 560px;
            flex-direction: column;
            padding: 22px;
            border: 1px solid var(--line);
            border-radius: 14px;
            background: var(--surface);
            box-shadow: 0 10px 28px rgba(15, 23, 42, .06);
        }

        .badge {
            align-self: flex-start;
            padding: 5px 9px;
            border-radius: 999px;
            color: #1e40af;
            background: #dbeafe;
            font-size: 12px;
            font-weight: 700;
        }

        h2 { margin: 13px 0 7px; font-size: 22px; }
        .description { min-height: 48px; margin: 0 0 16px; color: var(--muted); line-height: 1.55; }

        form { display: grid; gap: 12px; }
        label { display: grid; gap: 6px; font-size: 14px; font-weight: 700; }

        input, select, button {
            width: 100%;
            min-height: 42px;
            border-radius: 8px;
            font: inherit;
        }

        input, select {
            padding: 9px 11px;
            border: 1px solid #cbd5e1;
            background: white;
        }

        input:focus, select:focus {
            outline: 3px solid #bfdbfe;
            border-color: var(--accent);
        }

        button {
            margin-top: 3px;
            border: 0;
            color: white;
            background: var(--accent);
            font-weight: 800;
            cursor: pointer;
        }

        button:hover { background: var(--accent-dark); }
        button:disabled { opacity: .6; cursor: wait; }

        .endpoint {
            margin: 15px 0 8px;
            color: var(--muted);
            font-size: 12px;
        }

        code { font-family: Consolas, monospace; }

        pre {
            flex: 1;
            min-height: 158px;
            margin: 0;
            padding: 14px;
            border-radius: 9px;
            color: #d1fae5;
            background: var(--code);
            font: 13px/1.55 Consolas, monospace;
            white-space: pre-wrap;
            overflow-wrap: anywhere;
        }

        .links {
            display: flex;
            flex-wrap: wrap;
            gap: 9px;
            margin-top: 24px;
        }

        .links a {
            color: var(--accent-dark);
            text-decoration: none;
            font-weight: 700;
        }

        .links a:hover { text-decoration: underline; }
    </style>
</head>
<body>
<header>
    <div>
        <h1>Chapter 15-1</h1>
        <p>화면에서 직접 요청을 만들고 Spring Controller와 FastAPI가 주고받는 데이터를 확인합니다.</p>
        <div class="flow">Browser → Spring MVC Controller → FastAPI → Spring MVC Controller → Browser</div>
    </div>
</header>

<main>
    <div class="intro">
        브라우저는 FastAPI를 직접 호출하지 않습니다. 아래 세 폼은 모두 현재 Spring 애플리케이션의
        <code>/api/*</code>로 요청하며, <code>LessonController</code>가 주제별 Python 서버로 중계합니다.
    </div>

    <section class="grid">
        <article>
            <span class="badge">01 · GET</span>
            <h2>쿼리 파라미터</h2>
            <p class="description">이름과 언어를 URL 쿼리 파라미터로 보냅니다.</p>
            <form method="get"
                  action="${pageContext.request.contextPath}/api/basic"
                  target="_blank">
                <label>
                    이름
                    <input name="name" value="Spring" maxlength="30" required>
                </label>
                <label>
                    언어
                    <select name="language">
                        <option value="ko">한국어</option>
                        <option value="en">English</option>
                    </select>
                </label>
                <button type="submit">GET 요청 보내기</button>
            </form>
            <div class="endpoint">Spring GET <code>/api/basic</code> → FastAPI :8001</div>
            <pre>GET 응답은 새 탭에서 확인합니다.</pre>
        </article>

        <article>
            <span class="badge">02 · JSON</span>
            <h2>JSON 요청 본문</h2>
            <p class="description">입력값을 Java DTO와 Pydantic 모델로 차례로 변환합니다.</p>
            <form onsubmit="sendJson(event)">
                <label>
                    이름
                    <input name="name" value="홍길동" maxlength="30" required>
                </label>
                <label>
                    학습 주제
                    <input name="topic" value="JSON 요청과 응답" maxlength="100" required>
                </label>
                <label>
                    학습 시간
                    <input name="hours" type="number" value="2" min="1" max="24" required>
                </label>
                <button type="submit">JSON POST 보내기</button>
            </form>
            <div class="endpoint">Spring POST <code>/api/json</code> → FastAPI :8002</div>
            <pre id="jsonResult">응답이 여기에 표시됩니다.</pre>
        </article>

        <article>
            <span class="badge">03 · MULTIPART</span>
            <h2>문자열 + 파일</h2>
            <p class="description">FormData에 일반 필드와 파일을 함께 담아 전송합니다.</p>
            <form method="post"
                  action="${pageContext.request.contextPath}/api/multipart"
                  enctype="multipart/form-data"
                  target="_blank">
                <label>
                    파일 제목
                    <input name="title" value="수업 메모" maxlength="100" required>
                </label>
                <label>
                    파일 (1MB 이하 권장)
                    <input name="file" type="file" required>
                </label>
                <button type="submit">Multipart POST 보내기</button>
            </form>
            <div class="endpoint">Spring POST <code>/api/multipart</code> → FastAPI :8003</div>
            <pre>Multipart 응답은 새 탭에서 확인합니다.</pre>
        </article>
    </section>

    <nav class="links" aria-label="FastAPI 문서">
        <span>FastAPI 문서:</span>
        <a href="http://localhost:8001/docs" target="_blank" rel="noopener">01 Basic</a>
        <a href="http://localhost:8002/docs" target="_blank" rel="noopener">02 JSON</a>
        <a href="http://localhost:8003/docs" target="_blank" rel="noopener">03 Multipart</a>
    </nav>
</main>

<script>
    const contextPath = '${pageContext.request.contextPath}';

    async function show(response, resultId) {
        const data = await response.json();
        document.getElementById(resultId).textContent =
            'HTTP ' + response.status + '\n\n' + JSON.stringify(data, null, 2);//data: 응답 본문(JSON), null: 빈 값, 2: 들여쓰기 2칸
    }//JSON.stringify: JSON 데이터를 문자열로 변환

    // post 요청은 json으로 변환이 html에서는 불가능하기 때문에 스크립트로 변환 
    async function sendJson(event) {
        event.preventDefault();
        const form = event.currentTarget;   // 폼 요소를 가져옴
        const body = {  // JSON 요청 본문(body)을 설정
            name: form.elements.name.value, // name 파라미터 값
            topic: form.elements.topic.value,   // topic 파라미터 값
            hours: Number(form.elements.hours.value)   // hours 파라미터 값
        };
        const response = await fetch(contextPath + '/api/json', {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},  // JSON 요청 헤더 설정
            body: JSON.stringify(body)  // JSON 요청 본문(body)을 설정
        });
        await show(response, 'jsonResult');
    }
</script>
</body>
</html>
