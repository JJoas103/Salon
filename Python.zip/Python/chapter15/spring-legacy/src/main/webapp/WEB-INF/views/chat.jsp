<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<!DOCTYPE html>
<html lang="ko">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>무신사 MCP 상품 상담</title>
    <style>
        :root {
            color-scheme: light;
            --background: #f4f6f9;
            --panel: #ffffff;
            --text: #172033;
            --muted: #667085;
            --line: #e4e7ec;
            --brand: #111827;
            --accent: #2563eb;
            --assistant: #f0f4ff;
            --success: #087443;
        }

        * { box-sizing: border-box; }

        body {
            margin: 0;
            min-height: 100vh;
            background: var(--background);
            color: var(--text);
            font-family: Pretendard, "Noto Sans KR", system-ui, sans-serif;
        }

        .app {
            width: min(940px, calc(100% - 32px));
            margin: 32px auto;
        }

        .header {
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 24px;
            margin-bottom: 18px;
        }

        .header h1 { margin: 0 0 6px; font-size: clamp(24px, 4vw, 34px); }
        .header p { margin: 0; color: var(--muted); }

        .architecture {
            flex: 0 0 auto;
            padding: 9px 13px;
            border: 1px solid var(--line);
            border-radius: 999px;
            background: var(--panel);
            color: #344054;
            font-size: 13px;
            font-weight: 700;
        }

        .chat {
            overflow: hidden;
            border: 1px solid var(--line);
            border-radius: 22px;
            background: var(--panel);
            box-shadow: 0 18px 50px rgba(16, 24, 40, 0.08);
        }

        .chat-toolbar {
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 14px 18px;
            border-bottom: 1px solid var(--line);
        }

        .status {
            display: flex;
            align-items: center;
            gap: 8px;
            color: var(--success);
            font-size: 14px;
            font-weight: 700;
        }

        .status::before {
            width: 9px;
            height: 9px;
            border-radius: 50%;
            background: #12b76a;
            content: "";
        }

        button { font: inherit; }

        .reset-button {
            border: 0;
            background: transparent;
            color: var(--muted);
            cursor: pointer;
        }

        .messages {
            height: min(60vh, 580px);
            min-height: 420px;
            overflow-y: auto;
            padding: 24px;
        }

        .message { display: flex; margin: 0 0 18px; }
        .message.user { justify-content: flex-end; }

        .bubble {
            max-width: min(76%, 680px);
            padding: 13px 16px;
            border-radius: 17px;
            white-space: pre-wrap;
            word-break: break-word;
            line-height: 1.65;
        }

        .assistant .bubble {
            border-bottom-left-radius: 5px;
            background: var(--assistant);
        }

        .user .bubble {
            border-bottom-right-radius: 5px;
            background: var(--brand);
            color: white;
        }

        .bubble a { color: var(--accent); font-weight: 700; }

        .examples {
            display: flex;
            flex-wrap: wrap;
            gap: 8px;
            margin: 2px 0 22px;
        }

        .example {
            padding: 8px 12px;
            border: 1px solid #cfd7ee;
            border-radius: 999px;
            background: white;
            color: #344054;
            cursor: pointer;
        }

        .composer {
            display: flex;
            gap: 10px;
            padding: 16px;
            border-top: 1px solid var(--line);
            background: #fafbfc;
        }

        .composer input {
            min-width: 0;
            flex: 1;
            padding: 13px 15px;
            border: 1px solid #cfd4dc;
            border-radius: 13px;
            outline: none;
            font: inherit;
        }

        .composer input:focus {
            border-color: var(--accent);
            box-shadow: 0 0 0 3px rgba(37, 99, 235, 0.12);
        }

        .send-button {
            padding: 0 20px;
            border: 0;
            border-radius: 13px;
            background: var(--accent);
            color: white;
            font-weight: 800;
            cursor: pointer;
        }

        .send-button:disabled { cursor: wait; opacity: 0.55; }

        .notice {
            margin: 12px 4px 0;
            color: var(--muted);
            font-size: 12px;
            text-align: center;
        }

        @media (max-width: 680px) {
            .app { width: 100%; margin: 0; }
            .header { padding: 20px 18px 12px; align-items: flex-start; }
            .architecture { display: none; }
            .chat { border-right: 0; border-left: 0; border-radius: 0; }
            .messages { height: calc(100vh - 260px); min-height: 360px; }
            .bubble { max-width: 88%; }
        }
    </style>
</head>
<body>
<main class="app">
    <header class="header">
        <div>
            <h1>무신사 MCP 상품 상담</h1>
            <p>자연어로 가격과 할인 조건을 말하면 상품을 찾아드려요.</p>
        </div>
        <div class="architecture">Spring MVC → FastAPI → MCP</div>
    </header>

    <section class="chat" aria-label="상품 상담 채팅">
        <div class="chat-toolbar">
            <div class="status">상담 화면 준비됨</div>
            <button id="resetButton" class="reset-button" type="button">새 대화</button>
        </div>

        <div id="messages" class="messages" aria-live="polite"></div>

        <form id="chatForm" class="composer">
            <input id="question" name="question" maxlength="500" autocomplete="off"
                   placeholder="예: 3만원 이하 티셔츠 추천해 줘" required>
            <button id="sendButton" class="send-button" type="submit">전송</button>
        </form>
    </section>
    <p class="notice">상품 정보는 project14 MCP Tool 검색 결과를 기반으로 제공합니다.</p>

<script>
    const apiUrl = "${pageContext.request.contextPath}/rest/chat";
    const messages = document.getElementById("messages");
    const form = document.getElementById("chatForm");
    const input = document.getElementById("question");
    const sendButton = document.getElementById("sendButton");
    const examples = [
        "3만원 이하 티셔츠 추천해 줘",
        "할인율 30% 이상인 바지를 찾아 줘",
        "그중 두 번째 상품 링크를 알려 줘"
    ]

    // 브라우저별 고유 세션 ID 확인
    let sessionId = sessionStorage.getItem("mcpShoppingSession") || createSessionId();

    // 세션ID 생성(첫 접속)
    function createSessionId(){
        const id = window.crypto.randomUUID();
        sessionStorage.setItem("mcpShoppingSession", id);
        return id;
    }
    // 채팅 메시지 추가
    function appendMessage(role, text){
        const row = document.createElement("div");
        row.className = "message " + role;
        const bubble = document.createElement("div");
        bubble.className = "bubble";

        let lastIndex = 0;
        bubble.append(document.createTextNode(text));
        
        row.append(bubble);
        messages.append(row);

        messages.scrollTop = messages.scrollHeight;// 스크롤을 최하단으로

    }

    // 대화 시작 시 초기 메시지 표시
    function showWelcome(){
        messages.replaceChildren(); // messages 요소의 모든 자식 요소 제거
        appendMessage("assistant", "안녕하세요! 어떤 상품을 찾으시나요?")

        // 예시 버튼 생성
        const exampleBox = document.createElement("div");
        exampleBox.className = "examples";
        examples.forEach(text => {
            const button  = document.createElement("button");
            button.type = "button";
            button.className = "example";
            button.textContent += text;
            button.addEventListener("click", ()=>{
                input.value = text;
                input.focus();
            });
            exampleBox.append(button);
        });
        messages.append(exampleBox);
    }

    // 질문 전송
    async function sendQuestion(question){
        appendMessage("user", question);
        sendButton.disabled = true;
        sendButton.textContent = "검색 중";

        // 로딩 메시지 추가
        const loadingRow = document.createElement("div");
        loadingRow.className = "message assistant";
        loadingRow.innerHTML = "<div class='bubble'>서버에서 검색하고 있습니다...</div>"
        messages.append(loadingRow);
        messages.scrollTop = messages.scrollHeight;

        // 스프링 서버에 사용자의 질문을 JSON 형식으로 전송
        try{
            const response = await fetch(apiUrl, {
                method: "POST",
                headers: {"Content-Type" : "application/json"},
                body: JSON.stringify({question, sessionId})
            });
            const data = await response.json();//서버에서 응답한 데이터(LLM 답변)
            loadingRow.remove(); // 로딩 메시지 제거

            // 서버 응답 실패
            if(!response.ok){
                throw new Error(data.answer || data.detail || "상품 상담 요청에 실패했습니다");
            }
            sessionId = data.sessionId || sessionId;
            sessionStorage.setItem("mcpShoppingSession", sessionId);
            appendMessage("assistant", data.answer);//답변을 messages div에 추가
        }catch(error){
            loadingRow.remove();
            // (수정) error.messages -> error.message : Error 객체는 message(단수) 프로퍼티만 존재함
            //        기존 코드는 항상 undefined를 출력했음
            appendMessage("assistant", error.message);//오류 메시지 추가
        }finally{
            //전송 버튼 활성화(오류와 상관없이)
            sendButton.disabled = false;
            sendButton.textContent = "전송";
            input.focus();
        }
    }
    // 질문 전송 이벤트
    form.addEventListener("submit", event => {
        event.preventDefault();
        const question = input.value.trim();
        if(!question || sendButton.disabled) return;
        input.value = "";
        sendQuestion(question);
    });

    showWelcome();

</script>

</main>
</body>
</html>
