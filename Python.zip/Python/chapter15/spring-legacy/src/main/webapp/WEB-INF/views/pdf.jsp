<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<!DOCTYPE html>
<html lang="ko">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>MCP 문서 요약 PDF</title>
    <style>
        :root {
            color-scheme: light;
            --background: #f3f6f8;
            --panel: #ffffff;
            --text: #172033;
            --muted: #667085;
            --line: #dce4e8;
            --accent: #0f766e;
            --accent-dark: #115e59;
            --success: #087443;
            --error: #b42318;
        }

        * { box-sizing: border-box; }
        body {
            margin: 0;
            min-height: 100vh;
            background: var(--background);
            color: var(--text);
            font-family: Pretendard, "Noto Sans KR", system-ui, sans-serif;
        }

        .app {
            width: min(1120px, calc(100% - 32px));
            margin: 32px auto;
        }

        .header {
            display: flex;
            align-items: flex-start;
            justify-content: space-between;
            gap: 24px;
            margin-bottom: 18px;
        }

        .header h1 {
            margin: 0 0 7px;
            font-size: clamp(26px, 4vw, 38px);
        }

        .header p {
            max-width: 720px;
            margin: 0;
            color: var(--muted);
            line-height: 1.65;
        }

        .home-link {
            flex: 0 0 auto;
            padding: 9px 13px;
            border: 1px solid var(--line);
            border-radius: 999px;
            background: var(--panel);
            color: #344054;
            font-size: 13px;
            font-weight: 700;
            text-decoration: none;
        }

        .architecture {
            margin: 0 0 18px;
            padding: 11px 14px;
            border: 1px solid #b8ddd8;
            border-radius: 12px;
            background: #ecfdf9;
            color: #115e59;
            font: 700 13px/1.5 Consolas, monospace;
        }

        .workspace {
            display: grid;
            grid-template-columns: minmax(290px, 360px) minmax(0, 1fr);
            gap: 20px;
        }

        .panel {
            padding: 22px;
            border: 1px solid var(--line);
            border-radius: 20px;
            background: var(--panel);
            box-shadow: 0 18px 50px rgba(16, 24, 40, .07);
        }

        form { display: grid; gap: 16px; }
        label {
            display: grid;
            gap: 7px;
            font-size: 14px;
            font-weight: 800;
        }

        input, button {
            width: 100%;
            border-radius: 12px;
            font: inherit;
        }

        input {
            min-height: 46px;
            padding: 10px 12px;
            border: 1px solid #cfd4dc;
            background: white;
        }

        input[type="file"] { padding: 9px; }
        input:focus {
            border-color: var(--accent);
            outline: 3px solid rgba(15, 118, 110, .13);
        }

        button {
            min-height: 48px;
            border: 0;
            background: var(--accent);
            color: white;
            font-weight: 800;
            cursor: pointer;
        }

        button:hover { background: var(--accent-dark); }
        button:disabled { cursor: wait; opacity: .58; }

        .help {
            margin: -8px 0 0;
            color: var(--muted);
            font-size: 12px;
            line-height: 1.6;
        }

        .file-info {
            min-height: 68px;
            margin-top: 16px;
            padding: 13px 14px;
            border: 1px solid var(--line);
            border-radius: 12px;
            background: #f8fafc;
            color: var(--muted);
            font-size: 13px;
            line-height: 1.65;
            white-space: pre-line;
            word-break: break-all;
        }

        .status {
            min-height: 24px;
            margin: 14px 0 0;
            color: var(--muted);
            font-size: 13px;
            line-height: 1.6;
        }

        .status.success { color: var(--success); }
        .status.error { color: var(--error); }

        .preview-header {
            display: flex;
            align-items: center;
            justify-content: space-between;
            gap: 14px;
            margin-bottom: 13px;
        }

        .preview-header h2 { margin: 0; font-size: 19px; }
        .download {
            display: none;
            padding: 8px 12px;
            border: 1px solid #9fd3cc;
            border-radius: 10px;
            color: var(--accent-dark);
            font-size: 13px;
            font-weight: 800;
            text-decoration: none;
        }

        .download.visible { display: inline-flex; }
        .preview-box {
            display: grid;
            min-height: 620px;
            place-items: center;
            overflow: hidden;
            border: 1px solid var(--line);
            border-radius: 14px;
            background: #eef2f5;
            color: var(--muted);
            text-align: center;
        }

        .preview-box iframe {
            width: 100%;
            height: 720px;
            border: 0;
            background: white;
        }

        @media (max-width: 840px) {
            .workspace { grid-template-columns: 1fr; }
            .preview-box { min-height: 480px; }
            .preview-box iframe { height: 600px; }
        }

        @media (max-width: 560px) {
            .app { width: 100%; margin: 0; }
            .header { padding: 20px 18px 12px; }
            .architecture { margin: 0 18px 16px; }
            .home-link { display: none; }
            .panel { border-right: 0; border-left: 0; border-radius: 0; }
        }
    </style>
</head>
<body>
<main class="app">
    <header class="header">
        <div>
            <h1>MCP 문서 요약 PDF</h1>
            <p>문서를 올리면 MCP Tool이 내용을 LLM으로 요약하고 한글 PDF 보고서를 만듭니다.</p>
        </div>
        <a class="home-link" href="${pageContext.request.contextPath}/">홈으로</a>
    </header>

    <div class="architecture">Spring MVC → FastAPI → mcp_pdf → OpenAI 요약 → ReportLab PDF</div>

    <div class="workspace">
        <section class="panel" aria-label="문서 요약 PDF 입력">
            <form id="pdfForm">
                <label>
                    PDF 제목
                    <input id="title" name="title" value="문서 핵심 요약 보고서"
                           maxlength="100" required>
                </label>

                <label>
                    요약할 문서
                    <input id="documentFile" name="document" type="file"
                           accept=".txt,.md,.pdf,text/plain,text/markdown,application/pdf"
                           required>
                </label>
                <p class="help">TXT, Markdown, 텍스트 PDF · 최대 5MB</p>
                <p class="help">스캔 이미지만 있는 PDF와 암호화된 PDF는 지원하지 않습니다.</p>

                <button id="createButton" type="submit">요약 PDF 만들기</button>
            </form>

            <div id="fileInfo" class="file-info">문서를 선택해 주세요.</div>
            <p id="status" class="status" aria-live="polite">
                문서 요약에는 OpenAI API 호출 비용이 발생할 수 있습니다.
            </p>
        </section>

        <section class="panel" aria-label="생성 PDF 미리보기">
            <div class="preview-header">
                <h2>생성 PDF</h2>
                <a id="downloadLink" class="download" download="document-summary.pdf">
                    PDF 다운로드
                </a>
            </div>
            <div id="previewBox" class="preview-box">
                PDF를 만들면 이곳에서 미리 볼 수 있습니다.
            </div>
        </section>
    </div>
</main>

<script>
    const apiUrl = "${pageContext.request.contextPath}/api/pdf";
    const form = document.getElementById("pdfForm");
    const title = document.getElementById("title");
    const documentFile = document.getElementById("documentFile");
    const createButton = document.getElementById("createButton");
    const fileInfo = document.getElementById("fileInfo");
    const status = document.getElementById("status");
    const previewBox = document.getElementById("previewBox");
    const downloadLink = document.getElementById("downloadLink");
    const maxDocumentBytes = 5 * 1024 * 1024;
    let pdfUrl = null;

    documentFile.addEventListener("change", () => {
        const file = documentFile.files[0];
        if (!file) {
            fileInfo.textContent = "문서를 선택해 주세요.";
            return;
        }

        const sizeMb = (file.size / 1024 / 1024).toFixed(2);
        fileInfo.textContent = "파일: " + file.name + "\n크기: " + sizeMb + "MB";
    });

    form.addEventListener("submit", async event => {
        event.preventDefault();

        const file = documentFile.files[0];
        const cleanTitle = title.value.trim();
        if (!file || !cleanTitle || createButton.disabled) return;

        if (file.size > maxDocumentBytes) {
            status.className = "status error";
            status.textContent = "오류: 요약할 문서는 5MB 이하여야 합니다.";
            return;
        }

        const body = new FormData();
        body.append("title", cleanTitle);
        body.append("document", file);

        createButton.disabled = true;
        createButton.textContent = "요약 및 생성 중";
        status.className = "status";
        status.textContent = "MCP가 문서를 요약하고 PDF를 만들고 있습니다…";
        previewBox.textContent = "PDF 생성 결과를 기다리고 있습니다…";
        downloadLink.classList.remove("visible");

        try {
            const response = await fetch(apiUrl, {
                method: "POST",
                body
            });

            if (!response.ok) {
                let message = "문서 요약 PDF 요청에 실패했습니다.";
                try {
                    const errorData = await response.json();
                    message = errorData.message || errorData.detail || message;
                } catch (ignored) {
                }
                throw new Error(message);
            }

            const pdfBlob = await response.blob();
            if (pdfUrl) {
                URL.revokeObjectURL(pdfUrl);
            }
            pdfUrl = URL.createObjectURL(pdfBlob);

            const preview = document.createElement("iframe");
            preview.src = pdfUrl;
            preview.title = "생성된 문서 요약 PDF";
            previewBox.replaceChildren(preview);

            downloadLink.href = pdfUrl;
            downloadLink.classList.add("visible");
            status.className = "status success";
            status.textContent = "MCP 문서 요약 PDF가 완성되었습니다.";
        } catch (error) {
            previewBox.textContent = "PDF 생성 결과를 표시할 수 없습니다.";
            status.className = "status error";
            status.textContent = "오류: " + error.message;
        } finally {
            createButton.disabled = false;
            createButton.textContent = "요약 PDF 만들기";
        }
    });

    window.addEventListener("beforeunload", () => {
        if (pdfUrl) {
            URL.revokeObjectURL(pdfUrl);
        }
    });
</script>
</body>
</html>
