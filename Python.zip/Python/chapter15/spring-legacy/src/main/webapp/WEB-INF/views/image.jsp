<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<!DOCTYPE html>
<html lang="ko">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>참고 이미지로 새 이미지 만들기</title>
    <style>
        :root {
            color-scheme: light;
            --background: #f4f6f9;
            --panel: #ffffff;
            --text: #172033;
            --muted: #667085;
            --line: #e4e7ec;
            --accent: #7c3aed;
            --accent-dark: #6d28d9;
            --success: #087443;
        }

        * { box-sizing: border-box; }

        body {
            margin: 0;
            min-height: 100vh;
            background: var(--background);
            color: var(--text);
            font-family: Pretendard, "Noto Sans KR", system-ui, sans-serif;
        }

        .app {
            width: min(1080px, calc(100% - 32px));
            margin: 32px auto;
        }

        .header {
            display: flex;
            align-items: flex-start;
            justify-content: space-between;
            gap: 24px;
            margin-bottom: 18px;
        }

        .header h1 {
            margin: 0 0 7px;
            font-size: clamp(26px, 4vw, 38px);
        }

        .header p {
            margin: 0;
            color: var(--muted);
            line-height: 1.65;
        }

        .home-link {
            flex: 0 0 auto;
            padding: 9px 13px;
            border: 1px solid var(--line);
            border-radius: 999px;
            background: var(--panel);
            color: #344054;
            font-size: 13px;
            font-weight: 700;
            text-decoration: none;
        }

        .workspace {
            display: grid;
            grid-template-columns: minmax(280px, 360px) minmax(0, 1fr);
            gap: 20px;
        }

        .panel {
            padding: 22px;
            border: 1px solid var(--line);
            border-radius: 20px;
            background: var(--panel);
            box-shadow: 0 18px 50px rgba(16, 24, 40, .07);
        }

        form { display: grid; gap: 16px; }

        label {
            display: grid;
            gap: 7px;
            font-size: 14px;
            font-weight: 800;
        }

        textarea, input, button {
            width: 100%;
            border-radius: 12px;
            font: inherit;
        }

        textarea, input {
            border: 1px solid #cfd4dc;
            background: white;
        }

        textarea {
            min-height: 150px;
            padding: 12px 14px;
            resize: vertical;
            line-height: 1.6;
        }

        input[type="file"] { padding: 10px; }

        textarea:focus, input:focus {
            border-color: var(--accent);
            outline: 3px solid rgba(124, 58, 237, .13);
        }

        button {
            min-height: 48px;
            border: 0;
            background: var(--accent);
            color: white;
            font-weight: 800;
            cursor: pointer;
        }

        button:hover { background: var(--accent-dark); }
        button:disabled { cursor: wait; opacity: .58; }

        .help {
            margin: -8px 0 0;
            color: var(--muted);
            font-size: 12px;
            line-height: 1.6;
        }

        .status {
            min-height: 24px;
            margin: 16px 0 0;
            color: var(--muted);
            font-size: 13px;
            line-height: 1.6;
        }

        .status.error { color: #b42318; }
        .status.success { color: var(--success); }

        .result-grid {
            display: grid;
            grid-template-columns: repeat(2, minmax(0, 1fr));
            gap: 16px;
        }

        figure { margin: 0; }

        figcaption {
            margin-bottom: 9px;
            color: #344054;
            font-size: 14px;
            font-weight: 800;
        }

        .image-box {
            display: grid;
            min-height: 420px;
            place-items: center;
            overflow: hidden;
            border: 1px dashed #cfd4dc;
            border-radius: 15px;
            background:
                linear-gradient(45deg, #f7f7fa 25%, transparent 25%),
                linear-gradient(-45deg, #f7f7fa 25%, transparent 25%),
                linear-gradient(45deg, transparent 75%, #f7f7fa 75%),
                linear-gradient(-45deg, transparent 75%, #f7f7fa 75%);
            background-position: 0 0, 0 8px, 8px -8px, -8px 0;
            background-size: 16px 16px;
            color: var(--muted);
            text-align: center;
        }

        .image-box img {
            display: block;
            width: 100%;
            height: 100%;
            max-height: 560px;
            object-fit: contain;
        }

        .download {
            display: none;
            margin-top: 14px;
            padding: 10px 14px;
            border: 1px solid #d8c7ff;
            border-radius: 11px;
            color: var(--accent-dark);
            font-size: 14px;
            font-weight: 800;
            text-align: center;
            text-decoration: none;
        }

        .download.visible { display: block; }

        @media (max-width: 820px) {
            .workspace { grid-template-columns: 1fr; }
            .result-grid { grid-template-columns: 1fr; }
            .image-box { min-height: 320px; }
        }

        @media (max-width: 560px) {
            .app { width: 100%; margin: 0; }
            .header { padding: 20px 18px 12px; }
            .home-link { display: none; }
            .panel { border-right: 0; border-left: 0; border-radius: 0; }
        }
    </style>
</head>
<body>
<main class="app">
    <header class="header">
        <div>
            <h1>참고 이미지로 새 이미지 만들기</h1>
            <p>이미지와 바꾸고 싶은 내용을 보내면 OpenAI 이미지 모델이 새 그림을 만듭니다.</p>
        </div>
        <a class="home-link" href="${pageContext.request.contextPath}/">홈으로</a>
    </header>

    <div class="workspace">
        <section class="panel" aria-label="이미지 생성 입력">
            <form id="imageForm">
                <label>
                    참고 이미지
                    <input id="imageFile" name="image" type="file"
                           accept="image/png,image/jpeg,image/webp" required>
                </label>
                <p class="help">PNG, JPG, JPEG, WEBP · 최대 10MB</p>

                <label>
                    이미지 생성 문구
                    <textarea id="prompt" name="prompt" maxlength="1000"
                              placeholder="예: 인물은 그대로 두고 배경을 별이 가득한 밤하늘로 바꿔 줘"
                              required></textarea>
                </label>
                <p class="help">유지할 요소와 바꿀 요소를 구체적으로 적으면 결과가 더 명확해집니다.</p>

                <button id="generateButton" type="submit">이미지 생성하기</button>
            </form>
            <p id="status" class="status" aria-live="polite">
                참고 이미지와 문구를 입력해 주세요.
            </p>
        </section>

        <section class="panel result-grid" aria-label="이미지 생성 결과">
            <figure>
                <figcaption>참고 이미지</figcaption>
                <div id="referenceBox" class="image-box">이미지를 선택하면 미리보기가 표시됩니다.</div>
            </figure>
            <figure>
                <figcaption>생성 이미지</figcaption>
                <div id="generatedBox" class="image-box">생성 결과가 여기에 표시됩니다.</div>
                <a id="downloadLink" class="download" download="generated-image.png">
                    생성 이미지 다운로드
                </a>
            </figure>
        </section>
    </div>
</main>

<script>
    const apiUrl = "${pageContext.request.contextPath}/api/image";
    const form = document.getElementById("imageForm");
    const imageFile = document.getElementById("imageFile");
    const prompt = document.getElementById("prompt");
    const generateButton = document.getElementById("generateButton");
    const status = document.getElementById("status");
    const referenceBox = document.getElementById("referenceBox");
    const generatedBox = document.getElementById("generatedBox");
    const downloadLink = document.getElementById("downloadLink");
    let referenceUrl = null;

    // 선택한 참고 이미지를 화면에 미리 표시
    imageFile.addEventListener("change", () => {
        if (referenceUrl) {
            URL.revokeObjectURL(referenceUrl);  
            // 이전 이미지 URL 해제
            referenceUrl = null;
        }

        //선택한 이미지 파일 가져오기
        const file = imageFile.files[0];
        if (!file) {
            referenceBox.textContent = "이미지를 선택하면 미리보기가 표시됩니다.";
            return;
        }

        // 이미지 URL 생성
        referenceUrl = URL.createObjectURL(file);
        const preview = document.createElement("img");
        preview.src = referenceUrl;
        preview.alt = "선택한 참고 이미지";
        referenceBox.replaceChildren(preview);
    });

    // 이미지와 문구를 FormData에 담아 Spring Controller로 전송
    form.addEventListener("submit", async event => {
        event.preventDefault();

        const file = imageFile.files[0];
        const cleanPrompt = prompt.value.trim();
        if (!file || !cleanPrompt || generateButton.disabled) return;

        const body = new FormData();
        body.append("prompt", cleanPrompt);
        body.append("image", file);

        generateButton.disabled = true;
        generateButton.textContent = "생성 중";
        status.className = "status";
        status.textContent = "이미지를 생성하고 있습니다. 최대 몇 분 정도 걸릴 수 있습니다…";
        generatedBox.textContent = "OpenAI 이미지 모델의 응답을 기다리고 있습니다…";
        downloadLink.classList.remove("visible");

        try {
            const response = await fetch(apiUrl, {
                method: "POST",
                body
            });
            const data = await response.json();

            // 이미지 생성 실패
            if (!response.ok) {
                throw new Error(
                    data.message
                    || data.detail
                    || "이미지 생성 요청에 실패했습니다."
                );
            }
            /*
                Fast-Api 보내준 데이터
                {   
                    "mediaType" : "image/png",
                    "imageBase64" : "(데이터 문자열)",
                    "model" : "gpt-image-1"

                }
            */
            // 이미지 URL 생성
            const imageUrl = "data:" + data.mediaType + ";base64," + data.imageBase64;
            const result = document.createElement("img");
            result.src = imageUrl;
            result.alt = "생성된 이미지";
            generatedBox.replaceChildren(result);

            // 다운로드 링크 설정
            downloadLink.href = imageUrl;
            downloadLink.classList.add("visible");
            status.className = "status success";
            status.textContent = "이미지 생성이 완료되었습니다. 사용 모델: " + data.model;
        } catch (error) {
            generatedBox.textContent = "생성 결과를 표시할 수 없습니다.";
            status.className = "status error";
            status.textContent = "오류: " + error.message;
        } finally {
            generateButton.disabled = false;
            generateButton.textContent = "이미지 생성하기";
        }
    });
</script>
</body>
</html>
