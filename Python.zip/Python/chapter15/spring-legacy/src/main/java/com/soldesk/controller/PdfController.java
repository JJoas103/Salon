package com.soldesk.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;


@Controller
@RequestMapping("/pdf")
public class PdfController {

    @GetMapping("/")
    public String pdfForm() {
        return "pdf";
    }
}
