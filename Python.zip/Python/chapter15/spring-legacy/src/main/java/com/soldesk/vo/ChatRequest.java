package com.soldesk.vo;

//FastAPI 서버에 전달하기 위한 요청 클래스
public class ChatRequest {
    
    private String question;//질문
    private String sessionId;//세션 ID
    
    public String getQuestion() {
        return question;
    }
    public void setQuestion(String question) {
        this.question = question;
    }
    public String getSessionId() {
        return sessionId;
    }
    public void setSessionId(String sessionId) {
        this.sessionId = sessionId;
    }

    
}
