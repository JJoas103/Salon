package com.soldesk.controller;

import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.HttpStatusCodeException;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import com.soldesk.vo.ChatRequest;
import com.soldesk.vo.ChatResponse;

@RestController
@RequestMapping("/rest")
public class ChatRestController {

    private final RestTemplate restTemplate;
    private final String basicUrl = "http://localhost:8000";

    public ChatRestController(RestTemplate restTemplate){
        this.restTemplate = restTemplate;
    }
    
    @PostMapping(value = "/chat", consumes = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<?> chat(@RequestBody ChatRequest request){
        
        //질문이 없거나 질문의 길이가 500자 초과 시 오류 반환
        if(request.getQuestion() == null 
            || request.getQuestion().trim().isEmpty()
            || request.getQuestion().length() > 500){
                return ResponseEntity.badRequest().body(
                    new ChatResponse(
                        "질문은 1자 이상 500자 이하로 입력해주세요",
                        "spring",
                        request.getQuestion(),
                        request.getSessionId()
                    )
                );
            }
        //FastAPI 서버에 질문 전송(localhost:8000/api/chat)
        try{
            ResponseEntity<ChatResponse> response 
                = restTemplate.postForEntity
                    (basicUrl+"/api/chat", request, ChatResponse.class);
            return response;
        }
        // FastAPI 서버에 질문을 전송 실패
        catch(HttpStatusCodeException error){
            return ResponseEntity.status(HttpStatus.BAD_GATEWAY).body(
                new ChatResponse(
                    "서버상 문제로 MCP 상품 상담 서비스를 사용할 수 없습니다",
                    "mcp-error",
                    request.getQuestion(),
                    request.getSessionId())
            );
        }
        // FastAPI 서버 연결 실패
        catch(RestClientException error){
            return ResponseEntity.status(HttpStatus.BAD_GATEWAY).body(
                new ChatResponse(
                    "Fast-API 서버에 연결할 수 없습니다",
                    "spring",
                    request.getQuestion(),
                    request.getSessionId())
            );
        }
    }
}