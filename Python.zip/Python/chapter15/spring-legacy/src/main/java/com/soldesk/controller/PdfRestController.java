package com.soldesk.controller;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.http.ContentDisposition;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.HttpStatusCodeException;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.multipart.MultipartFile;

import com.soldesk.vo.MessageResponse;

import java.io.IOException;
import java.util.LinkedHashMap;
import java.util.Locale;
import java.util.Map;
import java.util.Set;


@RestController
@RequestMapping("/api")
public class PdfRestController {

    private static final long MAX_DOCUMENT_BYTES = 5L * 1024 * 1024;
    private static final Set<String> ALLOWED_SUFFIXES = Set.of(
            ".txt",
            ".md",
            ".pdf"
    );

    private final RestTemplate restTemplate;
    private final String fastApiUrl = "http://localhost:8000";

    public PdfRestController(
            RestTemplate restTemplate) {
        this.restTemplate = restTemplate;
    }

    // 문서와 PDF 제목을 multipart/form-data로 다시 조립해 FastAPI에 보내기
    @PostMapping(value = "/pdf", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public ResponseEntity<?> createPdf(
            @RequestParam String title,
            @RequestParam("document") MultipartFile document) {

        if (!StringUtils.hasText(title) || title.length() > 100) {
            return badRequest("PDF 제목은 1자 이상 100자 이하로 입력해 주세요.");
        }
        if (document.isEmpty()) {
            return badRequest("요약할 문서를 선택해 주세요.");
        }
        if (document.getSize() > MAX_DOCUMENT_BYTES) {
            return badRequest("요약할 문서는 5MB 이하여야 합니다.");
        }

        String originalFilename = document.getOriginalFilename() == null
                ? "document.txt"
                : StringUtils.cleanPath(document.getOriginalFilename());
        String suffix = fileSuffix(originalFilename);
        if (!ALLOWED_SUFFIXES.contains(suffix)) {
            return badRequest("TXT, Markdown, PDF 문서만 사용할 수 있습니다.");
        }

        try {
            ByteArrayResource documentResource =
                    new ByteArrayResource(document.getBytes()) {
                        @Override
                        public String getFilename() {
                            return originalFilename;
                        }
                    };

            String contentType = document.getContentType();
            MediaType documentMediaType = MediaType.APPLICATION_OCTET_STREAM;
            if (StringUtils.hasText(contentType)) {
                try {
                    documentMediaType = MediaType.parseMediaType(contentType);
                } catch (IllegalArgumentException ignored) {
                    documentMediaType = MediaType.APPLICATION_OCTET_STREAM;
                }
            }

            HttpHeaders documentHeaders = new HttpHeaders();
            documentHeaders.setContentDispositionFormData(
                    "document",
                    originalFilename
            );
            documentHeaders.setContentType(documentMediaType);

            MultiValueMap<String, Object> parts = new LinkedMultiValueMap<>();
            parts.add("title", title.trim());
            parts.add(
                    "document",
                    new HttpEntity<>(documentResource, documentHeaders)
            );

            HttpHeaders requestHeaders = new HttpHeaders();
            requestHeaders.setContentType(MediaType.MULTIPART_FORM_DATA);
            HttpEntity<MultiValueMap<String, Object>> request =
                    new HttpEntity<>(parts, requestHeaders);

            ResponseEntity<byte[]> fastApiResponse = restTemplate.postForEntity(
                    fastApiUrl + "/api/pdfs",
                    request,
                    byte[].class
            );
            byte[] pdfBytes = fastApiResponse.getBody();
            if (pdfBytes == null || pdfBytes.length == 0) {
                return ResponseEntity.status(HttpStatus.BAD_GATEWAY).body(
                      new MessageResponse("FastAPI가 빈 PDF를 반환했습니다.")
                );
            }

            HttpHeaders responseHeaders = new HttpHeaders();
            responseHeaders.setContentType(MediaType.APPLICATION_PDF);
            responseHeaders.setContentDisposition(
                    ContentDisposition.attachment()
                            .filename("document-summary.pdf")
                            .build()
            );
            responseHeaders.setContentLength(pdfBytes.length);
            responseHeaders.set("X-MCP-Server", "document-summary-pdf");
            return new ResponseEntity<>(
                    pdfBytes,
                    responseHeaders,
                    fastApiResponse.getStatusCode()
            );
        } catch (HttpStatusCodeException error) {
            Map<String, Object> body = message(
                    "FastAPI가 문서 요약 PDF 요청을 처리하지 못했습니다."
            );
            body.put("fastApiStatus", error.getRawStatusCode());
            body.put("fastApiBody", error.getResponseBodyAsString());
            return ResponseEntity.status(error.getStatusCode()).body(body);
        } catch (IOException error) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                    .body(message("업로드한 문서를 읽을 수 없습니다."));
        } catch (RestClientException error) {
            return ResponseEntity.status(HttpStatus.BAD_GATEWAY).body(
                    message("Python FastAPI PDF 서비스에 연결할 수 없습니다.")
            );
        }
    }

    private String fileSuffix(String filename) {
        int dotIndex = filename.lastIndexOf('.');
        if (dotIndex < 0) {
            return "";
        }
        return filename.substring(dotIndex).toLowerCase(Locale.ROOT);
    }

    private ResponseEntity<Map<String, Object>> badRequest(String text) {
        return ResponseEntity.badRequest().body(message(text));
    }

    private Map<String, Object> message(String text) {
        Map<String, Object> body = new LinkedHashMap<>();
        body.put("message", text);
        body.put("receivedBy", "Spring PdfRestController");
        return body;
    }
}
