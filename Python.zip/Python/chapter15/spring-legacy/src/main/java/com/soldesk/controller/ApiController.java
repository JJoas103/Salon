package com.soldesk.controller;

import java.io.IOException;
import java.net.URI;
import java.util.HashMap;
import java.util.Map;

import javax.print.attribute.standard.Media;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.HttpStatusCodeException;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.util.UriComponentsBuilder;

import com.soldesk.vo.StudyRequest;

@RestController
@RequestMapping("/api")
public class ApiController {
    
    private final RestTemplate restTemplate;
    //RestTemplate: 다른 API 서버를 호출하는 데 사용하는 클래스
    private final String basicUrl;
    private final String jsonUrl;

    public ApiController(
            RestTemplate restTemplate,
            @Value("${fastapi.basic-url}") String basicUrl,
            @Value("${fastapi.json-url}") String jsonUrl){
        this.restTemplate = restTemplate;
        this.basicUrl = basicUrl;
        this.jsonUrl = jsonUrl;
    }

    @GetMapping("/basic")
    public ResponseEntity<?> basic(@RequestParam String name, 
                                   @RequestParam String language){
        
        //URL 조립
        //localhost:8001/api/hello?name=홍길동&language=ko
        URI uri = UriComponentsBuilder.fromHttpUrl(basicUrl)
                    .path("/api/hello")
                    .queryParam("name", name)
                    .queryParam("language", language)
                    .build()
                    .encode()
                    .toUri();
        // restTemplate.exchange: API 서버에 요청
        return restTemplate.exchange(uri, HttpMethod.GET, HttpEntity.EMPTY, Map.class);
    }
    @PostMapping(value = "/json", consumes = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<?> json(@RequestBody StudyRequest request){
        return restTemplate.postForEntity(jsonUrl + "/api/study", request, Map.class);
    }
    //03. multipart/form-data
    @PostMapping(value = "/multipart", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public ResponseEntity<?> multipart(@RequestParam String title,
                                       @RequestParam("file") MultipartFile file){
        
        try{                            
            //파일명 처리
            String fileName = StringUtils.cleanPath(
                file.getOriginalFilename() == null ? "upload.bin" : file.getOriginalFilename());
            
            //파일 데이터를 바이트 배열로 변환
            ByteArrayResource filResource = new ByteArrayResource(file.getBytes()){
                @Override
                public String getFilename() {
                    return fileName;
                }
            };
            // MediaType
            String contentTypeValue = file.getContentType();
            MediaType fileMediaType;
            // 문자열이 null이거나 빈 문자열이면 기본값 사용
            if (!StringUtils.hasText(contentTypeValue)){
                fileMediaType = MediaType.APPLICATION_OCTET_STREAM;
            }else{
                fileMediaType = MediaType.parseMediaType(contentTypeValue);
            }
            // 파일 파트에 붙일 헤더 설정
            HttpHeaders filHeaders = new HttpHeaders();
            filHeaders.setContentDispositionFormData("file", fileName);
            filHeaders.setContentType(fileMediaType);

            // 요청 전체에 붙일 헤더 설정
            HttpHeaders requestHeaders = new HttpHeaders();
            requestHeaders.setContentType(MediaType.MULTIPART_FORM_DATA);

            // body 설정
            MultiValueMap<String, Object> parts = new LinkedMultiValueMap<>();
            parts.add("title", title);
            parts.add("file", new HttpEntity<>(filResource, filHeaders));

            // 헤더와 body를 합쳐 최종 요청 객체 생성
            HttpEntity<MultiValueMap<String, Object>> request = 
                new HttpEntity<>(parts, requestHeaders);

            // FastAPI에 POST 요청을 보내고, 응답 본문(JSON)을 Map으로 파싱 후 화면으로 보내기
            return restTemplate.postForEntity("http://localhost:8003/api/upload",request, Map.class);
        } catch(IOException error){
            System.out.println("파일을 읽을 수가 없습니다");
            Map<String, String> errorBody = new HashMap<>();
            errorBody.put("error", "파일을 읽을 수가 없습니다");
            return ResponseEntity.internalServerError().body(errorBody);
        }
    }

       
}
