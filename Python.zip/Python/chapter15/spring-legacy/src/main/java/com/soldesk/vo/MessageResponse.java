package com.soldesk.vo;

public class MessageResponse {

    private final String message;
    private final String receivedBy;

    public MessageResponse(String message) {
        this(message, "Spring PdfRestController");
    }

    public MessageResponse(String message, String receivedBy) {
        this.message = message;
        this.receivedBy = receivedBy;
    }

    public String getMessage() {
        return message;
    }

    public String getReceivedBy() {
        return receivedBy;
    }
}