package com.soldesk.controller;

import java.io.IOException;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;

import org.springframework.core.io.ByteArrayResource;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.HttpStatusCodeException;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.multipart.MultipartFile;

import com.soldesk.vo.ImageResponse;

@RestController
@RequestMapping("/api")
public class ImageRestController {
    
    // 첨부 이미지 최대 크기(10MB)
    private static final long MAX_IMAGE_BYTES = 10L * 1024 * 1024;

    // 허용된 이미지 타입(PNG, JPG)
    private static final Set<String> ALLOWED_IMAGE_TYPES = Set.of(
        MediaType.IMAGE_PNG_VALUE,
        MediaType.IMAGE_JPEG_VALUE);

    private final RestTemplate restTemplate;
    private final String fastApiUrl = "http://localhost:8000";

    private ImageRestController(RestTemplate restTemplate){
        this.restTemplate = restTemplate;
    }

    @PostMapping(value = "/image", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public ResponseEntity<?> createImage(
        @RequestParam String prompt,
        @RequestParam("image") MultipartFile image){

            // 프롬프트 검증
            if(!StringUtils.hasText(prompt) || prompt.length() > 1000){
                return badRequest("이미지 생성 문구는 1글자 이상 1000글자 이하로 입력해야 합니다.");
            }
            // 첨부 이미지 검증
            if(image.isEmpty()){
                return badRequest("이미지를 첨부해주세요.");
            }
            // 첨부 이미지 크기 검증
            if(image.getSize() > MAX_IMAGE_BYTES){
                return badRequest("첨부 이미지는 10MB 이하여야 합니다.");
            }
            // 첨부 이미지 타입 검증
            String contentType = image.getContentType();
            if(!StringUtils.hasText(contentType) || 
                !ALLOWED_IMAGE_TYPES.contains(contentType.toLowerCase())){
                    return badRequest("PNG, JPG, JPEG 형식의 이미지만 사용할 수 있습니다.");
            }
            try {
                // 디폴트 파일명 생성
                String fileName = StringUtils.cleanPath(
                    image.getOriginalFilename() == null ? "reference-image" : image.getOriginalFilename()
                );
                // 첨부 이미지 바이트 배열 리소스 생성
                ByteArrayResource imagResource = new ByteArrayResource(image.getBytes()){
                    @Override
                    public String getFilename() {
                        return fileName;
                    };
                };
                // 첨부 이미지 헤더 설정
                HttpHeaders imagHeaders = new HttpHeaders();
                imagHeaders.setContentDispositionFormData("image", fileName);
                imagHeaders.setContentType(MediaType.parseMediaType(contentType));

                // 바디 설정
                MultiValueMap<String, Object> parts = new LinkedMultiValueMap<>();
                parts.add("prompt", prompt.trim());
                parts.add("image", new HttpEntity<>(imagResource, imagHeaders));

                // 전체 요청 헤더 설정
                HttpHeaders requestHeaders = new HttpHeaders();
                requestHeaders.setContentType(MediaType.MULTIPART_FORM_DATA);
                HttpEntity<MultiValueMap<String, Object>> request = 
                    new HttpEntity<>(parts, requestHeaders);

                // FastAPI에 전송
                return restTemplate.postForEntity(
                    fastApiUrl+"/api/images", request, ImageResponse.class);

            } catch (HttpStatusCodeException error) {
                Map<String, Object> body = message("FastAPI가 이미지 생성 요청을 처리하지 못했습니다");
                body.put("fastAPIStatus", error.getRawStatusCode());
                body.put("fastApiBody", error.getResponseBodyAsString());
                return ResponseEntity.status(error.getRawStatusCode()).body(body);
            } catch(IOException error){
                return ResponseEntity.status(HttpStatus.BAD_REQUEST)
                        .body(message("첨부 이미지를 읽을 수 없습니다"));
            } catch(RestClientException error){
                return ResponseEntity.status(HttpStatus.BAD_GATEWAY)
                        .body(message("FastAPI 이미지 생성 서비스에 연결할 수 없습니다"));
            }

    }

    // 400 Bad Request 응답
    private ResponseEntity<Map<String, Object>> badRequest(String text){
        return ResponseEntity.badRequest().body(message(text));
    }
    // 메시지 생성
    private Map<String, Object> message(String text){
        Map<String, Object> body = new LinkedHashMap<>();
        body.put("message", text);
        body.put("receivedBy", "Spring");
        return body;
    }


}
