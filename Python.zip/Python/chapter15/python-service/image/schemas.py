from pydantic import BaseModel, ConfigDict, Field

# ImageResponse: Spring 웹 화면으로 반환하는 이미지 생성 응답
class ImageResponse(BaseModel):
    model_config = ConfigDict(populate_by_name=True)

    image_base64: str = Field(alias="imageBase64")  # 이미지 데이터를 Base64 인코딩한 문자열
    media_type: str = Field(alias="mediaType")      # 이미지 타입
    prompt: str
    source: str
    model: str
