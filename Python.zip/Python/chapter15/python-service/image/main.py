# 첨부이미지와 프롬프트를 OpenAI 이미지 생성 도구에 전달
import base64
from llm import get_llm, IMAGE_MODEL_NAME, IMAGE_QUALITY

# 이미지 생성
def generated_image(
    prompt: str,
    references_bytes: bytes,
    reference_media_type: str,
)-> tuple[str, str]:

    # 첨부 이미지를 base64 인코딩
    reference_base64 = base64.b64encode(references_bytes).decode("utf-8")
    # 첨부 이미지와 프롬프트를 OpenAI 이미지 생성도구에 전달
    content = [
        {
            "type" : "text",
            "text" : prompt.strip()
         },
         {
            "type" : "image",
            "base64" : reference_base64,
            "mime_type" : reference_media_type,   
         }
    ]
    # 이미지 생성 도구 설정
    image_tool = {
        "type" : "image_generation",    # 이미지 도구 타입
        "quality" : IMAGE_QUALITY,   # 이미지 품질(low, medium, high 중 선택)
        "action" : "edit"       # 편집 도구 타입(edit: 기존 이미지 편집 / create: 새로운 이미지)
    }
    # LLM 연결
    llm = get_llm(model_name=IMAGE_MODEL_NAME, temperature=None, use_responses_api=True)

    # 이미지 생성
    answer = llm.bind_tools([image_tool]).invoke([{"role" : "user", "content" : content}])

    # 이미지 결과 처리
    for block in answer.content_blocks:
        if block.get("type") == "image" and block.get("base64"):
            return block["base64"], block.get("mime_type") or "image/png"
            # 편집된 이미지와 이미지의 타입을 리턴
            
    raise RuntimeError("모델 응답에 생성된 이미지가 없습니다.")


    