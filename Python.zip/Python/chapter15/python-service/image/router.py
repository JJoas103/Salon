import asyncio
import logging
import time
from typing import Annotated

from fastapi import APIRouter, File, HTTPException, UploadFile, Form
from image.main import generated_image
from image.schemas import ImageResponse
from llm import get_llm

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/api", tags=["images"])

MAX_REFERENCE_BYTES = 10 * 1024 * 1024

# 첨부 이미지 검증
def detect_image_type(content: bytes): 
    if content.startswith(b"\x89PNG\r\n\x1a\n"):    # PNG 이미지 판별
        return "image/png"
    if content.startswith(b"\xff\xd8\xff"):        # JPEG 이미지 판별
        return "image/jpeg"

# 스프링이 보낸 이미지와 프롬프트로 이미지를 생성
@router.post("/images", response_model=ImageResponse)
async def create_image(
    prompt: Annotated[str, Form(min_length=1, max_length=1000)],
    image: Annotated[UploadFile, File(...)]
) -> ImageResponse:

    logger.info("[1/6] 요청 수신: prompt_len=%d, filename=%s, content_type=%s",
                len(prompt), image.filename, image.content_type)

    # 프롬프트 검증
    clean_prompt = prompt.strip()
    if not clean_prompt:
        logger.warning("빈 프롬프트로 요청됨")
        raise HTTPException(status_code=400, detail="이미지 생성 문구를 입력하세요")

    try: 
        # 이미지 읽어오기
        reference_bytes = await image.read(MAX_REFERENCE_BYTES + 1)
    finally:
        await image.close()

    logger.info("[2/6] 이미지 읽기 완료: size=%d bytes", len(reference_bytes))

    if not reference_bytes:
        logger.warning("이미지 바이트가 비어있음")
        raise HTTPException(status_code=400, detail="이미지를 첨부하세요.")

    if len(reference_bytes) > MAX_REFERENCE_BYTES:
        logger.warning("이미지 크기 초과: %d bytes", len(reference_bytes))
        raise HTTPException(status_code=413, detail="참고 이미지는 10MB 이하여야 합니다.")

    # 이미지 타입 검증
    media_type = detect_image_type(reference_bytes)
    if media_type is None:
        logger.warning("지원하지 않는 이미지 타입 (매직바이트 불일치)")
        raise HTTPException(status_code=400, detail="PNG, JPEG, JPG 이미지만 첨부하세요.")

    logger.info("[3/6] 이미지 타입 검증 통과: media_type=%s", media_type)

    # 이미지 편집(GPT)
    try:
        logger.info("[4/6] OpenAI 이미지 생성 호출 시작 (asyncio.to_thread)")
        start = time.monotonic()

        generated_base64, generated_media_type = await asyncio.to_thread(
            generated_image,
            clean_prompt,
            reference_bytes,
            media_type,
        )

        elapsed = time.monotonic() - start
        logger.info("[5/6] OpenAI 이미지 생성 완료: elapsed=%.1fs, media_type=%s, base64_len=%d",
                    elapsed, generated_media_type, len(generated_base64) if generated_base64 else 0)

    except Exception as error:
        elapsed = time.monotonic() - start
        logger.exception("OpenAI 이미지 생성 요청에 실패했습니다. elapsed=%.1fs", elapsed)
        raise HTTPException(status_code=503, 
                            detail=("이미지를 생성할 수 없습니다 OpenAI 키를 확인하세요")
        ) from error

    logger.info("[6/6] 응답 반환 준비 완료")

    # 스프링에 편집된 이미지를 전송
    return ImageResponse(
        imageBase64 = generated_base64,
        media_type = generated_media_type,
        prompt = clean_prompt,
        source = "openAI-image-generation",
        model = "gpt-o4-model",
    )