# pip install reportlab

import os
from datetime import datetime
from html import escape
from pathlib import Path

# ReportLab 라이브러리: PDF 생성, 텍스트 스타일 지정, 한글 지원
from reportlab.lib import colors        # 색상 지정
from reportlab.lib.pagesizes import A4   # A4 용지 크기
from reportlab.lib.styles import ParagraphStyle # 텍스트 스타일 지정
from reportlab.lib.units import mm             # 단위 변환
from reportlab.pdfbase import pdfmetrics     # ReportLab에 등록된 글꼴 목록 조회
from reportlab.pdfbase.ttfonts import TTFont   # ReportLab에 글꼴 등록
from reportlab.platypus import Paragraph, SimpleDocTemplate, Spacer # 텍스트 생성, PDF 생성

PYTHON_SERVICE_DIR = Path(__file__).resolve().parents[1]
OUTPUT_DIR = PYTHON_SERVICE_DIR / "output" / "pdf"  # PDF 보고서 저장 폴더
FONT_NAME = "Chapter15Malgun"  # 한글 글꼴 이름

# Windows 맑은 고딕을 ReportLab에 등록
def register_korean_font() -> str:
    if FONT_NAME in pdfmetrics.getRegisteredFontNames():
        return FONT_NAME

    font_path = Path(os.getenv("WINDIR", "C:/Windows")) / "Fonts" / "malgun.ttf"
    if not font_path.is_file():
        raise RuntimeError(
            "한글 PDF 글꼴을 찾을 수 없습니다. "
            "Windows 맑은 고딕(malgun.ttf)을 설치하세요."
        )

    pdfmetrics.registerFont(TTFont(FONT_NAME, str(font_path)))
    return FONT_NAME

# 문서 요약을 PDF 보고서로 저장
# LLM이 생성한 title, source_name, summary, analyzed_characters, model_name을 받아서 PDF 보고서를 생성
def create_summary_pdf(
    title: str,
    source_name: str,
    summary: str,
    analyzed_characters: int,
    model_name: str,
    output_path: Path | None = None,
) -> Path:
    clean_title = title.strip()
    clean_summary = summary.strip()
    if not clean_title:
        raise ValueError("PDF 제목을 입력하세요.")
    if not clean_summary:
        raise ValueError("PDF에 넣을 문서 요약이 없습니다.")

    font_name = register_korean_font()

    # PDF 보고서 저장 폴더 생성
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    output_path = output_path or OUTPUT_DIR / (
        f"document_summary_{datetime.now():%Y%m%d_%H%M%S_%f}.pdf"
    )
    output_path.parent.mkdir(parents=True, exist_ok=True)

    # === PDF 보고서 스타일 정의 ===
    # 제목 스타일 정의
    title_style = ParagraphStyle(
        "Title",
        fontName=font_name,
        fontSize=20,
        leading=28,
        textColor=colors.HexColor("#172554"),
        wordWrap="CJK",
        spaceAfter=7 * mm,
    )
    # 원본/분석/모델 정보를 담은 문단 스타일 정의
    info_style = ParagraphStyle(
        "Info",
        fontName=font_name,
        fontSize=9,
        leading=15,
        textColor=colors.HexColor("#64748b"),
        wordWrap="CJK",
        spaceAfter=7 * mm,
    )
    # 본문 스타일 정의
    body_style = ParagraphStyle(
        "Body",
        fontName=font_name,
        fontSize=10.5,
        leading=18,
        textColor=colors.HexColor("#27364b"),
        wordWrap="CJK",
        spaceAfter=2 * mm,
    )
    # 소제목 스타일 정의
    heading_style = ParagraphStyle(
        "Heading",
        parent=body_style,
        fontSize=13,
        leading=20,
        textColor=colors.HexColor("#1d4ed8"),
        spaceBefore=4 * mm,
    )

    # PDF 문서의 전체 틀(템플릿) 생성
    document = SimpleDocTemplate(
        str(output_path),
        pagesize=A4,
        rightMargin=20 * mm,    
        leftMargin=20 * mm,
        topMargin=20 * mm,
        bottomMargin=20 * mm,
        title=clean_title,
        author="Chapter 15 MCP PDF Service",
    )

    # PDF 보고서 내용 생성  
    story = [
        # 제목 문단 추가
        Paragraph(escape(clean_title), title_style),
        # 원본/분석/모델 정보를 담은 문단 추가
        Paragraph(
            (
                f"원본: {escape(source_name)}<br/>"
                f"분석: {analyzed_characters:,}자<br/>"
                f"모델: {escape(model_name)}"
            ),
            info_style,
        ),
    ]
    # 요약 내용을 소제목과 본문으로 분리
    headings = {"전체 요약", "핵심 내용", "결론"}
    for raw_line in clean_summary.splitlines():
        line = raw_line.strip().lstrip("#").strip().strip("*_")
        if not line:
            story.append(Spacer(1, 2 * mm))
            continue
        style = heading_style if line in headings else body_style
        story.append(Paragraph(escape(line), style))

    # 요약 내용 아래에 추가 정보 문단 추가
    story.extend(
        [
            Spacer(1, 7 * mm),
            Paragraph(
                "자동 요약 결과이므로 중요한 내용은 원문과 대조해 주세요.",
                info_style,
            ),
        ]
    )
    # PDF 문서 생성
    document.build(story)

    # PDF 파일이 생성되지 않았다면 예외 발생
    if not output_path.is_file() or output_path.stat().st_size == 0:
        raise RuntimeError("PDF 파일이 생성되지 않았습니다.")
    return output_path.resolve()
