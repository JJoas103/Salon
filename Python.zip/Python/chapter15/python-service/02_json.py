from fastapi import FastAPI
from pydantic import BaseModel, Field

app = FastAPI(title="chapter15-2 / 02 JSON Request")

class StudyRequest(BaseModel):
    name: str = Field(min_length=1, max_length=30)
    topic: str = Field(min_length=1, max_length=100)
    hours: int = Field(ge=1, le=24)

class StrudyResponse(BaseModel):
    name : str
    topic : str
    hours : int
    message : str
    receivedBy : str

@app.get("/health")
def health()->dict[str, str]:
    return {"stauts" : "ok", "port" : "8002"}

@app.post("/api/study", response_model=StrudyResponse)
def create_study_plan(request: StudyRequest) -> StrudyResponse:
    return StrudyResponse(
        name = request.name,
        topic= request.topic,
        hours= request.hours,
        message= f"{request.name}님의 {request.topic} 학습 시간을 {request.hours}으로 등록했습니다.",
        receivedBy = "02_json.py"
    )

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="localhost", port=8002)