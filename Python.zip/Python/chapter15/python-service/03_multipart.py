from fastapi import FastAPI, File, Form, HTTPException, UploadFile
from typing import Annotated
from pydantic import BaseModel

MAX_FILE_SIZE = 1024 * 1024

app = FastAPI(title="chapter15 / 03.Multipart")

class UploadResponse(BaseModel):
    title: str
    filename: str
    contentType: str
    size: int
    receivedBy: str

@app.get("/health")
def health() -> dict[str, str]:
    return {"status" : "ok", "port" : "8003"}

@app.post("/api/upload")
async def upload_file(
    title: Annotated[str, Form(min_length=1, max_length=100)],
    file: Annotated[UploadFile, File()],
) -> UploadResponse:
    content = await file.read(MAX_FILE_SIZE + 1)
    content_type = file.content_type
    
    return UploadResponse(
        title=title,
        filename=file.filename,
        contentType = content_type,
        size = len(content),
        receivedBy= "FastAPI"
    )

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="localhost", port=8003)