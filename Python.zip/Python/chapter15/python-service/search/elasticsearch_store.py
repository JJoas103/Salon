# Elasticsearch 실질적인 기능을 담당

import csv
import os
from pathlib import Path
from typing import Any

from elasticsearch import Elasticsearch, helpers
from sentence_transformers import SentenceTransformer

CSV_PATH = Path(__file__).parent/'musinsa_products.csv'
INDEX_NAME = 'musinsa-products-agent'
EMBEDDING_MODEL_NAME = 'sentence-transformers/paraphrase-multilingual-MiniLM-L12-v2'

# 임베딩 모델
embedding_model: SentenceTransformer | None = None

# ES 클라이언트
client = Elasticsearch(
    os.getenv("ELASTICSEARCH_URL", "http://localhost:9200"),
    request_timeout=30
)

# 임베딩 모델 객체 생성
def get_embedding_model() -> SentenceTransformer:
    # 전역변수 embedding_model을 함수 안에서 수정하겠음을 선언
    global embedding_model
    # 한번도 임베딩 모델 객체가 만들어지지 않으면 로딩
    if embedding_model is None:
        embedding_model = SentenceTransformer(EMBEDDING_MODEL_NAME)
    return embedding_model

# ES 연결 상태 확인
def ensure_elasticsearch() -> None:
    if not client.ping():
        raise ConnectionError('엘라스틱서치 연결에 실패했습니다.')
    
# CSV를 읽어 상품을 인덱스에 도큐먼트로 저장
def load_products() -> list[dict[str, Any]]:
    products = []
    # CSV 파일 열기
    with CSV_PATH.open(encoding='utf-8', newline='') as file:
        for row in csv.DictReader(file):
            price = int(row['가격'])
            discount = int(row['할인율'].removesuffix('%') or 0)
            content = (
                f"상품ID: {row['상품ID']}\n"
                f"상품명: {row['상품명']}\n"
                f"가격: {price}원\n"
                f"할인율: {discount}%\n"
                f"URL: {row['상품URL']}"
            )
            products.append({
                "product_id" : row['상품ID'],
                "name" : row['상품명'],
                "price" : price,
                "discount" : discount,
                "url" : row['상품URL'],
                "content" : content
            })
    return products

# CSV를 읽고 상품들을 인덱스에 저장
def prepare_index() -> dict[str, Any]:
    ensure_elasticsearch()

    # 인덱스가 이미 만들어져 있는 지 확인
    exists = bool(client.indices.exists(index=INDEX_NAME))

    # 인덱스가 이미 존재하면, 인덱스에 있는 문서 개수를 반환
    if exists:
        stored_count = client.count(index=INDEX_NAME)['count']
        if stored_count > 0:
            return {
                'created' : False,
                'index' : INDEX_NAME,
                'document_count' : stored_count,
                'message' : '기존 상품 인덱스를 사용합니다.'
            }
    # 인덱스가 없으면, CSV에서 상품을 읽어 인덱스에 저장
    # CSV에서 상품 들을 가져오기
    products = load_products()
    
    # 상품의 content 임베딩
    model = get_embedding_model()
    vectors = model.encode(
        [product['content'] for product in products],
        normalize_embeddings=True,
    ).tolist()

    # 인덱스 생성
    if not exists:
        client.indices.create(
            index=INDEX_NAME,
            mappings={
                'properties' : {
                    'product_id' : {'type' : 'keyword'},
                    'name' : {'type' : 'text', 'analyzer' : 'nori'},
                    'price' : {'type' : 'integer'},
                    'discount' : {'type' : 'integer'},
                    'url' : {'type' : 'text', 'analyzer' : 'nori'},
                    'content' : {'type' : 'text', 'analyzer' : 'nori'},
                    'embedding': {
                        'type' : 'dense_vector',
                        'dims' : len(vectors[0]),
                        'index' : True,
                        'similarity' : 'cosine'
                    },
                } 
            },
        )
    # 상품 색인
    helpers.bulk(
        client, 
        (
            {
            '_index' : INDEX_NAME,
            '_id' : product['product_id'],
            '_source' : {**product, 'embedding' : vector},
            }for product, vector in zip(products, vectors)
        ),
    )
    client.indices.refresh(index=INDEX_NAME)

    return{
        'created' : True,
        'index' : INDEX_NAME,
        'document_count' : len(products),
        'message' : '상품 인덱스와 임베딩을 준비했습니다.'
    }

# 상품 검색
def hybrid_search(
        query: str,
        max_price: int | None = None,
        min_discount: int | None = None,
        count: int = 5,
)->list[dict[str, Any]]:
    
    # 연결 확인
    ensure_elasticsearch()

    # 인덱스가 없으면 에러
    if not client.indices.exists(index=INDEX_NAME):
        raise RuntimeError('prepare_product_index Tool을 먼저 호출하세요.')
    
    query = query.strip()
    if not query:
        raise ValueError('상품 특징이나 종류를 query에 입력하세요.')

    if max_price is not None: 
        if max_price <=0 or max_price > 100000000:
            raise ValueError('max_price는 1원 이상 1억 원 이하이어야 합니다.')
    
    if min_discount is not None: 
        if min_discount < 0 or min_discount > 100:
            raise ValueError('min_discount 0 이상 100 이하이어야 합니다.')
    
    if count < 1:
        count = 1
    elif count > 10:
        count = 10

    # 필터 조건 구성(가격/할인율)
    filters: list[dict[str, Any]] = []

    if max_price is not None:
        # range 쿼리: price 필드 값이 max_price 이하(lte)
        filters.append({'range' : {'price' : {'lte': max_price}}})
    
    if min_discount is not None:
        # range 쿼리: discount 필드 값이 min_discount 이상(gte)
        filters.append({'range' : {'discount' : {'gte': min_discount}}})
    

    # 키워드 검색
    keyword_query: dict[str, Any] = {
        'multi_match' : {
            'query' : query,
            'fields' : ['name^3', 'content'],
            'boost': 0.7
        }
    }
    if filters:
        keyword_query = {
            'bool':{
                'must': [keyword_query],
                'filter' :filters,  
            }
        }
    
    # 벡터 기반 검색 조건 구성
    model = get_embedding_model()
    knn: dict[str, Any] = {
        'field' : 'embedding',
        'query_vector' : model.encode(
            query, 
            normalize_embeddings=True,
        ).tolist(),
        'k' : count,
        'num_candidates' : max(50, count * 5),
        'boost' : 0.3,
    }
    if filters:
        knn['filter'] = {'bool' : {'filter' : filters}}
    
    # 검색 요청
    response = client.search(
        index=INDEX_NAME,
        size=count,
        query=keyword_query,
        knn=knn
    )

    # 결과 반환
    products = []
    for hit in response['hits']['hits']:
        product = dict(hit['_source'])
        product.pop('embedding', None)
        product['search_score'] = hit.get('_score')
        products.append(product)

    return products