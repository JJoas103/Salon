# pip install fastapi

from fastapi import FastAPI, Query

app = FastAPI(title='chapter15 / 01.Basic GET')

# 상태 확인 API
@app.get('/health')
def health() -> dict[str, str]:
    return {'status' : 'ok', 'example' : '01_basic', 'port' : '8001'}

@app.get('/api/hello')
def hello(
    name: str = Query(min_length=1, max_length=30),
    language: str = Query(default='ko')
    ) -> dict[str, str]:
    message = f'Hello, {name}!' if language == 'en' else f'안녕하세요, {name}님!!'
    return {
        "message" : message,
        "name" : name,
        "language" : language,
        "receivedBy" : "FastAPI 01_basic에서 보냄"
    }


if __name__ == '__main__':
    import uvicorn  # FastAPI를 실행하는 명령어
    uvicorn.run(app, host='localhost', port=8001)