import logging
from pathlib import Path
from typing import Annotated
from urllib.parse import quote
from uuid import uuid4

from fastapi import APIRouter, File, Form, HTTPException, Request, UploadFile
from fastapi.responses import Response

from pdf.main import McpPdfService

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/api", tags=["pdf"])

PYTHON_SERVICE_DIR = Path(__file__).parent / ".."
PDF_INPUT_DIR = PYTHON_SERVICE_DIR / "tmp" / "pdfs" / "input"
ALLOWED_DOCUMENT_SUFFIXES = {".txt", ".md", ".pdf"}
MAX_DOCUMENT_BYTES = 5 * 1024 * 1024

# 스프링에서 보낸 문서를 MCP를 통해 LLM이 요약하고 PDF 파일을 반환
@router.post("/pdfs")
async def create_pdf(
    title: Annotated[str, Form(min_length=1, max_length=100)],
    document: Annotated[UploadFile, File(...)],
    request: Request,
) -> Response:
    clean_title = title.strip()
    if not clean_title:
        raise HTTPException(status_code=400, detail="PDF 제목을 입력하세요.")

    original_name = Path(document.filename or "document.txt").name
    suffix = Path(original_name).suffix.lower()
    if suffix not in ALLOWED_DOCUMENT_SUFFIXES:
        await document.close()
        raise HTTPException(
            status_code=400,
            detail="TXT, Markdown, PDF 문서만 사용할 수 있습니다.",
        )

    try:
        document_bytes = await document.read(MAX_DOCUMENT_BYTES + 1)
    finally:
        await document.close()

    if not document_bytes:
        raise HTTPException(status_code=400, detail="요약할 문서를 선택하세요.")
    if len(document_bytes) > MAX_DOCUMENT_BYTES:
        raise HTTPException(
            status_code=413,
            detail="요약할 문서는 5MB 이하여야 합니다.",
        )
    if suffix == ".pdf" and not document_bytes.startswith(b"%PDF-"):
        raise HTTPException(
            status_code=400,
            detail="올바른 PDF 파일이 아닙니다.",
        )

    PDF_INPUT_DIR.mkdir(parents=True, exist_ok=True)
    input_name = f"{uuid4().hex}{suffix}"
    input_path = PDF_INPUT_DIR / input_name
    input_path.write_bytes(document_bytes)

    try:
        # 상태저장소에 저장된 McpPdfService 객체 불러오기
        pdf_service: McpPdfService = request.app.state.pdf_service

        output_path = await pdf_service.create_summary_pdf(
            title=clean_title,
            input_name=input_name,
            original_name=original_name,
        )

        pdf_bytes = output_path.read_bytes()
        if not pdf_bytes.startswith(b"%PDF-"):
            raise RuntimeError("생성 결과가 올바른 PDF 파일이 아닙니다.")
        
    except Exception as error:
        logger.exception("MCP 문서 요약 PDF 생성에 실패했습니다.")
        raise HTTPException(
            status_code=503,
            detail=(
                "문서 요약 PDF를 생성할 수 없습니다. "
                "OpenAI API 키와 mcp_pdf 설정을 확인하세요. "
                f"({type(error).__name__}: {error})"
            ),
        ) from error
    finally:
        input_path.unlink(missing_ok=True)

    download_name = quote(output_path.name)
    return Response(
        content=pdf_bytes,
        media_type="application/pdf",
        headers={
            "Content-Disposition": (
                f"attachment; filename=\"document-summary.pdf\"; "
                f"filename*=UTF-8''{download_name}"
            ),
            "X-MCP-Server": "document-summary-pdf",
        },
    )


