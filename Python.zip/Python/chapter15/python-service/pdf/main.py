# MCP 서버와 연결하는 클라이언트 객체, LLM과 통신하는 에이전트 객체 생성 및 관리

import asyncio
import json
import logging
import sys
from contextlib import AsyncExitStack
from pathlib import Path
from typing import Any

from langchain_core.messages import HumanMessage
from langchain_mcp_adapters.client import MultiServerMCPClient
from langchain_mcp_adapters.prompts import load_mcp_prompt
from langchain_mcp_adapters.tools import load_mcp_tools

from llm import get_llm

logger = logging.getLogger("uvocorn.error")

PYTHON_SERVICE_DIR = Path(__file__).parent/'..'
MCP_SERVER_MODULE = "mcp_pdf.mcp_pdf_server"

class McpPdfService:

    def __init__(self) -> None:
        self._client: MultiServerMCPClient | None = None # MCP 클라이언트 객체
        self._document_tool: Any = None                  # MCP 도구(Tool)-문서 읽기 불러오기
        self._pdf_tool: Any = None                       # MCP 도구(Tool)-PDF 쓰기 불러오기
        self._summary_prompt: list = []                  # MCP 프롬프트 불러오기
        self._llm: Any = None                            # LLM 객체
        self._exit_stack: AsyncExitStack | None          # 종료 스택 객체
        self._start_lock = asyncio.Lock()                # 시작 락 객체
        self._invoke_lock = asyncio.Lock()               # 호출 락 객체
        # asyncio.Lock(): 비동기 락 객체(동시 접근 제한)

    # 클라이언트 생성, 도구 로드, LLM 초기화, 세션 생성
    async def start(self) -> None:

        # llm 객체가 이미 초기화되어 있으면 메서드 종료
        if self._llm is not None:
            return

        # 다른 클라이언트는 락이 걸려 대기
        async with self._start_lock:
            if self._llm is not None:
                return

            # 종료 스택 객체 생성
            exit_stack = AsyncExitStack()

            try:
                client = MultiServerMCPClient(   # MCP 클라이언트 객체 생성
                    {
                        "documents": {
                            "transport": "stdio",
                            "command": sys.executable,
                            "args": ["-m", MCP_SERVER_MODULE],
                            "cwd": str(PYTHON_SERVICE_DIR),
                        }
                    }
                )
                # MCP 클라이언트 객체의 documents 세션 생성
                session = await exit_stack.enter_async_context(
                    client.session("documents")
                )
                tools = await load_mcp_tools(session)
                tools_by_name = {tool.name: tool for tool in tools}

                # MCP 클라이언트 객체의 documents 세션에서 문서 읽기 Tool 찾기
                document_tool = tools_by_name.get("read_document")
                pdf_tool = tools_by_name.get("create_document_summary_pdf")
                if document_tool is None or pdf_tool is None:
                    raise RuntimeError(
                        "mcp_pdf 서버에서 문서 읽기 또는 PDF Tool을 찾을 수 없습니다."
                    )
                summary_prompt = await load_mcp_prompt(
                    session,
                    "document_summary_prompt",
                    arguments={"max_points": "5"},
                )

                self._client = client
                self._exit_stack = exit_stack
                self._document_tool = document_tool
                self._pdf_tool = pdf_tool
                self._llm = get_llm(temperature=0.1)
                self._summary_prompt = summary_prompt
                logger.info('MCP 문서 서버 연결과 PDF 서비스 초기화 완료')

            except Exception:
                await exit_stack.aclose()
                raise

    # MCP로 문서를 읽고 LLM으로 요약한 뒤 PDF Tool을 호출
    async def create_summary_pdf(
        self,
        title: str,
        input_name: str,
        original_name: str,
    ) -> Path:
        # 첫 요청에서 MCP PDF 서버와 Tool을 한 번만 준비
        await self.start()

        async with self._invoke_lock:
            # 파일 읽기
            document_result = self._tool_dict(
                await self._document_tool.ainvoke(
                    {
                        "input_name": input_name,
                        "original_name": original_name,
                    }
                )
            )
            if document_result.get("status") != "completed":
                raise RuntimeError("MCP 문서 읽기가 완료되지 않았습니다.")

            answer = await self._llm.ainvoke(
                [
                    *self._summary_prompt,
                    HumanMessage(
                        content=(
                            "[문서 시작]\n"
                            f"{document_result['document_text']}\n"
                            "[문서 끝]"
                        )
                    ),
                ]
            )
            # LLM 요약 결과 추출
            summary = str(answer.content).strip()
            if not summary:
                raise RuntimeError("LLM 응답에 문서 요약이 없습니다.")

            # MCP PDF 생성
            pdf_result = self._tool_dict(
                await self._pdf_tool.ainvoke(
                    {
                        "title": title,
                        "source_name": document_result["source_name"],
                        "summary": summary,
                        "analyzed_characters": document_result[
                            "analyzed_characters"
                        ],
                        "model_name": "",
                    }
                )
            )

            if pdf_result.get("status") != "completed":
                raise RuntimeError("MCP PDF 생성이 완료되지 않았습니다.")

            output_path = Path(str(pdf_result["path"])).resolve()
            if not output_path.is_file():
                raise RuntimeError("MCP가 생성한 PDF 파일을 찾을 수 없습니다.")
            return output_path


    # MCP ainvoke 결과에서 JSON dict만 추출
    @staticmethod
    def _tool_dict(result: Any) -> dict[str, Any]:
        return json.loads(result[0]["text"])

    # FastAPI 종료 시 MCP 세션과 하위 프로세스를 정리한다
    async def close(self) -> None:
        
        async with self._invoke_lock:
            if self._exit_stack is not None:
                await self._exit_stack.aclose()

            self._client = None
            self._exit_stack = None
            self._document_tool = None
            self._pdf_tool = None
            self._llm = None
            self._summary_prompt = []




    
