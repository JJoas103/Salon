import os
from pathlib import Path

from dotenv import load_dotenv
from langchain_openai import ChatOpenAI

# 저장소 루트(.env)와 현재 작업 디렉터리 .env를 로드
_ROOT_ENV = Path(__file__).resolve().parents[3] / ".env"
load_dotenv(_ROOT_ENV)
load_dotenv()

# OpenAI GPT 모델 설정 (환경변수 OPENAI_API_KEY 필요)
MODEL_NAME = os.getenv("OPENAI_MODEL", "gpt-4o-mini")
IMAGE_MODEL_NAME = os.getenv(
    "OPENAI_IMAGE_MODEL",
    os.getenv("OPENAI_IMAGE_TOOL_MODEL", "gpt-5.4-mini"),
)
api_key = os.getenv("OPENAI_API_KEY")
IMAGE_QUALITY = os.getenv("OPENAI_IMAGE_QUALITY", "low")

# llm 객체 생성
def get_llm(
        model_name: str = MODEL_NAME,
        temperature: float | None = 0.2 ,
        use_responses_api: bool = False) -> ChatOpenAI:
    api_key = os.getenv("OPENAI_API_KEY")
    if not api_key:
        raise RuntimeError(
            "OPENAI_API_KEY가 없습니다. "
            "저장소 루트 .env 또는 환경변수에 키를 설정하세요."
        )
    options = {
        "model": model_name,
        "api_key": api_key,
        "use_responses_api": use_responses_api,
    }
    if temperature is not None:
        options["temperature"] = temperature
    return ChatOpenAI(**options)
