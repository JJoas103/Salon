from llm import get_llm
from langchain_core.output_parsers import StrOutputParser
from langchain_core.prompts import ChatPromptTemplate
from elasticsearch_common import prepare_index, search_products

# 직전 검색인지 판단하는 키워드
FOLLOW_UP_WORDS = ('방금', '그중', '그 중', '첫 번째', '두 번째', '링크')

# 체인 생성
def create_chain():
    prompt = ChatPromptTemplate.from_messages([
        (
            'system',
            '너는 무신사 상품 추천 상담원이다. 반드시 검색된 상품만 근거로 '
            '답한다. 상품명, 가격, 할인율, 추천 이유와 URL을 표시한다.',
        ),
        (
            'human',
            '[최근 대화] \n{history}\n\n'
            '[검색된 상품] \n{context}\n\n'
            '[현재 질문] \n{question}\n\n'
        )
    ])
    chain = prompt | get_llm() | StrOutputParser()
    return chain

# 메인 함수
def main() -> None:
    try:
        # ES에 인덱스 생성
        prepare_index()
        chain = create_chain()
    except Exception as error:
        print('시작 실패: ElasticSearch 또는 LLM 설정을 확인하세요')
        print('상세 오류: ', error)
        return
    
    history: list[str] = []         # 대화기록(문자열)
    last_product: list[dict] = []   # 검색된 상품(딕셔너리)

    print('질문 예: 3만원 이하 티셔츠를 추천해 줘')
    print('종료하려면 "종료"를 입력하세요')

    while True:
        # 사용자의 질문
        question = input('\n나: ').strip()

        # 사용자 질문X
        if not question:
            continue
        # 챗봇 종료
        if question.lower() in {'종료', 'exit', 'quit'}:
            print('챗봇: 상담을 종료합니다')
            break

        try:
            # 사용자의 질문이 직전 검색된 상품을 참조하는 질문인지 판단(키워드로)
            is_follow_up = any(word in question for word in FOLLOW_UP_WORDS)

            # 새로운 질문 - ES에서 검색
            if not is_follow_up or not last_product:
                # 사용자의 질문의 키워드가 일치하는 상품이거나 유사도가 높은 상품들을 가져오기
                last_product = search_products(question)

            # 검색 결과가 없으면 다시 질문지 작성
            if not last_product:
                print('챗봇: 조건에 맞는 상품을 찾지 못했습니다')
                continue

            # 검색결과를 문자열로 반환
            context = '\n\n'.join(
                product['content'] for product in last_product
            )
            # LLM에게 최종답변 받아오기
            answer = chain.invoke({
                'history' : '\n'.join(history[-6:]) or '이전 대화 없음',
                'context' : context,
                'question' : question
            })
        except Exception as error : 
            print('챗봇: 검색 또는 LLM 호출에 실패했습니다')
            print('상세오류: ', error)
            continue
        print('챗봇: ', answer)
        #사용자의 질문, AI 답변을 history 리스트에 담기
        history.extend([f'사용자: {question}', f'챗봇: {answer}'])
main()
         
