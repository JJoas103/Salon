import csv
import os
import re
from pathlib import Path
from elasticsearch import Elasticsearch, helpers
from sentence_transformers import SentenceTransformer

CSV_PATH = Path(__file__).parent/'musinsa_products.csv'
INDEX_NAME = 'musinsa-products'

client = Elasticsearch(
    os.getenv('ELASTICSEARCH_URL', 'http://localhost:9200'),
    request_timeout=30,
)
embedding_model = SentenceTransformer(
    'sentence-transformers/paraphrase-multilingual-MiniLM-L12-v2'
)

# CSV 상품 들을 인덱스에 저장
def prepare_index() ->None:
    if not client.ping():
        raise ConnectionError('ES 연결에 실패했습니다')

    # CSV 불러오기
    products = []
    with CSV_PATH.open(encoding='utf-8', newline='') as file:
        for row in csv.DictReader(file):
            price = int(row['가격'])
            discount = int(row['할인율'].removesuffix('%') or 0)
            content = (
                f'상품ID : {row["상품ID"]}\n'
                f'상품명 : {row["상품명"]}\n'
                f'가격 : {price}원\n'
                f'할인율: {discount}%\n'
                f'URL: {row["상품URL"]}'
            )
            products.append({
                'product_id' : row['상품ID'],
                'name' : row['상품명'],
                'price' : price,
                'discount' : discount,
                'url' : row['상품URL'],
                'content' : content
            })
        vectors = embedding_model.encode(
            [product["content"] for product in products],
            normalize_embeddings=True,
        ).tolist()
                
    # 인덱스 검사 후 인덱스가 없으면 상품 저장
    exists = client.indices.exists(index=INDEX_NAME)
    if not exists:
        client.indices.create(
            index=INDEX_NAME,
            mappings={
                'properties' : {
                    'product_id' : {'type' : 'keyword'},
                    'name' : {'type' : 'text', 'analyzer' : 'nori'},
                    'price' : {'type' : 'integer'},
                    'discount' : {'type' : 'integer'},
                    'url' : {'type' : 'keyword', 'index' : False},
                    'content' : {'type' : 'text', 'analyzer' : 'nori'},
                    'embedding' : {
                        'type' : 'dense_vector',
                        'dims' : len(vectors[0]),
                        'index' : True,
                        'similarity' : 'cosine',
                    },
                }
            },
        )
    helpers.bulk(
        client,
        (
            {
                '_index' : INDEX_NAME,
                '_id' : product['product_id'],
                '_source' : {**product, 'embedding' : vector}
            }
            for product, vector in zip(products, vectors)
        ),
    )
    client.indices.refresh(index=INDEX_NAME)

# 사용자의 질문에서 상품을 검색해 상품 들을 리스트로 반환
def search_products(question: str, count: int = 5) -> list[dict]:
    # 키워드 검색
    keyword_query = {
        'multi_match' : {
            'query' : question,
            'fields' : ['name^3', 'content'],
            'boost' : 0.7
        }
    }
    # 벡터 검색
    knn = {
        'field' : 'embedding',
        'query_vector' : embedding_model.encode(
            question,
            normalize_embeddings=True
        ).tolist(),     # 사용자의 질문을 벡터화
        'k' : count,
        'num_candidates' : 50,  # 후보개수
        'boost' : 0.3
    }
    # 검색 요청
    response = client.search(
        index=INDEX_NAME,
        size = count,
        query = keyword_query,
        knn = knn
    )
    # 검색 결과를 반환
    return [hit['_source'] for hit in response['hits']['hits']]